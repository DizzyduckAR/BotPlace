class ClientConfig(object):
    PUBLIC_KEY = 'q1zREphA5FDAMaW186E4K491hai1siewtYe1gaUaKX8'
    APP_NAME = 'BotPlace App Hub'
    COMPANY_NAME = 'Buck and Moncey'
    HTTP_TIMEOUT = 30
    MAX_DOWNLOAD_RETRIES = 3
    APP_VERSION = '1.0.0'
    UPDATE_URLS = ['https://github.com/DizzyduckAR/BotPlace/tree/master/projects-update/BotPlace-Hub/']


New Auto mirror App Fully portable and open source

![Auto_Mirror_TMyi6ILZII](https://user-images.githubusercontent.com/52171360/111868311-e9ba0180-8981-11eb-9785-bb27e4815504.png)


Mirror All and Any Android Device No root needed.

App Size 700KB and 33.7mb after Deploy.

Fully Secure RSA handshake to bubble you from anything.

Multi Mirror Built In

Auto Support USB and WIFI mirror

Auto Get connected device ip

Remote ip connect

kill all ADB

Turn Device Screen On and Off (while keep mirror alive)

Everything is tiny and adaptive to make an easy and smooth Mirror process.

*App Will Self Deploy Core and Ip get Command From github.

GUI:
html / css / js

ahk function with html dom

SVG's by Flaticon


**How to Debug Phone**

Step 1
![1Enable-Developer-Options-Android- GIF](https://user-images.githubusercontent.com/52171360/63210271-dafbd080-c0f4-11e9-8b32-18f4d4386272.gif)

Step 2
![2Enable-Debug-GIF](https://user-images.githubusercontent.com/52171360/63210272-dd5e2a80-c0f4-11e9-9849-f7254db6ff24.gif)

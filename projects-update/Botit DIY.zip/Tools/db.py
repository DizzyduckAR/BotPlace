import json
import os
import configparser
import requests
botlist=[]
def addtoDB(window,name,type):
    print(name,type)

def jsoncompare(window,botobject):
    print('new compare')
    try:
       # print('compare '+botobject) 
        compbot=[]
        compmodes=[]
        compobj=[]

        
       # print('New func',botobject.name)
        game1 = open("DB/"+botobject.name+".json")
        game1data = json.load(game1)
       # print(game1data)
        Botdata = game1data["Settings"][0]
       # print(Botdata)
        modedata = game1data["modes"]
       # print(modedata)
        objdata = game1data['Objects']
        #print(objdata)


        botobject.GetSetting()
        botobject.GetModes()
        botobject.GetObjs()
        shadowdata=botobject.data
        Botdatashadow = botobject.settings
        modedatashadow = botobject.modesRaw
        objshadow = botobject.objs

    # print(botobject.objlist)


        #bot settings check
        for gmdat in Botdata:
            try:
                if Botdata[gmdat] == Botdatashadow[gmdat]:
                    pass
                else:
                    compbot.append(gmdat)
            except:
                compbot.append(gmdat)
        


        #modes check
        if modedata == modedatashadow:
            pass
        else:
            
            if len(modedata)!=len(modedatashadow):
                compmodes.append('New Modes')
            indexer = 0
            for gmode in modedata:
                try:
                    for key in gmode:
                        try:
                            tmp = modedatashadow[indexer][key]
                            if modedata[indexer][key]== tmp:
                                pass
                            else:
                                compmodes.append(key)
                        except:
                            compmodes.append(key)
                        
                        indexer = indexer+ 1
                    
                    
                except:
                    indexer =indexer+ 1
        

        #Objects check
        if objdata == objshadow:
            pass
        else:
            if len(objdata)!=len(objshadow):
                compobj.append('New Objects')
            indexer = 0
            for gobj in objdata:
            # print(gobj)
                try:
                    for key in gobj:
                        try:
                            tmp = objshadow[indexer][key]
                            if objdata[indexer][key]== tmp:
                                pass
                            else:
                                compobj.append(key)
                        except:
                            compobj.append(key)
                        
                        indexer = indexer+ 1
                    
                    
                except:
                    indexer =indexer+ 1
        

        if not compbot and  not compmodes and not compobj:
            print('pass ok')

            
            result1 = window.evaluate_js("""
        
        document.getElementById("modalshead").innerHTML = `<div class="mb-5 text-2xl font-medium leading-none mt-3 text-center">No Changes Detected <br> Bot Data Loaded</div>`;
        document.getElementById("modalsbody").innerHTML =""
        document.getElementById("modalsfoot").innerHTML=' <button type="button" data-dismiss="modal" class="btn btn-success  w-24">Ok</button> ';
        
                                """)
            pass
        else:
            print('changes detected')
        #  print(compbot)
        #  print(compmodes)
        #  print(compobj)

            dict = {'set':compbot,'mds':compmodes,'objs':compobj,'botname':botobject.name}
            result1 = window.evaluate_js("""
        
        document.getElementById("modalshead").innerHTML = `<div class="mb-5 text-2xl font-medium leading-none mt-3 text-center">Warning Web App<br>Data Changes Detected!!</div>`;
        document.getElementById("modalsbody").innerHTML ="Bot Settings:<br>{set}<br><br>Bot Modes:<br>{mds}<br><br>Bot Objects:<br>{objs}<br><br>"
        document.getElementById('modalsfoot').innerHTML = ` <button type="button" onclick="pywebview.api.jsonsave('{botname}')" data-dismiss="modal" class="btn btn-danger  w-24">Restore</button> <button type="button" data-dismiss="modal" class="btn btn-success ml-3  w-24">Keep Local</button> `
        
                                """.format(**dict))
            # dict = {'botname':name}
            # testvar = ''' document.getElementById('footbtns').innerHTML = ` <button type="button" onclick="pywebview.api.objectscards(' {botname} ')" data-dismiss="modal" class="btn btn-danger  w-24">Save</button> <button type="button" data-dismiss="modal" class="btn btn-success ml-3  w-24">Dont Save</button> ` '''.format(**dict)
            # test = window.evaluate_js(testvar)

        
    except:
            print('error in compare')

def dataget(botname,myuser,mypass,hand,Udata):
   # print(botname,myuser,mypass)
    url =hand
    #url ="https://botplace.hopto.org/api/devhand/?format=json"
    r = requests.get(url, auth=(myuser,mypass))
    datahand= r.json()
    for item in datahand:
        #print(item)
        vergate=False
        imggate=False
        botname2=item["botname"]
        try:
            botlist.index(botname2)
        except:
            print("no obj")
            botlist.append(botname2)
        
        try:
            tmp_data=open("DB/"+botname2+".json")
            datatmp = json.load(tmp_data)
            settings = datatmp[botname2][0]
            version = settings['botver']
            imgversion = settings['botimgver']
            # oldmodes = datatmp[botname][1]
            # oldobjects = datatmp[botname][2]

            # print(oldmodes)
            # print(oldobjects)
            
            #print(settings)
            settingappend= {'botver': item['botver'], 'botimgver': item['botimgver'], 'targetwidth': item['targetwidth'],
                                'targetheight': item['targetheight'],'thumburl': item['thumburl'],
                                'system': item['system'],'botgui': item['botgui'],'dev': item['dev'],'public':True,'code':item['Code']}
            datatmp[botname2][0]=settingappend
            json.dumps(datatmp)
            with open('DB/'+ botname2 +'.json', mode='w') as f:
                f.write(json.dumps(datatmp, indent=2))
        except:print('settings err')
    # url ="https://botplace.hopto.org/api/devdata/?format=json"
    
    #Settings update Done
    
    url =Udata
    test = myuser
    test2 = mypass
    #print(botname)
    tmp_data=open("DB/"+botname+".json")
    datatmp = json.load(tmp_data)
    r = requests.get(url, auth=(test, test2),params = {"data": botname+'|Full'})
   # print(r)
    data= r.json()
   # print(data)
    modeslist=[]
    #print(modeslist)
    for item2 in data:
       # print(item2["goldmodes"])
        try:
            tmp = json.loads(item2["goldmodes"])
            for stuff in tmp:
                modeslist.append(stuff)
                #print('Mode name',stuff)
                #print('Mode Data',tmp[stuff])
        except:print('error in gold modes')

    # print(modeslist)
    #Modes Write
    #print(botname)
    datatmp[botname][1]['modes']=[]
    

    #for item in datatmp:
        #print(jdata[item][1]['modes'])
    for mode in modeslist:
        datatmp[botname][1]['modes'].append(
    
        {mode:
            [
            {'free': False,'silver':False ,'gold':True ,'objects':tmp[mode]}
            ]
        }
    
    )
    
  #  print('start silver')
    
    #Silver modes
    #for item in data:
        #print(item)
  #  print('starting silver',item2["silvermodes"])
    try:
        tmp = json.loads(item2["silvermodes"])
        #print(tmp)
        for stuff in tmp:
            #print(stuff)
            # print('Mode name',stuff)
            
        # print('Mode index',modeslist.index(stuff))
            #print(datatmp[botname][1]['modes'][modeslist.index(stuff)][stuff][0]['silver'])
            datatmp[botname][1]['modes'][modeslist.index(stuff)][stuff][0]['silver']=True
            # print(datatmp[botname][1]['modes'][modeslist.index(stuff)][stuff][0]['silver'])
            # print('Mode Data',tmp[stuff])
    except:print('error in silver modes')
    # print('done')
    # return
    # with open('DB/'+ botname +'.json', mode='w') as f:
    #     f.write(json.dumps(datatmp, indent=2))
  #  print('start Free')

    
    #Silver modes
    #for item in data:
        #print(item)
    try:
        tmp = json.loads(item2["freemodes"])
        for stuff in tmp:
            datatmp[botname][1]['modes'][modeslist.index(stuff)][stuff][0]['free']=True

    except:pass

  #  print('Start obj writer')
    # print(data)
    #Object Write
    datatmp[botname][2]['Objects']=[]
    ### Start Obj Get
    objlist=[]
    # for item in data:
        #print(item)
        #print(item["imgcalls"])
    try:
        tmp = json.loads(data[0]["imgcalls"])
        for stuff in tmp:
            #print('obj name',stuff)
            objlist.append(stuff)
            #print('Mode name',stuff)
            #print('obj Data',tmp[stuff])
    except:pass

  #  print('My object List',objlist)
    
    for item in datatmp:
    # print('Obj list',datatmp[botname][2]['Objects'])

        for obj in objlist:
    #         print(obj)
            args=tmp[obj].split("|")
            if args[0]=="Image":
                print('image')
                try:
                    datatmp[botname][2]['Objects'].append(
                    {obj:
                        [
                        {'type':args[0],'tol':args[1] ,'scantype':args[2] ,'scancolor':args[3],'clicks':args[4],'x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                        ]
                    })
                except:
                    datatmp[botname][2]['Objects'].append(
                    {obj:
                        [
                        {'type':args[0],'tol':'' ,'scantype':'' ,'scancolor':'','clicks':'','x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                        ]
                    })

            if args[0]=="Pixel":
                print('Pixel')
                try:
                    print(args[4])
                    pixclr=args[4]
                except:
                    pixclr=''

                try:
                    datatmp[botname][2]['Objects'].append(
                        {obj:
                            [
                            {'type': args[0],'tol':args[1] ,'scantype':args[2] ,'clicks':args[3],'pixelcolor':pixclr,'x1':'','y1':'','x2':'','y2':''}
                            ]
                        })
                except:
                    datatmp[botname][2]['Objects'].append(
                    {obj:
                        [
                        {'type':args[0],'tol':'' ,'scantype':'' ,'clicks':'','pixelcolor':'','x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                        ]
                    })
            if args[0]=="Func":
                print('Func')
                try:
                #print(tmp[obj])
                    funcobjs=tmp[obj].replace("Func|", '')
                
                # print(funcobjs)
                except:
                    funcobjs=''
                
                if funcobjs=="Func" or funcobjs=="func":
                    funcobjs=''

                datatmp[botname][2]['Objects'].append(
                    {obj:
                        [
                        {'type': args[0],'objects':funcobjs,'code':''}
                        ]
                    }
                
                )
            if args[0]=="UIFunc":
                print('UIFunc')
                datatmp[botname][2]['Objects'].append(
                    {obj:
                        [
                        {'type': args[0],'code':''}
                        ]
                    }
                
                )
    
    #img calls Imgxy
    print('try y')
    try:
        tmp = json.loads(data[0]["imgxy"])
        
        print(tmp)
        
        for stuff in tmp:
            try:
                #print('ImageXY  ',tmp[stuff])
                args=tmp[stuff].split("|")
                # print(args[0])
                # print(jdata[botname][2]['Objects'][objlist.index(stuff)][stuff][0])
                datatmp[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['x1']=args[0]
                datatmp[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['y1']=args[1]
                datatmp[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['x2']=args[2]
                datatmp[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['y2']=args[3]
                # #print('obj name',stuff)
                # objlist.append(stuff)
                #print('Mode name',stuff)
                #print('obj Data',tmp[stuff])
            except:print('error in xy', stuff)
    except:print('error in xy' )

    #Img Strings
    try:
        tmp = json.loads(data[0]["botimages"])
        for stuff in tmp:
            datatmp[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['colorstring']=tmp[stuff]
    except:pass


    #Func Code Writter
    try:
        tmp = json.loads(data[0]["botfunctions"])
    # print(tmp)
        # print(datatmp[botname][2]['Objects'])
        for item in tmp:
            # print(item)
            # print(tmp[item])
            # print(jdata[botname][2]['Objects'][objlist.index(item)][item][0]['code'])
            datatmp[botname][2]['Objects'][objlist.index(item)][item][0]['code']=tmp[item]
            #jdata[botname][2]['Objects'][modeslist.index(item)][item][0]['free']=
            

    
    except:
        print('nocode')
        #code=''

    print('before save')
    json.dumps(datatmp)
    with open('DB/'+ botname +'.json', mode='w') as f:
        f.write(json.dumps(datatmp, indent=2))
    
    print('after')


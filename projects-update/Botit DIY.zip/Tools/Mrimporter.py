import os
#adeptive root
filename= os.path.basename(__file__)
filename=filename.replace('.py','')

# class ClearRoot(object):
#     def __init__(self, filename):
#         self.path=''
#         print('app name var',__name__)
#         if  __name__ == 'Tools.Mrimporter':
#             filename='Botit DIY'
#             self.path="apps/"+filename+"/"

# myClearRoot=ClearRoot(filename)

import webview
import webbrowser
import requests, base64
import json
import configparser
import pyautogui
import win32api

import logging
import shutil
import base64
from PIL import Image
import io
import sys
from threading import Thread
from Tools.windowcapture import *
# from Tools.Login import LoginDB
from Tools.db import *
#from Tools.bots import *
from Tools.Newbot import *
from Tools.ui import *
import ctypes
import clipboard
from win32api import GetSystemMetrics
# from Tools.AppControl import *



# from . import ClearRoot
# print('after',myClearRoot.path)
#Init Set Vals
ifmode='None'
tmpactivefunc=''
UImain=''
codebuilder=''
botobject=''
loadtoggle=False





import json
#from main import Api
#from webview import window
#from client_config import ClientConfig
#api = Api()
class appui(object):
    bar = []
    indexerinit=0

    def __init__(self,window,APP_NAME,APP_VERSION,comp):
       self.window = window
       print("UI Start")
    #    print(client.APP_NAME,client.APP_VERSION)

       dict = {'appname': APP_NAME,'appver':APP_VERSION}
       self.topframe = ''' 
            <span class="title-bar pywebview-drag-region" ><strong>{appname}&nbsp;&nbsp;&nbsp;&nbsp; Ver:&nbsp;{appver}</strong></span>
            <span class="title-bar pywebview-drag-region"id="loadstat"><a class="flex"><img id="statusimg2" src="media/ststus/Done.png" height="25" width="25"> <strong id="titlestatus" class="ml-2">Get Data Done</strong></a></span>
            <span class="title-btn title-btn-discord" onclick="pywebview.api.bottbar('discord')" ><img title="Discord Server"  src="media/ststus/discord.svg" height="25" width="25"></span>
            <span class="title-btn title-btn-website" onclick="pywebview.api.bottbar('website')" ><img title="Botit DIY Site"  src="dist/images/icon.png" height="25" width="25"></span>
            <span class="title-btn" onclick="pywebview.api.topbar('mini')" >0</span>
            <span class="title-btn title-btn-full" onclick="pywebview.api.topbar('full')">1</span>
            <span class="title-btn title-btn-close" onclick="pywebview.api.topbar('close')" >r</span>
       '''.format(**dict)
       self.toputil = '''
            <div class="-intro-x breadcrumb mr-auto hidden sm:flex"> 

                        <div> 
                            <i style="font-weight: bold; color: white">Target Window:</i> 
                        </div>
                        <div class="search hidden sm:block ml-2">
                            <!-- BEGIN: Basic Select -->
                            <div>
                                                                
                                <div >
                                    <select  id="targetselect" class="form-select w-full">
                                    
                                    
                                    </select>

                                    </div>
                                </div>
                            <!-- END: Basic Select -->

                            
                        </div>
                        <button class="btn btn-warning mr-4" onclick="pywebview.api.refreshlist()"> <img  class="w-4 dark:text-gray-300" src="media/feather/refresh-cw.svg"/> </button>
                        
                    </div>
                   
                    <div class="intro-x relative mr-3 sm:mr-6">
                       
                       
                    </div>
                    
                    <div class="intro-x dropdown mr-auto sm:mr-6">
                        
                    </div>
                    
                   
                    <div class="side-nav__devider my-6"></div>
       '''
       self.topmain = '''
       '''
       self.main = '''
       <div class="intro-y flex items-center mt-8">
                    <h2 class="text-lg font-medium mr-auto">
                        Welcome To BotPlace Developer Tool
                    </h2>
                </div>
                <div class="grid grid-cols-12 gap-6 mt-5">
                    <!-- BEGIN: FAQ Menu -->
                    <a  class="intro-y col-span-12 lg:col-span-4 box py-10">
                        <i  class="block w-12 h-12 text-theme-1 dark:text-theme-10 mx-auto"><img src="media/submenu/apps.png"></i> 
                        <div class="font-medium text-center text-base mt-3">Code Free System</div>
                        <div class="text-gray-600 mt-2 w-3/4 text-center mx-auto">We Removed Any Coding Needed to Build Bots.</div>
                    </a>
                    <a  class="intro-y col-span-12 lg:col-span-4 box py-10">
                        <i  class="block w-12 h-12 text-theme-1 dark:text-theme-10 mx-auto"><img src="media/submenu/artificial-intelligence.png"></i> 
                        <div class="font-medium text-center text-base mt-3">Bot DIY Builder</div>
                        <div class="text-gray-600 mt-2 w-3/4 text-center mx-auto">Top of the Line Object System Support Ahk,Python.</div>
                    </a>
                    <a  class="intro-y col-span-12 lg:col-span-4 box py-10">
                        <i  class="block w-12 h-12 text-theme-1 dark:text-theme-10 mx-auto"><img src="media/submenu/protection.png"></i>                         <div class="font-medium text-center text-base mt-3">Web App Backups and Deploy</div>
                        <div class="text-gray-600 mt-2 w-3/4 text-center mx-auto">Save to the Cloud. Get your Data Anywhere!!</div>
                    </a>
                    <!-- END: FAQ Menu -->
                    <!-- BEGIN: FAQ Content -->
                    <div class="intro-y col-span-12 lg:col-span-6">
                        <div class="box">
                            <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                                <h2 class="font-medium text-base mr-auto">
                                    Working with Developer Tool
                                </h2>
                            </div>
                            <div id="faq-accordion-1" class="accordion p-5">
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-1" class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-1" aria-expanded="true" aria-controls="faq-accordion-collapse-1"> Data1 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-1" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-content-1" data-bs-parent="#faq-accordion-1">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">Data1 Accordion </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-2" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-2" aria-expanded="false" aria-controls="faq-accordion-collapse-2"> Data2 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-2" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-2" data-bs-parent="#faq-accordion-1">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Data2 Accordion </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-3" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-3" aria-expanded="false" aria-controls="faq-accordion-collapse-3"> Data3 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-3" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-3" data-bs-parent="#faq-accordion-1">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Data3 Accordion</div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-4" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-4" aria-expanded="false" aria-controls="faq-accordion-collapse-4"> Data4 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-4" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-4" data-bs-parent="#faq-accordion-1">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Data4 Accordion </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="intro-y col-span-12 lg:col-span-6">
                        <div class="box">
                            <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                                <h2 class="font-medium text-base mr-auto">
                                    System Information
                                </h2>
                            </div>
                            <div id="faq-accordion-3" class="accordion p-5">
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-1" class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-9" aria-expanded="true" aria-controls="faq-accordion-collapse-9"> Data5 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-9" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-content-1" data-bs-parent="#faq-accordion-3">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Info</div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-2" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-10" aria-expanded="false" aria-controls="faq-accordion-collapse-10"> Data6 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-10" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-2" data-bs-parent="#faq-accordion-3">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Info</div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-3" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-11" aria-expanded="false" aria-controls="faq-accordion-collapse-11"> Data7 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-11" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-3" data-bs-parent="#faq-accordion-3">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Info</div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-4" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-12" aria-expanded="false" aria-controls="faq-accordion-collapse-12"> Data8 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-12" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-4" data-bs-parent="#faq-accordion-3">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Info</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <!-- END: FAQ Content -->
                </div>
       '''
       print('UI done')

    def setdata(self):
        if self.indexerinit==0:
            dict = {'topf': self.topframe,'util':self.toputil,'maintop':self.topmain}
            self.window.evaluate_js("""
                document.getElementById('topframe').innerHTML = `{topf}`;
                document.getElementById('utilbar').innerHTML = `{util}`;
                document.getElementById('mainhead').innerHTML = `{maintop}`;
                """.format(**dict))
            self.indexerinit=+1
            print(self.indexerinit)
            return

        dict = {'topf': self.topframe,'util':self.toputil,'maintop':self.topmain}
        self.window.evaluate_js("""
           document.getElementById('topframe').innerHTML = `{topf}`;
           document.getElementById('utilbar').innerHTML = `{util}`;
           document.getElementById('mainhead').innerHTML = `{maintop}`;
           document.getElementById('mainapp').innerHTML = `{maintop}`;
            """.format(**dict))

    def senddata(self,mode,zone,data):
        # print('setdata Func',mode,zone,data)
        #print(data)
        try:
            dict = {'mod': mode,'zoner':zone,'dater':data}
            if mode == "Clear":
                self.window.evaluate_js("""
                document.getElementById('{zoner}').innerHTML = ``;
                    """.format(**dict))
            if mode == "Set":
                self.window.evaluate_js("""
                document.getElementById('{zoner}').innerHTML = `{dater}`;
                    """.format(**dict))
        except: print('data set failed')
            
    def maintop(self,mode,active):
        
        if mode == "Objects":
            #print('this is active',active)
            dict = {'mode':active}
            self.topmain = '''
            <div class="flex box flex-wrap "> <a data-toggle="modal" data-target="#modall" ><img title="Add Selected To Mode" onclick="pywebview.api.addtomode()" class="mr-2" src="media/submenu/add.svg"  height="50" width="50" />  </a> <img title="Remove Selected From Mode"  src="media/modes/remove.svg" height="50" width="50" onclick="pywebview.api.objaddremove('{mode}','removefrommode')" class="ml-2"></div> 
            '''.format(**dict)
          #  print(self.topmain)
        if mode == "Modes":
            self.topmain = '''
            <div class="flex box flex-wrap "> <a ><img title="Remove Selected From Mode"  src="media/modes/remove.svg" height="50" width="50" onclick="pywebview.api.objaddremove('modes','modes')" class="ml-2"> </a> </div> 
            '''

        if mode == "Total":
            self.topmain = '''
            <div class="flex box flex-wrap ">  <img title="Remove Selected From DB"  src="media/modes/remove.svg" height="50" width="50" onclick="pywebview.api.objaddremove('DB','removefromDB')" class="ml-2"></div>
            '''
        if mode == "Editor":
            self.topmain = '''
            <div class="flex box flex-wrap"> 
            <a class="flex" data-toggle="modal" data-target="#modall" onclick="pywebview.api.functiontop('Image')" style="cursor: pointer;"> <img src="media/submenu/picture.svg" height="50" width="50" class="mr-1"/><strong class="mt-3 mr-4">Image</strong></a> 
            <a class="flex" data-toggle="modal" data-target="#modall" onclick="pywebview.api.functiontop('Pixel')" style="cursor: pointer;"> <img src="media/submenu/pixels.svg" height="50" width="50" class="mr-1"/><strong class="mt-3 mr-4">Pixel</strong> </a> 
            <a class="flex" data-toggle="modal" data-target="#modall" onclick="pywebview.api.functiontop('Function')" style="cursor: pointer;"> <img src="media/submenu/function.svg" height="50" width="50" class="mr-1"/><strong class="mt-3 mr-4">Functions</strong> </a> 
            <a class="flex" data-toggle="modal" data-target="#modall" onclick="pywebview.api.functiontop('Clicks')" style="cursor: pointer;"> <img src="media/editor/030-clicking.svg" height="50" width="50" class="mr-1"/><strong class="mt-3 mr-4">Clicks</strong> </a> 
            <a class="flex" data-toggle="modal" data-target="#modall" onclick="pywebview.api.functiontop('Keys')" style="cursor: pointer;"> <img src="media/editor/keyboard.svg" height="50" width="50" class="mr-1"/><strong class="mt-3 mr-4">keys</strong> </a> 
            <a class="flex" data-toggle="modal" data-target="#modall" onclick="pywebview.api.functiontop('Sleep')" style="cursor: pointer;"> <img src="media/editor/039-sand-clock.svg" height="50" width="50" class="mr-1"/><strong class="mt-3 mr-4">Sleep</strong> </a> 
            <a class="flex" data-toggle="modal" data-target="#modall" onclick="pywebview.api.functiontop('Loops')" style="cursor: pointer;"> <img src="media/editor/loop.svg" height="50" width="50" class="mr-1"/><strong class="mt-3 mr-4">Loops</strong></a>
            </div> 
            '''
    
    def appHome(self):
        print('Im home')
        self.Homemain = '''
        <div>
        <div class="intro-y flex items-center mt-8">
                    <h2 class="text-lg font-medium mr-auto" style="color:white">
                        Welcome To BotPlace Developer Tool
                    </h2>
                </div>
                <div class="grid grid-cols-12 gap-6 mt-5">
                    <!-- BEGIN: FAQ Menu -->
                    <a  class="intro-y col-span-12 lg:col-span-4 box py-10">
                        <i  class="block w-12 h-12 text-theme-1 dark:text-theme-10 mx-auto"><img src="media/submenu/apps.png"></i> 
                        <div class="font-medium text-center text-base mt-3">Code Free System</div>
                        <div class="text-gray-600 mt-2 w-3/4 text-center mx-auto">We Removed Any Coding Needed to Build Bots.</div>
                    </a>
                    <a  class="intro-y col-span-12 lg:col-span-4 box py-10">
                        <i  class="block w-12 h-12 text-theme-1 dark:text-theme-10 mx-auto"><img src="media/submenu/artificial-intelligence.png"></i> 
                        <div class="font-medium text-center text-base mt-3">Bot DIY Builder</div>
                        <div class="text-gray-600 mt-2 w-3/4 text-center mx-auto">Top of the Line Object System Support Ahk,Python.</div>
                    </a>
                    <a  class="intro-y col-span-12 lg:col-span-4 box py-10">
                        <i  class="block w-12 h-12 text-theme-1 dark:text-theme-10 mx-auto"><img src="media/submenu/protection.png"></i>                         <div class="font-medium text-center text-base mt-3">Web App Backups and Deploy</div>
                        <div class="text-gray-600 mt-2 w-3/4 text-center mx-auto">Save to the Cloud. Get your Data Anywhere!!</div>
                    </a>
                    <!-- END: FAQ Menu -->
                    <!-- BEGIN: FAQ Content -->
                    <div class="intro-y col-span-12 lg:col-span-6">
                        <div class="box">
                            <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                                <h2 class="font-medium text-base mr-auto" style="color:white">
                                    Working with Developer Tool
                                </h2>
                            </div>
                            <div id="faq-accordion-1" class="accordion p-5">
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-1" class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-1" aria-expanded="true" aria-controls="faq-accordion-collapse-1"> Data1 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-1" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-content-1" data-bs-parent="#faq-accordion-1">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">Data1 Accordion </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-2" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-2" aria-expanded="false" aria-controls="faq-accordion-collapse-2"> Data2 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-2" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-2" data-bs-parent="#faq-accordion-1">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Data2 Accordion </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-3" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-3" aria-expanded="false" aria-controls="faq-accordion-collapse-3"> Data3 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-3" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-3" data-bs-parent="#faq-accordion-1">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Data3 Accordion</div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-4" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-4" aria-expanded="false" aria-controls="faq-accordion-collapse-4"> Data4 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-4" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-4" data-bs-parent="#faq-accordion-1">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Data4 Accordion </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="intro-y col-span-12 lg:col-span-6">
                        <div class="box">
                            <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                                <h2 class="font-medium text-base mr-auto" style="color:white">
                                    System Information
                                </h2>
                            </div>
                            <div id="faq-accordion-3" class="accordion p-5">
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-1" class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-9" aria-expanded="true" aria-controls="faq-accordion-collapse-9"> Data5 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-9" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-content-1" data-bs-parent="#faq-accordion-3">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Info</div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-2" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-10" aria-expanded="false" aria-controls="faq-accordion-collapse-10"> Data6 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-10" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-2" data-bs-parent="#faq-accordion-3">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Info</div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-3" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-11" aria-expanded="false" aria-controls="faq-accordion-collapse-11"> Data7 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-11" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-3" data-bs-parent="#faq-accordion-3">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Info</div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <div id="faq-accordion-content-4" class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-12" aria-expanded="false" aria-controls="faq-accordion-collapse-12"> Data8 </button>
                                    </div>
                                    <div id="faq-accordion-collapse-12" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-4" data-bs-parent="#faq-accordion-3">
                                        <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed"> Info</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <!-- END: FAQ Content -->
                </div>
        </div>
       '''
    
    def botcardmaker(self,mode,bar):
            print('in card maker')
            divgroup=''
            if mode=="Bots":
                print('card bots',bar)
                try:
                    for item in bar:
                        print(item)
                        json_data=open("DB/"+item+".json")
                        jdata = json.load(json_data)
                        # try:
                        #     print(jdata["Settings"][0]['thumburl'],jdata["Settings"][0]['botname'])
                        # except:print(item,'Error')
                        dict = {'imgurl': jdata["Settings"][0]['thumburl'],'name':item}
                        
                        divchanger = '''
                                        
                        <div class="brick large">
                            <a data-toggle="modal" data-target="#modals" onclick="pywebview.api.loadbot('{name}','loadbot')"> <img class="rounded-md mr-auto ml-auto"  title="{name}"  src="{imgurl}" height="220" width="220" ><a/>
                            <div class="flex">
                                <!-- BEGIN: Header & Footer Slide Over -->
                                <div class="intro-y  mb-1">
                                    <div id="header-footer-slide-over" class="p-2">
                                        <div class="preview">
                                            <div class="text-center"> <a  data-toggle="modal"  data-target="#sidemodal" onclick="pywebview.api.botsidemenu('{name}')" class="btn btn-primary ml-5">Edit Bot</a> </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="intro-y  mb-1">
                                    <div id="header-footer-slide-over" class="p-2">
                                        <div class="preview">
                                            <div class="text-center"> <a  data-toggle="modal" data-target="#modals" onclick="pywebview.api.loadbot('{name}','loadbot')" class="btn btn-danger">Pick Bot</a> </div>
                                        </div>
                                    </div>
                                </div>


                                
                            </div>
                        </div> '''.format(**dict)
                        divgroup = divgroup + divchanger
                    self.cards=divgroup
                    json_data.close()
                except:
                    self.cards='<div class="text-center"> Oops no bots detected. Add new Bot</div>'
            
            if mode=="Modes":
               
                modedata = bar
               
                if modedata ==[]:
                   print('null')
                   self.cards=""
                   return
             #  print("data print",modedata)
                tmpdata=""
                print('my mode data',modedata)
                for p in modedata:
                   # print(p)
                    
                    for key in p:
                    #print(key)
                        dict = {'name':key}
                        gamediv = ''' 
                                <div class="intro-y ml-2  brick large">
                                            <div class="file box rounded-md px-5 pt-8 pb-5 px-3 sm:px-5 relative ">
                                                <div class="absolute left-0 top-0 mt-3 ml-3">
                                                    <input class="form-check-input border border-gray-500" id="{name}moddel" type="checkbox">
                                                </div>
                                                    <a class="w-3/5 file__icon file__icon--image mx-auto">
                                                    <div class="file__icon--image__preview image-fit">
                                                        <img src="media/modes/data-collection.svg"  onclick="pywebview.api.objectscards('{name}')" height="200" width="200">
                                                    </div>
                                                
                                                    
                                                </a>
                                                <a  class="block font-medium mt-4 text-center ">{name}</a> 
                                                
                                                <div class="absolute top-0 right-0 mr-2 mt-2 dropdown ml-auto">
                                                    <a class="dropdown-toggle w-5 h-5 block"  aria-expanded="false"> <img  src="media/modes/settings.svg" class="w-5 h-5 text-gray-600"> </a>
                                                    <div class="dropdown-menu w-40">
                                                        <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                                            <a  class="flex items-center block  p-2 transition duration-50 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"  data-dismiss="dropdown" data-toggle="modal" data-target="#sidemodal" onclick="pywebview.api.modesubmenu('{name}')"> <img  src="media/modes/ninja.svg" class="w-8 h-8 mr-2"> Tier Setting </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                '''.format(**dict)
                        tmpdata= tmpdata + gamediv
                self.cards=tmpdata

            if mode=="Objects":
                print('Objects')
             
                targetwidth=bar.wid
                targetheight=bar.heig
                indexer = 0
                tmpdata2=""
                print(bar.objlist)
                try:
                    for key in bar.modeobjecets:
                        bar.ActiveObj(key)
                        if bar.Aobjtype == "Image":
                            rawimg=''
                            if bar.Aobjcolorstring == "":
                                if bar.Aobjgraystring == "":
                                    tmpdiv='''<img  src="media/submenu/picture.svg">'''
                                    dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':''}
                                else:
                                    rawimg=bar.Aobjgraystring
                                    dict = {'imgbase64':bar.Aobjgraystring}
                                    tmpdiv='''<img  src="data:image/png;base64,{imgbase64}">'''.format(**dict)
                                    
                                    dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                                    
                            else:
                                rawimg=bar.Aobjcolorstring
                                dict = {'imgbase64':bar.Aobjcolorstring}
                                tmpdiv='''<img  src="data:image/png;base64,{imgbase64}">'''.format(**dict)
                                dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}

                            # onclick="pywebview.api.editobj('{objname}','{type}','{targetwidth}','{targetheight}','{img}')"  onclick="pywebview.api.objsubmenu('{objname}','{type}')"
                            #print(dict)
                        if bar.Aobjtype == "Pixel":
                            #print('pix')
                            rawimg=''
                            if bar.pixelcolor == "":
                                x=''
                                dict = {'pixelcolor':x}
                                tmpdiv='''<div style="width:60px;height:60px;background-color: #{pixelcolor};"></div>'''.format(**dict)
                            else:
                                try:
                                    x = bar.pixelcolor.replace("0x", "")
                                    rawimg=bar.pixelcolor
                                    dict = {'pixelcolor':x}
                                    tmpdiv='''<div style="width:60px;height:60px;background-color: #{pixelcolor};"></div>'''.format(**dict)
                                except:
                                    x=''
                                    dict = {'pixelcolor':x}
                                    tmpdiv='''<div style="width:60px;height:60px;background-color: #{pixelcolor};"></div>'''.format(**dict)
                            dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                        if bar.Aobjtype == "Func":
                            rawimg=''
                            tmpdiv='''<img  src="media/submenu/function.svg">'''
                            dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                        if bar.Aobjtype == "UIFunc":
                            rawimg=''
                            tmpdiv='''<img  src="media/submenu/UI.png">'''
                            dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                        
                        #func change Div
                        if bar.Aobjtype == "Func" or bar.Aobjtype == "UIFunc":
                            divchanger = '''
                                    <div class="intro-y p-2 brick small">
                                        <div class="file box rounded-md px-5 pt-8 pb-5 px-3 sm:px-5 relative ">
                                            <div class="absolute left-0 top-0 mt-3 ml-3">
                                                <input class="form-check-input border border-gray-500" id="{objname}modchk" type="checkbox">
                                            </div>
                                            <a  class="w-3/5 file__icon file__icon--image mx-auto" onclick="pywebview.api.objsubmenu('{nameraw}')"  data-toggle="modal" data-target="#sidemodal">
                                                <div class="file__icon--image__preview image-fit" >
                                                    {media}
                                                    
                                                </div>
                                            </a>
                                            <a  class="block font-medium mt-4 text-center "> {objname} </a> 
                                            
                                            
                                        </div>
                                        <div class="intro-y  ">
                                            <div class="p-2">
                                                <div >
                                                    <div class="text-center"> <a   onclick="pywebview.api.funcedit('{objname}')" class="btn rounded-full border border-theme-12 text-theme-12 dark:border-theme-12"><img  src="media/modes/photo-editing.svg" class="w-4 h-4 mr-2">Edit</a> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                        '''.format(**dict)
                        
                        

                        
                        else:
                        
                            divchanger = '''
                                    <div class="intro-y p-2  brick small">
                                        <div class="file box rounded-md px-5 pt-8 pb-5 px-3 sm:px-5 relative ">
                                            <div class="absolute left-0 top-0 mt-3 ml-3">
                                                <input class="form-check-input border border-gray-500" id="{objname}modchk" type="checkbox">
                                            </div>
                                            <a  class="w-3/5 file__icon file__icon--image mx-auto" onclick="pywebview.api.objsubmenu('{nameraw}')"  data-toggle="modal" data-target="#sidemodal">
                                                <div class="file__icon--image__preview image-fit" >
                                                    {media}
                                                    
                                                </div>
                                            </a>
                                            <a  class="block font-medium mt-4 text-center "> {objname} </a> 
                                            
                                            <div class="absolute top-0 right-0 mr-2 mt-2 dropdown ml-auto">
                                                <a class="dropdown-toggle w-5 h-5 block"  aria-expanded="false"> <img  src="media/modes/settings.svg" class="w-5 h-5 text-gray-600"> </a>
                                                <div class="dropdown-menu w-40">
                                                    <div class="dropdown-menu__content box dark:bg-dark-1 p-2 ">
                                                        <a   class="dropdown-toggle flex items-center block p-2 transition duration-50 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md" data-dismiss="dropdown" onclick="pywebview.api.editobj('{nameraw}','{imgraw}')"  aria-expanded="false" data-toggle="modal"  data-target="#modall"> <img  src="media/modes/photo-editing.svg" class="w-8 h-8 mr-2"> Edit </a>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="intro-y  ">
                                            <div class="p-2">
                                                <div >
                                                    <div class="text-center"> <a  onclick="pywebview.api.editobj('{nameraw}','{imgraw}')" aria-expanded="false" data-toggle="modal"  data-target="#modall" class="btn rounded-full border border-theme-12 text-theme-12 dark:border-theme-12"><img  src="media/modes/photo-editing.svg" class="w-4 h-4 mr-2">Edit</a> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                        '''.format(**dict)
                            
                            #print(bar.objs[tmp1][tmp][0])

                        
                        tmpdata2= tmpdata2 + divchanger
                    self.cards=tmpdata2
                except:
                    self.cards=''
                    print('no objects Detected')
           
            if mode=="Total":
                print("total")
                targetwidth=bar.wid
                targetheight=bar.heig
                indexer = 0
                tmpdata2=""

                #print(bar.modeobjecets)
               # print(bar.objlist)
                try:
                    for key in bar.objlist:   
                        bar.ActiveObj(key)
                    # print('done active')
                    # print(bar.activeobjectname,bar.Aobjtype)
                        if bar.Aobjtype == "Image":
                            #print(bar.Aobjtype)
                            rawimg=''
                            if bar.Aobjcolorstring == "":
                                if bar.Aobjgraystring == "":
                                    tmpdiv='''<img  src="media/submenu/picture.svg">'''
                                    dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':''}
                                else:
                                    rawimg=bar.Aobjgraystring
                                    dict = {'imgbase64':bar.Aobjgraystring}
                                    tmpdiv='''<img  src="data:image/png;base64,{imgbase64}">'''.format(**dict)
                                    dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                            else:
                                rawimg=bar.Aobjcolorstring
                                dict = {'imgbase64':bar.Aobjcolorstring}
                                tmpdiv='''<img  src="data:image/png;base64,{imgbase64}">'''.format(**dict)
                                dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                            # onclick="pywebview.api.editobj('{objname}','{type}','{targetwidth}','{targetheight}','{img}')"  onclick="pywebview.api.objsubmenu('{objname}','{type}')"
                            #print(dict)
                        if bar.Aobjtype == "Pixel":
                            #print('pix')
                            rawimg=''
                            if bar.pixelcolor == "":
                                x=''
                                dict = {'pixelcolor':x}
                                tmpdiv='''<div style="width:60px;height:60px;background-color: #{pixelcolor};"></div>'''.format(**dict)
                            else:
                                try:
                                    x = bar.pixelcolor.replace("0x", "")
                                    rawimg=bar.pixelcolor
                                    dict = {'pixelcolor':x}
                                    tmpdiv='''<div style="width:60px;height:60px;background-color: #{pixelcolor};"></div>'''.format(**dict)
                                except:
                                    x=''
                                    dict = {'pixelcolor':x}
                                    tmpdiv='''<div style="width:60px;height:60px;background-color: #{pixelcolor};"></div>'''.format(**dict)
                            dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                        if bar.Aobjtype == "Func":
                        # print('func found')
                            rawimg=''
                            tmpdiv='''<img  src="media/submenu/function.svg">'''
                            dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}

                        if bar.Aobjtype == "UIFunc":
                        # print('func found')
                            rawimg=''
                            tmpdiv='''<img  src="media/submenu/UI.png">'''
                            dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                        #print(dict)
                    #  print("after type",bar.Aobjtype )

                        if bar.Aobjtype == "Func" or bar.Aobjtype == "UIFunc":

                        # print("if 2 func")
                            divchanger = '''
                                    <div class="intro-y p-2 brick small">
                                        <div class="file box rounded-md px-5 pt-8 pb-5 px-3 sm:px-5 relative ">
                                            <div class="absolute left-0 top-0 mt-3 ml-3">
                                                <input class="form-check-input border border-gray-500" id="{objname}chktotal" type="checkbox">
                                            </div>
                                            <a  class="w-3/5 file__icon file__icon--image mx-auto" onclick="pywebview.api.objsubmenu('{nameraw}')"  data-toggle="modal" data-target="#sidemodal">
                                                <div class="file__icon--image__preview image-fit" >
                                                    {media}
                                                    
                                                </div>
                                            </a>
                                            <a  class="block font-medium mt-2 text-center "> {objname} </a> 

                                            
                                        </div>
                                        <div class="intro-y  ">
                                            <div class="p-2">
                                                <div >
                                                    <div class="text-center"> <a onclick="pywebview.api.funcedit('{objname}')" class="btn rounded-full border border-theme-12 text-theme-12 dark:border-theme-12"><img  src="media/modes/photo-editing.svg" class="w-4 h-4 mr-2">Edit</a> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                        '''.format(**dict)
                        
                            
                        #dict = {'objname':dat,'type':typer,'objtype':test3,'index':objindextmp,'targetwidth':targetwidth,'targetheight':targetheight,'img':imgstring}
                        else:
                        # print("No func")
                            divchanger = '''
                                    <div class="intro-y p-2 brick small">
                                        <div class="file box rounded-md px-5 pt-8 pb-5 px-3 sm:px-5 relative ">
                                            <div class="absolute left-0 top-0 mt-3 ml-3">
                                                <input class="form-check-input border border-gray-500" id="{objname}chktotal" type="checkbox">
                                            </div>
                                            <a  class="w-3/5 file__icon file__icon--image mx-auto" onclick="pywebview.api.objsubmenu('{nameraw}')"  data-toggle="modal" data-target="#sidemodal">
                                                <div class="file__icon--image__preview image-fit" >
                                                    {media}
                                                    
                                                </div>
                                            </a>
                                            
                                            <a  class="block font-medium mt-2 text-center "> {objname} </a> 
                                            <div class="absolute top-0 right-0 mr-2 mt-2 dropdown ml-auto">
                                                <a class="dropdown-toggle w-5 h-5 block"  aria-expanded="false"> <img  src="media/modes/settings.svg" class="w-5 h-5 text-gray-600"> </a>
                                                <div class="dropdown-menu w-40">
                                                    <div class="dropdown-menu__content box dark:bg-dark-1 p-2 ">
                                                        <a   class="dropdown-toggle flex items-center block p-2 transition duration-50 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md" data-dismiss="dropdown" onclick="pywebview.api.editobj('{nameraw}','{imgraw}')"  aria-expanded="false" data-toggle="modal"  data-target="#modall"> <img  src="media/modes/photo-editing.svg" class="w-8 h-8 mr-2"> Edit </a>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                       <div class="intro-y  ">
                                            <div class="p-2">
                                                <div >
                                                    <div class="text-center"> <a  onclick="pywebview.api.editobj('{nameraw}','{imgraw}')" aria-expanded="false" data-toggle="modal"  data-target="#modall" class="btn rounded-full border border-theme-12 text-theme-12 dark:border-theme-12"><img  src="media/modes/photo-editing.svg" class="w-4 h-4 mr-2">Edit</a> </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                    </div>

                                    

                                        '''.format(**dict)
                    #  print(divchanger)
                        tmpdata2= tmpdata2 + divchanger
                    
                    dict = {'datait':tmpdata2}
                    
                    tmpdata2 = '''
                    <div class="scoller">
                    {datait}
                    </div>
                    '''.format(**dict)
                    #print(tmpdata2)
                    self.cards=tmpdata2 
                
                except:
                    self.cards=''
            
            if mode=="TotalFunc":
                print("total func")
                tmpdata2=""
                for key in bar.objlist:
                  #  print(key)
                    bar.ActiveObj(key)
                   
                   # print('done active')
                   # print(bar.activeobjectname,bar.Aobjtype)
                    if bar.Aobjtype == "Func":
                       
                        rawimg=''
                        tmpdiv='''<img  src="media/submenu/function.svg">'''
                        dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                        divchanger = '''
                                <div class="intro-y  brick small">
                                    <div class="file box rounded-md px-5 pt-8 pb-5 px-3 sm:px-5 relative ">
                                        
                                        <a  class="w-3/5 file__icon file__icon--image mx-auto" onclick="pywebview.api.funcedit('{objname}')" >
                                            <div class="file__icon--image__preview image-fit" >
                                                {media}
                                                
                                            </div>
                                        </a>
                                        <a  class="block font-medium mt-4 text-center "> {objname} </a> 
                                        
                                        
                                    </div>
                                </div>
                                
                                    '''.format(**dict)
                    elif bar.Aobjtype == "UIFunc":
                       
                        rawimg=''
                        tmpdiv='''<img  src="media/submenu/UI.png">'''
                        dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                        divchanger = '''
                                <div class="intro-y  brick small">
                                    <div class="file box rounded-md px-5 pt-8 pb-5 px-3 sm:px-5 relative ">
                                        
                                        <a  class="w-3/5 file__icon file__icon--image mx-auto" onclick="pywebview.api.funcedit('{objname}')" >
                                            <div class="file__icon--image__preview image-fit" >
                                                {media}
                                                
                                            </div>
                                        </a>
                                        <a  class="block font-medium mt-4 text-center "> {objname} </a> 
                                        
                                        
                                    </div>
                                </div>
                                
                                    '''.format(**dict)

                    else:
                        continue
                    tmpdata2= tmpdata2 + divchanger
                self.cards=tmpdata2    

    def Sidemenu(self,mode,botobject):
        if mode == "Bot":
            
            dict = {'namer':botobject.name}
            self.sidehead = '''
                <i id="botsubname" class="font-medium text-base mr-auto">
                    {namer}
                </i>
                <button class="btn btn-danger data-dismiss="modal" hidden sm:flex" onclick="pywebview.api.pushtoapplocal()" data-dismiss="modal"> <img  class="w-8 mr-3 " src="media/submenu/big-data.svg" / >  Save Bot Seed </button>
             '''.format(**dict)
            
            

            freedata=''
            silverdata=''
            golddata=''
            # dict = {'botname':botobject.name,'botver': botobject.version, 'botimgver': botobject.imgversion, 'targetwidth': botobject.wid,
            # 'targetheight': botobject.heig,'thumburl': botobject.thumb,'dev': botobject.developer,
            # 'free': freedata,'silver':silverdata,'gold':golddata,'public':botobject.public}
            dict = {'botname':botobject.name,'botver': botobject.version, 'botimgver': botobject.imgversion, 'targetwidth': botobject.wid,
            'targetheight': botobject.heig,'thumburl': botobject.thumb,'dev': botobject.developer,
            'free': freedata,'silver':silverdata,'gold':golddata,'public':True}
            #print(bar.public)
            #print(sysid)
            self.sidebody = '''
                <div class="flex">
                    <div>
                        <img src="media/editbot/control-panel.svg" alt="" width="40" height="40" />
                        
                    </div>
                    <span class="ml-2">System</span>
                    <select id="botsubsys" class="form-select ml-2" aria-label="Select System">
                        <option>Nox</option>
                        <option>Bluestacks</option>
                        <option>Chrome</option>
                        <option>Human</option>
                    </select>
                        
                </div>
                <div class="flex mt-2">
                    <div>
                        <img src="media/editbot/history.svg" alt="" width="40" height="40" />
                        
                    </div>
                    <span class="ml-2">Version</span>
                    <input id="botsubver" value="{botver}" type="text" class="form-control ml-2" placeholder="Edit Version">
                        
                </div>
                <div class="flex mt-2">
                    <div>
                        <img src="media/editbot/video-game.svg" alt="" width="40" height="40" />
                        
                    </div>
                    <span class="ml-2">Image Ver</span>
                    <input id="botsubimgver" value="{botimgver}" type="text" class="form-control ml-1" placeholder="Edit Version">
                        
                </div>
                <div class="flex mt-2">
                    <div>
                        <img src="media/editbot/app.svg" alt="" width="40" height="40" />
                        
                    </div>
                    <span class="ml-2">Bot Width</span>
                    <input id="botsubwid" value="{targetwidth}" type="text" class="form-control ml-2" placeholder="Edit Version">
                        
                </div>
                <div class="flex mt-2">
                    <div>
                        <img src="media/editbot/monitor-height.svg" alt="" width="40" height="40" />
                        
                    </div>
                    <span class="ml-2">Bot Height</span>
                    <input id="botsubhei" value="{targetheight}" type="text" class="form-control ml-2" placeholder="Edit Version">
                        
                </div>
                <div class="flex mt-2">
                    <div>
                        <img src="media/editbot/022-3d.svg" alt="" width="40" height="40" />
                        
                    </div>
                    <span class="ml-2">Image URL</span>
                    <input id="botsubthum" value="{thumburl}" type="text" class="form-control ml-2" placeholder="Edit Version">
                        
                </div>
                <div class="flex mt-2">
                    <div>
                        <img src="media/editbot/bronze.svg" alt="" width="30" height="30" />
                        
                    </div>
                    <label for="modal-form-4" class="form-label ml-2">Free Modes</label>
                    <div id="selectMultiple"  class="ml-2 flex-wrap">
                        {free}
                    </div>
                        
                </div>
                <div class="flex mt-2">
                    <div>
                        <img src="media/editbot/silver.svg" alt="" width="30" height="30" />
                        
                    </div>
                    <label for="modal-form-4 " class="form-label ml-2">Silver Modes</label>
                    <div id="selectMultiple2"  class="ml-2 flex-wrap">
                        {silver}
                    </div>
                        
                </div>
                <div class="flex mt-2">
                    <div>
                        <img src="media/editbot/gold.svg" alt="" width="30" height="30" />
                        
                    </div>
                    <label for="modal-form-4 " class="form-label ml-2">Gold Modes</label>
                    <div id="selectMultiple3"  class="ml-2 flex-wrap">
                        {gold}
                    </div>
                        
                </div>
              
             '''.format(**dict)
            self.sidefoot = ''' 
            <div><button type="button" data-dismiss="modal" class="btn btn-outline-secondary w-20 mr-1">Cancel</button></div>
                <div id="savesidebot">
                    
                    <button  data-dismiss="modal" type="button" onclick="pywebview.api.sidesave('BotSettings','')" class="btn btn-primary w-20">Save</button>
                </div>
            '''

        if mode == "Mode":
            #print(botobject.activemodename)
            dict = {'namer':botobject.activemodename}
            self.sidehead = '''
                <div  class="text-center mr-auto ml-auto mt-2">
                            <a>
                                <span class="px-4 py-3 rounded-full bg-theme-1 text-white mr-1">{namer}</span>
                            
                            </a>
                    </div>
             '''.format(**dict)
           # print(botobject.activefree,botobject.activesilver,botobject.activegold)
            self.sidebody = '''
                <div class="flex mt-2">
                                <div>
                                    <img src="media/editbot/bronze.svg" alt="" width="30" height="30" />
                                    
                                </div>
                                <label for="modal-form-4" class="form-label ml-2">Free Allowed</label>
                                <input class="ml-3 mb-2" id="addfree" class="form-check-input" type="checkbox">
                                
                            </div>

                            
                            <div class="flex mt-2">
                                <div>
                                    <img src="media/editbot/silver.svg" alt="" width="30" height="30" />
                                    
                                </div>
                                <label for="modal-form-4 " class="form-label ml-2">Silver Allowed</label>
                                <input class="ml-3 mb-2" id="addsilver" class="form-check-input" type="checkbox">
                                
                            </div>

                            
                            <div class="flex mt-2">
                                <div>
                                    <img src="media/editbot/gold.svg" alt="" width="30" height="30" />
                                    
                                </div>
                                <label for="modal-form-4 " class="form-label ml-2">Gold Allowed</label>
                                <input class="ml-3 mb-2" id="addgold" class="form-check-input" type="checkbox">
                                
                            </div> 
             '''
            self.sidefoot = ''' 
            <div>
            <button type="button" data-dismiss="modal" class="btn btn-outline-secondary w-20 mr-1">Cancel</button></div>
                <div id="savesidebot">
                    
                    <button  type="button" data-dismiss="modal" onclick="pywebview.api.sidesave('ModeSettingSave','')" class="btn btn-primary w-20">Save</button>
                </div>
            '''
    
        if mode == "Object":
            if botobject.Aobjtype == "Image":

                if botobject.Aobjcolorstring =="":
                    colorc="media/submenu/picture.svg"
                else:
                    dict = {'imgbase64':botobject.Aobjcolorstring}                  
                    colorc="data:image/png;base64,{imgbase64}".format(**dict)
                
                if botobject.Aobjgraystring =="":
                    grayc="media/submenu/picture.svg"
                else:
                    dict = {'imgbase64':botobject.Aobjgraystring}                  
                    grayc="data:image/png;base64,{imgbase64}".format(**dict)


                dict = {'objname':botobject.activeobjectname,'color':colorc,'gray':grayc}
                self.sidehead = '''
                    <div  class="text-center mr-auto ml-auto mt-2">
                            <a>
                                <span class="px-4 py-3 rounded-full bg-theme-1 text-white mr-1">{objname}</span>
                            
                            </a>
                            <a  class="flex gap-5 mt-5">
                                    <div class="box mr-5">
                                    Color
                                    <img  src="{color}" style="max-width:100px;width:100%" class="mt-3">
                                    </div>
                                    <div class="box ml-5">
                                    Grayscale
                                    <img  src="{color}"  style="max-width:100px;width:100%" class="mt-3 gray">
                                    </div>
                                    
                                    
                                </a>

                        </div>
                '''.format(**dict)

            

                dict = {'name':botobject.activeobjectname,'type': botobject.Aobjtype,'tol':botobject.Aobjtol, 'scan': botobject.Aobjscan, 'color': botobject.Aobjcolor,
                'clicks': botobject.Aobjclicks,'x1': botobject.Aobjx1,'y1': botobject.Aobjy1,
                'x2': botobject.Aobjx2,'y2':botobject.Aobjy2,'stringcolor':botobject.Aobjcolorstring,'stringgray':botobject.Aobjgraystring}
                self.sidebody = '''
                    <div class="modal-body">
                        <div class="flex">
                            <div>
                                <img src="media/objectmenu/edit.svg" alt="" width="40" height="40" />
                                
                            </div>
                                <span class="ml-2">Scan Type:</span>
                                <select id="objecttype" class="form-select ml-2" aria-label="Select System">
                                    <option>Area</option>
                                    <option>Window</option>
                                </select>
                        </div>
                    <div class="flex mt-2">
                            <div>
                                <img src="media/objectmenu/color-circle.svg" alt="" width="40" height="40" />
                                
                            </div>
                            <span  class="ml-2">Scan Color:</span>
                            <select id="objectcolor" class="form-select ml-2" aria-label="Select System">
                                <option>Color</option>
                                <option>Grayscale</option>
                                </select>
                    </div>

                    <div class="flex mt-2">
                            <div>
                                <img src="media/objectmenu/tap.svg" alt="" width="40" height="40" />
                                
                            </div>
                            <span class="ml-2">Click Options:</span>
                            <select id="objectclick" value="" class="form-select ml-2" aria-label="Select System">
                                <option>Click</option>
                                <option>No Click</option>
                                </select>
                    </div>

                    <div class="flex mt-2">
                            <div>
                                <img src="media/objectmenu/transparency.svg" alt="" width="40" height="40" />
                                
                            </div>
                            <span class="ml-2">Similarity:</span>
                            <input id="objecttol"  type="text" value="{tol}" class="form-control ml-2" placeholder="How Similar Image Can Be">
                                
                    </div>

                        <div class="box mt-2">
                            <div class="text-center mr-auto ml-auto">
                                <img src="media/objectmenu/male.svg" class="mr-auto ml-auto" alt="" width="40" height="40" />
                                
                            </div>
                            <div class="flex mt-4">
                                <a class="ml-2">X1:</a>
                                <input id="objectx1" type="text" value="{x1}" class="form-control ml-2" placeholder="X1">
                                
                                <a class="ml-2">Y1:</a>
                                <input id="objecty1" type="text" value="{y1}" class="form-control ml-2" placeholder="Y1">
                            </div>
                            <div class="flex mt-4">
                                <a class="ml-2">X2:</a>
                                <input id="objectx2" type="text" value="{x2}" class="form-control ml-2" placeholder="X2">
                                
                                <a class="ml-2">Y2:</a>
                                <input id="objecty2" type="text" value="{y2}" class="form-control ml-2" placeholder="Y2">
                            </div>
                            
                                
                        </div>

                        
                        <div class="box mt-4">
                            <div class="text-center mr-auto ml-auto">
                                <img src="media/objectmenu/strings.svg" class="mr-auto ml-auto" alt="" width="40" height="40" />
                                
                            </div>
                            <div class="flex mt-4">
                                <a class="ml-2">Color:</a>
                                <input id="objectcolorstring" value="{stringcolor}" type="text" class="form-control ml-2" placeholder="Color String">
                                
                                
                            </div>
                            <div class="flex mt-4">
                                <a class="ml-2">GrayScale:</a>
                                <input id="objectgraystring" value="{stringgray}" type="text" class="form-control ml-2" placeholder="GrayScale String">
                                
                            </div>
                            
                                
                        </div>
                    </div>
                    '''.format(**dict)
            
                self.sidefoot = '''
                    <div class="text-center mr-auto ml-auto mt-2">
                    <button type="button" data-dismiss="modal" class="btn btn-outline-secondary w-20 mr-1">Cancel</button>
                    <button type="button" data-dismiss="modal" class="btn btn-primary w-20" onclick="pywebview.api.sidesave('ObjectSideSave','Image')">Save</button>
                    </div>
                 '''
            if botobject.Aobjtype == "Pixel":
                #print('start pix head')
                try:
                    x = botobject.pixelcolor.replace("0x", "")
                # print(x)
                except:
                    print('no 0x')
                    x=""
                dict = {'objname':botobject.activeobjectname,'pixelcolor':x}
                self.sidehead = '''
                    <div class="text-center mr-auto ml-auto mt-2">
                    <a>
                        <span class="px-4 py-3 rounded-full bg-theme-1 text-white mt-1 mr-1">{objname}</span>
                            
                    </a>
                        <a  class="flex mt-5">
                            
                                    <div style="width:100px;height:100px;background-color: #{pixelcolor};"></div>
                        </a>
                    </div>
                 '''.format(**dict)
               # print(botobject.Aobjtol)
                dict = {'name':botobject.activeobjectname,'type': botobject.Aobjtype,'tol':botobject.Aobjtol, 'scan': botobject.Aobjscan, 'color': botobject.pixelcolor,
                'clicks': botobject.Aobjclicks,'x1': botobject.Aobjx1,'y1': botobject.Aobjy1,'x2': botobject.Aobjx2,'y2':botobject.Aobjy2}
                
                self.sidebody = '''
                    <div class="modal-body">
                            <div class="flex">
                                <div>
                                    <img src="media/objectmenu/edit.svg" alt="" width="40" height="40" />
                                    
                                </div>
                                    <span class="ml-2">Scan Type:</span>
                                    <select id="objecttype" class="form-select ml-2" aria-label="Select System">
                                        <option>Area</option>
                                        <option>Single Point</option>
                                    </select>
                            </div>

                            <div class="flex mt-2">
                                <div>
                                    <img src="media/objectmenu/tap.svg" alt="" width="40" height="40" />
                                    
                                </div>
                                <span class="ml-2">Click Options:</span>
                                <select id="objectclick" class="form-select ml-2" aria-label="Select System">
                                    <option>Click</option>
                                    <option>No Click</option>
                                    </select>
                            </div>

                            <div class="flex mt-2">
                                <div>
                                    <img src="media/objectmenu/transparency.svg" alt="" width="40" height="40" />
                                    
                                </div>
                                <span class="ml-2">Similarity:</span>
                                <input id="objecttol" value="{tol}"  type="text" class="form-control ml-2" placeholder="How Similar Image Can Be">
                                    
                            </div>

                            <div class="box mt-2">
                                <div class="text-center mr-auto ml-auto">
                                    <img src="media/objectmenu/male.svg" class="mr-auto ml-auto" alt="" width="40" height="40" />
                                    
                                </div>
                                <div class="flex mt-4">
                                    <a class="ml-2">X1:</a>
                                    <input id="objectx1" value="{x1}" type="text" class="form-control ml-2" placeholder="X1">
                                    
                                    <a class="ml-2">Y1:</a>
                                    <input id="objecty1" type="text" value="{y1}" class="form-control ml-2" placeholder="Y1">
                                </div>
                                <div class="flex mt-4">
                                    <a class="ml-2">X2:</a>
                                    <input id="objectx2" type="text" value="{x2}" class="form-control ml-2" placeholder="X2">
                                    
                                    <a class="ml-2">Y2:</a>
                                    <input id="objecty2" type="text" value="{y2}" class="form-control ml-2" placeholder="Y2">
                                </div>
                                
                                    
                            </div>

                            
                            <div class="box mt-4">
                                <div class="text-center mr-auto ml-auto">
                                    <img src="media/objectmenu/strings.svg" class="mr-auto ml-auto" alt="" width="40" height="40" />
                                    
                                </div>
                                <div class="flex mt-4">
                                    <a class="ml-2">Pixel Color:</a>
                                    <input id="objectcolorstring" value="{color}" type="text" class="form-control ml-2" placeholder="Color String">
                                    
                                    
                                </div>
                                
                                
                                    
                            </div>
                        </div>
                        '''.format(**dict)
                
                self.sidefoot = '''
                    <div class="text-center mr-auto ml-auto mt-2">
                    <button type="button" data-dismiss="modal" class="btn btn-outline-secondary w-20 mr-1">Cancel</button>
                    <button type="button" class="btn btn-primary w-20" data-dismiss="modal" onclick="pywebview.api.sidesave('ObjectSideSave','Pixel')">Save</button>
                    </div>
                 '''
            if botobject.Aobjtype == "Func":
                dict = {'objname':botobject.activeobjectname}
                self.sidehead = '''
                    <div  class="text-center mr-auto ml-auto mt-2">
                        <a>
                            <span class="px-4 py-3 rounded-full bg-theme-1 text-white mt-1 mr-1">{objname}</span>
                           
                        </a>
                        <a  class="flex mt-5">
                           
                                <img  src="media/submenu/function.svg" style="max-width:100px;width:100%"">
                            </a>

                    </div>
                    '''.format(**dict)
               #print("Func objects",botobject.Aobjfunc)
                tmpvar=""
                x = botobject.Aobjfunc.split("|")
                for some in x:
                    if some == "Func":
                        continue
                    dict = {'modename':some}
                    test= '''<span  class=" mb-4 ml-2 px-5    rounded-full bg-theme-6 text-gray-300 "><strong>{modename}</strong></span> '''.format(**dict)
                    tmpvar = test +  tmpvar
                dict = {'objname':tmpvar}
                self.sidebody = '''{objname}'''.format(**dict)
                
            
                
                
                self.sidefoot = ''' 
                <div class="modal-footer text-right w-full absolute bottom-0">
                    <button type="button" data-dismiss="modal" class="btn btn-outline-secondary w-20 mr-1">Close</button>
                    
                </div>
                
                '''
            if botobject.Aobjtype == "UIFunc":
                dict = {'objname':botobject.activeobjectname}
                self.sidehead = '''
                    <div  class="text-center mr-auto ml-auto mt-2">
                        <a>
                            <span class="px-4 py-3 rounded-full bg-theme-1 text-white mt-1 mr-1">{objname}</span>
                           
                        </a>
                        <a  class="flex mt-5">
                           
                                <img  src="media/submenu/UI.png" style="max-width:100px;width:100%"">
                            </a>

                    </div>
                    '''.format(**dict)
               #print("Func objects",botobject.Aobjfunc)
                # tmpvar=""
                # x = botobject.Aobjfunc.split("|")
                # for some in x:
                #     if some == "Func":
                #         continue
                #     dict = {'modename':some}
                #     test= '''<span  class=" mb-4 ml-2 px-5    rounded-full bg-theme-6 text-gray-300 "><strong>{modename}</strong></span> '''.format(**dict)
                #     tmpvar = test +  tmpvar
                # dict = {'objname':tmpvar}
                self.sidebody = ''''''
                
            
                
                
                self.sidefoot = ''' 
                <div class="modal-footer text-right w-full absolute bottom-0">
                    <button type="button" data-dismiss="modal" class="btn btn-outline-secondary w-20 mr-1">Close</button>
                    
                </div>
                
                '''
               
    def modalsmake(self,mode,botobject):
        print(mode)

        if mode == "Addbot":
            print('Add bot')
            self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
            self.sidebody =''' 
                <div class="text-3xl mb-5">Add New Bot</div>
                                
                                <div class="flex">
                                    <div>
                                        <img src="media/modes/ninja.svg" alt="" width="40" height="40" />
                                        
                                    </div>
                                    <span class="ml-2">Name</span>
                                    <input id="addbotname"  type="text" class="form-control ml-2" placeholder="Edit Name">
                                    
                                </div>

                                <div class="flex mt-2">
                                    <div>
                                        <img src="media/editbot/control-panel.svg"  alt="" width="40" height="40" />
                                        
                                    </div>
                                    <span class="ml-2">System</span>
                                    <select id="addbotsystem" class="form-select ml-2" aria-label="Select System">
                                        <option>Nox</option>
                                        <option>Bluestacks</option>
                                        <option>Chrome</option>
                                        <option>Human</option>
                                    </select>
                                    
                                </div>
            
                                <div class="flex mt-2">
                                    <div>
                                        <img src="media/editbot/history.svg" alt="" width="40" height="40" />
                                        
                                    </div>
                                    <span class="ml-2">Version</span>
                                    <input id="addbotver" type="text" class="form-control ml-2"  value="1.0.0"  placeholder="1.0.0 ">
                                    
                                </div>
                                <div class="flex mt-2">
                                    <div>
                                        <img src="media/editbot/video-game.svg" alt="" width="40" height="40" />
                                        
                                    </div>
                                    <span class="ml-2">Image Ver</span>
                                    <input id="addbotimgver" type="text" class="form-control ml-1" value="1.0.0" placeholder="1.0.0">
                                    
                                </div>

                                <div class="flex mt-2">
                                    <div>
                                        <img src="media/editbot/app.svg" alt="" width="40" height="40" />
                                        
                                    </div>
                                    <span class="ml-2">Bot Width</span>
                                    <input id="addbotw" type="text" class="form-control ml-2" value="960" placeholder="960 *target window Width">
                                    
                                </div>

                                <div class="flex mt-2">
                                    <div>
                                        <img src="media/editbot/monitor-height.svg" alt="" width="40" height="40" " />
                                        
                                    </div>
                                    <span class="ml-2">Bot Height</span>
                                    <input id="addboth" type="text" class="form-control ml-2" value="600" placeholder="600 *target window Height">
                                    
                                </div>
            
                                <div class="flex mt-2">
                                    <div>
                                        <img src="media/editbot/022-3d.svg" alt="" width="40" height="40" />
                                        
                                    </div>
                                    <span class="ml-2">Image URL</span>
                                    <input id="addbotimg" type="text" class="form-control ml-2" value="Developertool.png" placeholder="Developertool.png">
                                    
                                </div>

                              
                '''
            self.sidefoot = ''' <button  type="button"  onclick="pywebview.api.sidesave('addBot','')" class="btn btn-primary w-20">Add</button> '''

        if mode == "Addmode":
            print('Add Mode')
            self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
            self.sidebody =''' 
                <div class="text-3xl mb-5">Add New Mode</div>
                                
                                <div class="flex">
                                    <div>
                                        <img src="media/modes/data-collection.svg" alt="" width="40" height="40" />
                                        
                                    </div>
                                    <span class="ml-2">Name</span>
                                    <input id="addmodename" type="text" class="form-control ml-2" placeholder="Edit Name">
                                    
                                </div>
            
                            
                '''
            self.sidefoot = ''' <button  type="button" data-dismiss="modal"  onclick="pywebview.api.sidesave('AddMode','')" class="btn btn-primary w-20">Add</button> '''
        
        if mode == "BotSett":
            print('Add Mode')
            self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
            self.sidebody =''' 
                <div class="text-3xl mb-5">Bot Click Settings</div>
                <div class="mr-auto ml-auto">
                <label>Pick Click Controller</label>
                <div class="flex flex-col sm:flex-row mt-2">
                    <div class="form-check mr-2"  onclick="pywebview.api.Controllermode('Nox')">
                        <input id="radio-switch-41" class="form-check-input" type="radio"  name="horizontal_radio_button" value="none">
                        <label class="form-check-label" for="radio-switch-41"><img  class="w-8 mr-auto ml-auto" src="media/submenu/Nox_App_Player_Icon.png" />Nox</label>
                    </div>
                    <div class="form-check mr-2"  onclick="pywebview.api.Controllermode('Bluestacks')">
                        <input id="radio-switch-42" class="form-check-input" type="radio"  name="horizontal_radio_button" value="none">
                        <label class="form-check-label" for="radio-switch-42"><img  class="w-8 mr-auto ml-auto" src="media/submenu/bluestacks.png" />BlueStacks</label>
                    </div>
                    <div class="form-check mr-2 mt-2 sm:mt-0" onclick="pywebview.api.Controllermode('Chrome')">
                        <input id="radio-switch-51" class="form-check-input" type="radio" name="horizontal_radio_button" value="ifexist">
                        <label class="form-check-label" for="radio-switch-51"><img  class="w-8 mr-auto ml-auto" src="media/submenu/chrome (1).png" />Chrome/Mirror</label>
                    </div>
                    <div class="form-check mr-2 mt-2 sm:mt-0" onclick="pywebview.api.Controllermode('Human')">
                        <input id="radio-switch-61" class="form-check-input" type="radio" name="horizontal_radio_button" value="Ifnotexist">
                        <label class="form-check-label" for="radio-switch-61"><img  class="w-8 mr-auto ml-auto" src="media/submenu/mouse.png" />HumanLikeMouse</label>
                    </div>
                </div>
            </div>
                '''
            self.sidefoot = ''' <button  type="button" data-dismiss="modal"  onclick="pywebview.api.controllersave()" class="btn btn-primary w-20">Save</button> '''
        
        if mode== "Addimage":
            self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
            self.sidebody =''' <div  class="text-3xl mb-5">Add New Image</div>
                <div id="basic-accordion" class="p-5">
                                    <div class="preview">
                                        <div id="faq-accordion-1" class="accordion">
                                            <div class="accordion-item">
                                                <div id="faq-accordion-content-1" class="accordion-header">
                                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-1" aria-expanded="true" aria-controls="faq-accordion-collapse-1"> Single Object Add </button>
                                                </div>
                                                <div id="faq-accordion-collapse-1" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-content-1" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    <div class="flex mt-2">
                                                        <div>
                                                            <img src="media/submenu/picture.svg" alt="" width="40" height="40" />
                                                            
                                                        </div>
                                                        <span class="ml-2">Name</span>
                                                        <input id="simgname" type="text" class="form-control ml-2" placeholder="Edit Name">
                                                        
                                                    </div>

                                                    <div class="flex mt-2">
                                                            <div>
                                                                <img src="media/objectmenu/edit.svg" alt="" width="40" height="40" />
                                                                
                                                            </div>
                                                        
                                                        <span class="ml-2">Scan Type:</span>
                                                        <select id="simgtype" class="form-select ml-2" aria-label="Select System">
                                                            <option>Area</option>
                                                            <option>Window</option>
                                                        </select>
                                                    </div>

                                                    <div class="flex mt-3">
                                                        <div>
                                                            <img src="media/objectmenu/color-circle.svg" alt="" width="40" height="40" />
                                                            
                                                        </div>
                                                        <span  class="ml-2">Scan Color:</span>
                                                        <select id="simgcolor" class="form-select ml-2" aria-label="Select System">
                                                            <option>Color</option>
                                                            <option>Grayscale</option>
                                                            </select>
                                                    </div>

                                                    <div class="flex mt-3">
                                                        <div>
                                                            <img src="media/objectmenu/tap.svg" alt="" width="40" height="40" />
                                                            
                                                        </div>
                                                        <span class="ml-2">Click Options:</span>
                                                        <select id="simgclick" class="form-select ml-2" aria-label="Select System">
                                                            <option>Click</option>
                                                            <option>No Click</option>
                                                            </select>
                                                    </div>

                                                    <div class="flex mt-3">
                                                        <div>
                                                            <img src="media/objectmenu/transparency.svg" alt="" width="40" height="40" />
                                                            
                                                        </div>
                                                        <span class="ml-2">Similarity:</span>
                                                        <input id="simgtol" value="55" type="text" class="form-control ml-2" placeholder="How Similar Image Can Be">     
                                                    </div>
                                                        <button  type="button" data-dismiss="modal"  onclick="pywebview.api.sidesave('DbObjAdd','Single|Image')" class="btn btn-primary mt-2 w-20">Add</button>                                   
                                                </div>
                                            </div>
                                        </div>
                                            <div class="accordion-item">
                                                <div id="faq-accordion-content-2" class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-2" aria-expanded="false" aria-controls="faq-accordion-collapse-2"> Multi Objects Add</button>
                                                </div>
                                                <div id="faq-accordion-collapse-2" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-2" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    <div class="flex mt-2">
                                                        <div>
                                                            <img src="media/submenu/picture.svg" alt="" width="40" height="40" />
                                                            
                                                        </div>
                                                        <span class="ml-2">Name</span>
                                                        <input id="mimgname" type="text" class="form-control ml-2" placeholder="Edit Name">
                                                        
                                                    </div>
                                                    <div class="flex mt-2">
                                                    
                                                        <span class="ml-2 mt-2">Range</span>
                                                        <input id="mimgrange1" type="text" class="form-control ml-2" value="1" placeholder="input number">
                                                        <input id="mimgrange2" type="text" class="form-control ml-2" type="number" value="9" min="1" max="9" placeholder="input number">
                                                        
                                                    </div>

                                                    <div class="flex mt-2">
                                                            <div>
                                                                <img src="media/objectmenu/edit.svg" alt="" width="40" height="40" />
                                                                
                                                            </div>
                                                        
                                                        <span class="ml-2">Scan Type:</span>
                                                        <select id="mimgtype" class="form-select ml-2" aria-label="Select System">
                                                            <option>Area</option>
                                                            <option>Window</option>
                                                        </select>
                                                    </div>

                                                    <div class="flex mt-3">
                                                        <div>
                                                            <img src="media/objectmenu/color-circle.svg" alt="" width="40" height="40" />
                                                            
                                                        </div>
                                                        <span  class="ml-2">Scan Color:</span>
                                                        <select id="mimgcolor" class="form-select ml-2" aria-label="Select System">
                                                            <option>Color</option>
                                                            <option>Grayscale</option>
                                                            </select>
                                                    </div>

                                                    <div class="flex mt-3">
                                                        <div>
                                                            <img src="media/objectmenu/tap.svg" alt="" width="40" height="40" />
                                                            
                                                        </div>
                                                        <span class="ml-2">Click Options:</span>
                                                        <select id="mimgclick" class="form-select ml-2" aria-label="Select System">
                                                            <option>Click</option>
                                                            <option>No Click</option>
                                                            </select>
                                                    </div>

                                                    <div class="flex mt-3">
                                                        <div>
                                                            <img src="media/objectmenu/transparency.svg" alt="" width="40" height="40" />
                                                            
                                                        </div>
                                                        <span class="ml-2">Similarity:</span>
                                                        <input id="mimgtol"  type="text" class="form-control ml-2" value="55" placeholder="How Similar Image Can Be">     
                                                    </div>
                                                    <button  type="button" data-dismiss="modal"  onclick="pywebview.api.sidesave('DbObjAdd','Multi|Image')" class="btn btn-primary mt-2 w-20">Add</button>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    
                                </div>
                                '''
            self.sidefoot = ''' '''

        if mode== "Addpixel":
            self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
            self.sidebody =''' <div  class="text-3xl mb-5">Add New Pixel</div>
                        <div id="basic-accordion" class="p-5">
                                            <div class="preview">
                                                <div id="faq-accordion-1" class="accordion">
                                                    <div class="accordion-item">
                                                        <div id="faq-accordion-content-1" class="accordion-header">
                                                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-1" aria-expanded="true" aria-controls="faq-accordion-collapse-1"> Single Object Add </button>
                                                        </div>
                                                        <div id="faq-accordion-collapse-1" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-content-1" data-bs-parent="#faq-accordion-1">
                                                            <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                            <div class="flex mt-2">
                                                                <div>
                                                                    <img src="media/editmenu/022-dropper-1.svg" alt="" width="40" height="40" />
                                                                    
                                                                </div>
                                                                <span class="ml-2">Name</span>
                                                                <input id="spixname" type="text" class="form-control ml-2" placeholder="Edit Name">
                                                                
                                                            </div>

                                                            <div class="flex mt-2">
                                                                    <div>
                                                                        <img src="media/objectmenu/edit.svg" alt="" width="40" height="40" />
                                                                        
                                                                    </div>
                                                                
                                                                <span class="ml-2">Scan Type:</span>
                                                                <select id="spixtype" class="form-select ml-2" aria-label="Select System">
                                                                    <option>Area</option>
                                                                    <option>Window</option>
                                                                </select>
                                                            </div>

                                                        

                                                            <div class="flex mt-3">
                                                                <div>
                                                                    <img src="media/objectmenu/tap.svg" alt="" width="40" height="40" />
                                                                    
                                                                </div>
                                                                <span class="ml-2">Click Options:</span>
                                                                <select id="spixclick" class="form-select ml-2" aria-label="Select System">
                                                                    <option>Click</option>
                                                                    <option>No Click</option>
                                                                    </select>
                                                            </div>

                                                            <div class="flex mt-3">
                                                                <div>
                                                                    <img src="media/objectmenu/transparency.svg" alt="" width="40" height="40" />
                                                                    
                                                                </div>
                                                                <span class="ml-2">Similarity:</span>
                                                                <input id="spixtol" value="5"  type="text" class="form-control ml-2" placeholder="How Similar Image Can Be">     
                                                            </div>
                                                                <button  type="button" data-dismiss="modal" onclick="pywebview.api.sidesave('DbObjAdd','Single|Pixel')"  class="btn btn-primary mt-2 w-20">Add</button>                                    
                                                        </div>
                                                    </div>
                                                </div>
                                                    <div class="accordion-item">
                                                        <div id="faq-accordion-content-2" class="accordion-header">
                                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-2" aria-expanded="false" aria-controls="faq-accordion-collapse-2"> Multi Objects Add</button>
                                                        </div>
                                                        <div id="faq-accordion-collapse-2" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-2" data-bs-parent="#faq-accordion-1">
                                                            <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                            <div class="flex mt-2">
                                                                <div>
                                                                    <img src="media/editmenu/022-dropper-1.svg" alt="" width="40" height="40" />
                                                                    
                                                                </div>
                                                                <span class="ml-2">Name</span>
                                                                <input id="mpixname" type="text" class="form-control ml-2" placeholder="Edit Name">
                                                                
                                                            </div>
                                                            <div class="flex mt-2">
                                                            
                                                                <span class="ml-2 mt-2">Range</span>
                                                                <input id="mpixrange1" value="1" min="1" type="text" class="form-control ml-2" placeholder="input number">
                                                                <input id="mpixrange2" value="9" min="1" max="9" type="text" class="form-control ml-2" placeholder="input number">
                                                                
                                                            </div>

                                                            <div class="flex mt-2">
                                                                    <div>
                                                                        <img src="media/objectmenu/edit.svg" alt="" width="40" height="40" />
                                                                        
                                                                    </div>
                                                                
                                                                <span class="ml-2">Scan Type:</span>
                                                                <select id="mpixtype" class="form-select ml-2" aria-label="Select System">
                                                                    <option>Area</option>
                                                                    <option>Window</option>
                                                                </select>
                                                            </div>

                                                            

                                                            <div class="flex mt-3">
                                                                <div>
                                                                    <img src="media/objectmenu/tap.svg" alt="" width="40" height="40" />
                                                                    
                                                                </div>
                                                                <span class="ml-2">Click Options:</span>
                                                                <select id="mpixclick" class="form-select ml-2" aria-label="Select System">
                                                                    <option>Click</option>
                                                                    <option>No Click</option>
                                                                    </select>
                                                            </div>

                                                            <div class="flex mt-3">
                                                                <div>
                                                                    <img src="media/objectmenu/transparency.svg" alt="" width="40" height="40" />
                                                                    
                                                                </div>
                                                                <span class="ml-2">Similarity:</span>
                                                                <input id="mpixtol" value="5" type="text" class="form-control ml-2" placeholder="How Similar Image Can Be">     
                                                            </div>
                                                            </div>
                                                             <button  type="button" data-dismiss="modal"  onclick="pywebview.api.sidesave('DbObjAdd','Multi|Pixel')" class="btn btn-primary mt-2 w-20">Add</button>
                                                        </div>
                                                        
                                                    </div>
                            
                                                </div>
                                                
                                            </div>
                                            
                                        </div>
                                '''
            self.sidefoot = ''' '''
        
        if mode == "Addfunc":
            self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
            self.sidebody =''' <div  class="text-3xl mb-5">Add New Function</div>
                                <div id="basic-accordion" class="p-5">
                                                    <div class="preview">
                                                        <div id="faq-accordion-1" class="accordion">
                                                            <div class="accordion-item">
                                                                <div id="faq-accordion-content-1" class="accordion-header">
                                                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-1" aria-expanded="true" aria-controls="faq-accordion-collapse-1"> Single Object Add </button>
                                                                </div>
                                                                <div id="faq-accordion-collapse-1" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-content-1" data-bs-parent="#faq-accordion-1">
                                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                                    <div class="flex mt-2">
                                                                        <div>
                                                                            <img src="media/submenu/function.svg" alt="" width="40" height="40" />
                                                                            
                                                                        </div>
                                                                        <span class="ml-2 mt-2">Name</span>
                                                                        <input id="funcname" type="text" class="form-control ml-2" placeholder="Edit Name">
                                                                        
                                                                    </div>

                                                                     <button  type="button" data-dismiss="modal"   onclick="pywebview.api.sidesave('DbObjAdd','Single|Func')" class="btn btn-primary mt-5 w-20">Add</button> 
                                                                                                            
                                                                </div>
                                                            </div>
                                                        </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                '''
            self.sidefoot = ''' '''
        
        if mode == "AddUIfunc":
            self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
            self.sidebody =''' <div  class="text-3xl mb-5">Add New Function</div>
                                <div id="basic-accordion" class="p-5">
                                                    <div class="preview">
                                                        <div id="faq-accordion-1" class="accordion">
                                                            <div class="accordion-item">
                                                                <div id="faq-accordion-content-1" class="accordion-header">
                                                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-1" aria-expanded="true" aria-controls="faq-accordion-collapse-1"> Single Object Add </button>
                                                                </div>
                                                                <div id="faq-accordion-collapse-1" class="accordion-collapse collapse show" aria-labelledby="faq-accordion-content-1" data-bs-parent="#faq-accordion-1">
                                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                                    <div class="flex mt-2">
                                                                        <div>
                                                                            <img src="media/submenu/UI.png" alt="" width="40" height="40" />
                                                                            
                                                                        </div>
                                                                        <span class="ml-2 mt-2">Name</span>
                                                                        <input id="funcname" type="text" class="form-control ml-2" placeholder="Edit Name">
                                                                        
                                                                    </div>

                                                                     <button  type="button" data-dismiss="modal"   onclick="pywebview.api.sidesave('DbObjAdd','Single|UIFunc')" class="btn btn-primary mt-5 w-20">Add</button> 
                                                                                                            
                                                                </div>
                                                            </div>
                                                        </div>
                                                            
                                                            
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                '''
            self.sidefoot = ''' '''

        if mode == "Addtomode":
            indexer = 0
            totalimg=""
            totalpix=""
            totalfunc=""
            listimg=[]
            listpix=[]
            listfunc=[]
            for key in botobject.objs:
                
                for objname in key:
                    #print(objname)
                    
                    objname=objname.lower()
                    objtyp =botobject.objs[indexer][objname][0]['type']
                    #print(objtyp)
                    if objtyp == "Image":
                        listimg.append(objname)
                        listimg.sort()
                    if objtyp == "Pixel":
                        listpix.append(objname)
                        listpix.sort()
                    
                    if objtyp == "Func":
                        listfunc.append(objname)
                        listfunc.sort()

                    indexer += 1
           # print(listimg,listpix,listfunc)
            listimg.reverse()
            listpix.reverse()
            listfunc.reverse()
            for item in listimg:
                dict = {'name':item}
                imgobj= ''' <div class="w-16 h-16 relative image-fit mb-5 mr-5 cursor-pointer zoom-in">
                <img title="{name}" class="rounded-md mt-2" onclick="toggleCheckbox({name}chk)" src="media/submenu/picture.svg">
                <div  class="w-5 h-5 flex items-center justify-center absolute rounded-full text-white left-4 top-0 -mt-2"></div>
                <div title="Add this image?" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white right-0 top-0 -mr-2 -mt-2"> <input class="form-check-input border border-gray-500 mt-5 ml-2" id="{name}chk" type="checkbox"></div>
                <i  class="  items-center justify-center absolute rounded-full text-white left-0 bott-0 -mt-2">{name}</i>
                </div> '''.format(**dict)
            #  print('after div')
                totalimg= imgobj+totalimg
            for item in listpix:
                    dict = {'name':item}
                    pixobj= ''' <div class="w-16 h-16 relative image-fit mb-5 mr-5 cursor-pointer zoom-in">
                    <img class="rounded-md mt-2"onclick="toggleCheckbox({name}chk)" title="{name}" src="media/submenu/pixels.svg">
                    <div  class="w-5 h-5 flex items-center justify-center absolute rounded-full text-white left-4 top-0 -mt-2"></div>
                    <div title="Add this Pixel?" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white right-0 top-0 -mr-2 -mt-2"> <input class="form-check-input border border-gray-500 mt-5 ml-2" id="{name}chk" type="checkbox"></div>
                    <i  class="  items-center justify-center absolute rounded-full text-white left-0 bott-0 -mt-2">{name}</i>
                    </div> '''.format(**dict)
                    totalpix= pixobj+totalpix
            for item in listfunc:
                    dict = {'name':item}
                    funcobj= ''' <div class="w-16 h-16 relative image-fit mb-5 mr-5 cursor-pointer zoom-in">
                    <img class="rounded-md mt-2" title="{name}" onclick="toggleCheckbox({name}chk)"  src="media/submenu/function.svg">
                    <div  class="w-5 h-5 flex items-center justify-center absolute rounded-full text-white left-4 top-0 -mt-2"></div>
                    <div title="Add this Pixel?" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white right-0 top-0 -mr-2 -mt-2"> <input class="form-check-input border border-gray-500 mt-5 ml-2" id="{name}chk" type="checkbox"></div>
                    <i  class="  items-center justify-center absolute rounded-full text-white left-0 bott-0 -mt-2">{name}</i>
                    </div> '''.format(**dict)
                    totalfunc= funcobj+totalfunc
            #print(totalimg)
            
                    # if objtyp == "Image":
                    # #  print('image')
                    #     dict = {'name':objname}
                    #     imgobj= ''' <div class="w-16 h-16 relative image-fit mb-5 mr-5 cursor-pointer zoom-in">
                    #     <img title="{name}" class="rounded-md mt-2"  src="media/submenu/picture.svg">
                    #     <div  class="w-5 h-5 flex items-center justify-center absolute rounded-full text-white left-4 top-0 -mt-2"></div>
                    #     <div title="Add this image?" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white right-0 top-0 -mr-2 -mt-2"> <input class="form-check-input border border-gray-500 mt-5 ml-2" id="{name}chk" type="checkbox"></div>
                    #     <i  class="  items-center justify-center absolute rounded-full text-white left-0 bott-0 -mt-2">{name}</i>
                    #     </div> '''.format(**dict)
                    # #  print('after div')
                    #     totalimg= imgobj+totalimg
                    # # print(objname,objtyp)
                    # if objtyp == "Pixel":

                    #     dict = {'name':objname}
                    #     pixobj= ''' <div class="w-16 h-16 relative image-fit mb-5 mr-5 cursor-pointer zoom-in">
                    #     <img class="rounded-md mt-2" title="{name}" src="media/submenu/pixels.svg">
                    #     <div  class="w-5 h-5 flex items-center justify-center absolute rounded-full text-white left-4 top-0 -mt-2"></div>
                    #     <div title="Add this Pixel?" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white right-0 top-0 -mr-2 -mt-2"> <input class="form-check-input border border-gray-500 mt-5 ml-2" id="{name}chk" type="checkbox"></div>
                    #     <i  class="  items-center justify-center absolute rounded-full text-white left-0 bott-0 -mt-2">{name}</i>
                    #     </div> '''.format(**dict)
                    # #  print('after div')
                    #     totalpix= pixobj+totalpix
                    # # print(objname,objtyp)
                    # if objtyp == "Func":
                        
                    #     dict = {'name':objname}
                    #     funcobj= ''' <div class="w-16 h-16 relative image-fit mb-5 mr-5 cursor-pointer zoom-in">
                    #     <img class="rounded-md mt-2" title="{name}"  src="media/submenu/function.svg">
                    #     <div  class="w-5 h-5 flex items-center justify-center absolute rounded-full text-white left-4 top-0 -mt-2"></div>
                    #     <div title="Add this Pixel?" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white right-0 top-0 -mr-2 -mt-2"> <input class="form-check-input border border-gray-500 mt-5 ml-2" id="{name}chk" type="checkbox"></div>
                    #     <i  class="  items-center justify-center absolute rounded-full text-white left-0 bott-0 -mt-2">{name}</i>
                    #     </div> '''.format(**dict)
                    # #  print('after div')
                    #     totalfunc= funcobj+totalfunc
                    
                   # indexer += 1
                    #print(objname['type'])
            self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
            dict = {'imgobjs':totalimg,'pixobjs':totalpix,'funcobjs':totalfunc}
            self.sidebody =''' <div class="scoller2">
                                <div class="bg-white dark:bg-dark-3 px-2 text-gray-300">Image Objects</div></div>
                                <div class="w-full border-t border-gray-200 dark:border-dark-5 mt-5"></div>
                                <div class=" flex flex-wrap items-center p-2 px-5">
                                
                                    {imgobjs}

                                </div>
                                <div class="bg-white dark:bg-dark-3 px-5 text-gray-300">Pixel Objects</div></div>
                                <div class="w-full border-t border-gray-200 dark:border-dark-5 mt-5"></div>
                                <div class="flex flex-wrap items-center px-5">
                                    {pixobjs}
                                    
                                </div>
                                <div class="bg-white dark:bg-dark-3 px-5 text-gray-300">Image Function</div></div>
                                <div class="w-full border-t border-gray-200 dark:border-dark-5 mt-5"></div>
                                <div class="flex flex-wrap items-center px-5">
                                    {funcobjs}
                                </div>
                                </div>
                                '''.format(**dict)
            dict = {'name':botobject.activemodename}
            self.sidefoot = ''' <button  type="button" data-dismiss="modal"  onclick="pywebview.api.objaddremove('{name}','addtomode')" class="btn btn-success w-20 " style="color:black;"><i >Add To Mode</i></button> '''.format(**dict)

        if mode == "Editobj":
            print('editobj modal')
           # print(botobject.Aobjtype)
            if botobject.Aobjtype == "Image":
                tmpdiv='''<img class="w-6" src="media/submenu/picture.svg">'''
            if botobject.Aobjtype == "Pixel":
                tmpdiv='''<img class="w-6" src="media/submenu/pixels.svg">'''
            if botobject.Aobjtype == "Func":
                tmpdiv='''<img class="w-6" src="media/submenu/function.svg">'''
            if botobject.Aobjtype == "UIFunc":
                tmpdiv='''<img class="w-6" src="media/submenu/UI.png">'''
            #print(tmpdiv)
            dict = {'div':tmpdiv}
            self.sidehead =''' 
                    <div class="flex">
                        <a class="mr-3 " id="editobjname"> <strong>Object Name</strong> </a>
                        <a class="mr-3 flex" id="editobjtype">Type: {div}</a>
                        <a class="mr-3 " id="editobjtrgw"> Target Max Width</a>
                        <a class="mr-3 " id="editobjtrgh"> Targer Max Height</a>

                    </div>
                    

                    <div>
                        <a data-dismiss="modal" onclick="destroycrop()"> <img  class="w-8 " src="media/submenu/close.svg" /></a>
                       
                    </div> '''.format(**dict)
            self.sidebody =''' <div class="container">
                        <img id="image" src="">

                        </div>
                    
                        <div class="box flex mt-4" >
                            <div class="flex">
                                <div class="ml-2 mt-2">X</div>
                                <input id="cropx1" type="text" class="form-control ml-3 w-40"  placeholder="X1">
                                
                                <div class="ml-6  mt-2">y</div>
                                <input id="cropy1" type="text" class="form-control ml-3 w-40" placeholder="y1">
                            </div>
                            
                            <div class="flex">
                                <div class="ml-2  mt-2">Width</div>
                            <input id="cropx2" type="text" class="form-control ml-2 w-40" placeholder="X2">
                            
                            <div class="ml-2  mt-2">Height</div>
                            <input id="cropy2" type="text" class="form-control ml-2 w-40" placeholder="y2">
                            </div>
                            


                        </div>
                        
                        <p class="mt-3 text-center">Result</p>
                            <div class="flex" style="display: flex; justify-content: space-around">
                                <div>
                                    New
                                    <div class="mt-3" id="result"></div>
                                </div>

                                <div>
                                    Old
                                    <div class="mt-3" id="oldimgnest" style="max-height:100px;max-width:100px">
                                    </div>
                                </div>
                            </div>
                    </div>'''
            self.sidefoot = '''<button type="button" class="btn btn-outline-secondary text-gray-100 px-4" name="multibtn" id="buttoncrop"> <img  class="mr-2" src="media/editmenu/crop.svg" height="30" width="30" name="multibtnimg" />  <i name="multibtntxt" class="mr-l">Crop</i> </button>
                    <button type="button" class="btn btn-outline-secondary text-gray-300 px-4 ml-2"   onclick="pywebview.api.getscanarea()"> <img name="startbtn" class="mr-2" src="media/editmenu/028-resize-1.svg" height="30" width="30"/>  Scan Area</button>
                    <!-- <button type="button" class="btn bg-gray-200 text-gray-800 px-4 ml-2" onclick="destroycrop()" id="targetre" > <img name="startbtn" class="mr-2" src="media/editmenu/048-trash.svg" height="30" width="30" />  Destroy</button> -->
                    <button type="button" class="btn btn-outline-secondary text-gray-500 px-4 ml-2" onclick="croptrig()"  > <img name="startbtn" class="mr-2" src="media/editmenu/040-rotate.svg" height="30" width="30" />  Get Screen</button>'''
        
        if mode == "Help":
            print(mode)
            self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
            self.sidebody =''' <div  class="text-3xl mb-5">Developer Help</div>
                <div id="basic-accordion" class="p-5">
                                    <div class="preview">
                                        <div id="faq-accordion-1" class="accordion">
                                            <div class="accordion-item">
                                                <div id="faq-accordion-content-1" class="accordion-header">
                                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-1" aria-expanded="true" aria-controls="faq-accordion-collapse-1"> Add New Bot </button>
                                                </div>
                                                <div id="faq-accordion-collapse-1" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-1" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    Not Supported Yet                           
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item text-center">
                                                <div id="faq-accordion-content-2" class="accordion-header">
                                                    <button class="accordion-button collapsed text-center" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-2" aria-expanded="false" aria-controls="faq-accordion-collapse-2"> Add Mode</button>
                                                </div>
                                                <div id="faq-accordion-collapse-2" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-2" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                   <img class="mr-2" src="https://raw.githubusercontent.com/DizzyduckAR/BotPlace/master/Help/NewMode.gif" height="600" width="800" />    
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <div class="accordion-item">
                                                <div id="faq-accordion-content-3" class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-3" aria-expanded="false" aria-controls="faq-accordion-collapse-3"> Add Image</button>
                                                </div>
                                                <div id="faq-accordion-collapse-3" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-3" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    <img class="mr-2" src="https://raw.githubusercontent.com/DizzyduckAR/BotPlace/master/Help/Newimg.gif" height="600" width="800" /> 
                                                </div>
                                            </div>
                                            
                                        </div>

                                        <div class="accordion-item">
                                                <div id="faq-accordion-content-4" class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-4" aria-expanded="false" aria-controls="faq-accordion-collapse-4"> Add pixel</button>
                                                </div>
                                                <div id="faq-accordion-collapse-4" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-4" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    <img class="mr-2" src="https://raw.githubusercontent.com/DizzyduckAR/BotPlace/master/Help/Newpixel.gif" height="600" width="800" /> 
                                                </div>
                                            </div>
                                            
                                        </div>

                                        <div class="accordion-item">
                                                <div id="faq-accordion-content-5" class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-5" aria-expanded="false" aria-controls="faq-accordion-collapse-5"> Add Function</button>
                                                </div>
                                                <div id="faq-accordion-collapse-5" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-5" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    <img class="mr-2" src="https://raw.githubusercontent.com/DizzyduckAR/BotPlace/master/Help/NewFunc.gif" height="600" width="800" /> 
                                                </div>
                                            </div>
                                            
                                        </div>

                                        <div class="accordion-item">
                                                <div id="faq-accordion-content-6" class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-6" aria-expanded="false" aria-controls="faq-accordion-collapse-6"> Add objects to Mode</button>
                                                </div>
                                                <div id="faq-accordion-collapse-6" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-6" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    <img class="mr-2" src="https://raw.githubusercontent.com/DizzyduckAR/BotPlace/master/Help/ObjtoMode.gif" height="600" width="800" /> 
                                                </div>
                                            </div>
                                            
                                        </div>

                                        <div class="accordion-item">
                                                <div id="faq-accordion-content-7" class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-7" aria-expanded="false" aria-controls="faq-accordion-collapse-7"> Crop Image</button>
                                                </div>
                                                <div id="faq-accordion-collapse-7" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-7" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    <img class="mr-2" src="https://raw.githubusercontent.com/DizzyduckAR/BotPlace/master/Help/Cropimg.gif" height="600" width="800" /> 
                                                </div>
                                            </div>
                                            
                                        </div>

                                        <div class="accordion-item">
                                                <div id="faq-accordion-content-8" class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-8" aria-expanded="false" aria-controls="faq-accordion-collapse-8"> Get Pixel</button>
                                                </div>
                                                <div id="faq-accordion-collapse-8" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-8" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    <img class="mr-2" src="https://raw.githubusercontent.com/DizzyduckAR/BotPlace/master/Help/Getpixel.gif" height="600" width="800" /> 
                                                </div>
                                            </div>
                                            
                                        </div>

                                        <div class="accordion-item">
                                                <div id="faq-accordion-content-9" class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-9" aria-expanded="false" aria-controls="faq-accordion-collapse-9"> Edit Function</button>
                                                </div>
                                                <div id="faq-accordion-collapse-9" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-9" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    <img class="mr-2" src="https://raw.githubusercontent.com/DizzyduckAR/BotPlace/master/Help/FuncEdit.gif" height="600" width="800" /> 
                                                </div>
                                            </div>
                                            
                                        </div>

                                        <div class="accordion-item">
                                                <div id="faq-accordion-content-10" class="accordion-header">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-accordion-collapse-10" aria-expanded="false" aria-controls="faq-accordion-collapse-10"> Test Bot Live</button>
                                                </div>
                                                <div id="faq-accordion-collapse-10" class="accordion-collapse collapse" aria-labelledby="faq-accordion-content-10" data-bs-parent="#faq-accordion-1">
                                                    <div class="accordion-body text-gray-700 dark:text-gray-600 leading-relaxed">
                                                    <img class="mr-2" src="https://raw.githubusercontent.com/DizzyduckAR/BotPlace/master/Help/Testbot.gif" height="600" width="800" /> 
                                                </div>
                                            </div>
                                            
                                        </div>
                                        
                                        
                                    </div>
                                    
                                </div>
                                '''
            self.sidefoot = ''' Click the Title to expend '''

        if mode == "fail":
            print('fail')
            self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
            self.sidebody =''' No Bot Loaded! Load Bot First'''
            self.sidefoot = '''Go To Bots/Apps | Edit Bots | Load Bot '''
            print('doen fail ')

    def autocodemodal(self,mode,botobject):
        self.sidehead =''' <a data-dismiss="modal" > <img  class="w-8 " src="media/submenu/close.svg" /></a> '''
        if mode =="Image":
            print('img card')
            indexer = 0
            totalimg=""
            listimg=[]
            for key in botobject.objs:
                
                for objname in key:
                    #print(objname)
                    
                    objname=objname.lower()
                    objtyp =botobject.objs[indexer][objname][0]['type']
                    #print(objtyp)
                    if objtyp == "Image":
                               # dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                        listimg.append(objname)
                        listimg.sort()
                 

                    indexer += 1
           # print(listimg,listpix,listfunc)
            listimg.reverse()
           
            for item in listimg:
                botobject.ActiveObj(item)
                
                try:
                    imgcolor =botobject.Aobjcolorstring
                    if imgcolor == '' or imgcolor==None or imgcolor == "":
                        dict = {'name':item}
                        democard='''<div class="w-12 h-12 image-fit zoom-in" onclick="pywebview.api.funceditactiveobj('{name}','Image')" title="{name}">
                                <img  class="tooltip rounded-full" src="media/submenu/picture.svg"">
                                </div>&nbsp;&nbsp;'''.format(**dict)
                    else:
                        dict = {'imgbase64':imgcolor}
                        tmpdiv='''src="data:image/png;base64,{imgbase64}"'''.format(**dict)
                        dict = {'name':item,'img':tmpdiv}
                        democard='''<div class="w-12 h-12 image-fit zoom-in" onclick="pywebview.api.funceditactiveobj('{name}','Image')" title="{name}">
                                    <img  class="tooltip rounded-full" {img} title="{name}">
                                    </div>&nbsp;&nbsp;'''.format(**dict)
                  
                    # rawimg=''
                    # if imgcolor == "":
                    #         print("empty")
                    #         tmpdiv='''media/submenu/picture.svg'''
                    #         #dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':''}
                    # else:
                    #         #rawimg=imgcolor
                    #         dict = {'imgbase64':imgcolor}
                    #         tmpdiv='''data:image/png;base64,{imgbase64}'''.format(**dict)
                    #         print(tmpdiv)
                except:
                    print('fail build')
            
                
                totalimg= democard+totalimg
           # print(totalimg)
            dict = {'imgobjs':totalimg}
            self.sidebody ='''  <!-- BEGIN: General Report -->
                            <div class="col-span-12 lg:col-span-8 xl:col-span-6 mt-2">

                                <div class="report-box-2 intro-y mt-12 sm:mt-5">
                                    <div class="box sm:flex">
                                        <div class="px-8 py-12 flex flex-col  flex-1">
                                            <div class="flex">
                                            
                                            
                                            <strong>Pick Object</strong><br><br>
                                        </div>
                                            
                                            <div class="flex flex-wrap">
                                                {imgobjs}
                                            </div>
                                             <br>
                                        <br>
                                        <div class="w-full border-t border-gray-200 dark:border-dark-5 mt-5"></div>   
                                        <br>
                                        <div class="mr-auto ml-auto"
                                            <label>If Image Exist Options</label>
                                            <div class="flex flex-col sm:flex-row mt-2">
                                                <div class="form-check mr-2"  onclick="pywebview.api.existmode('None')">
                                                    <input id="radio-switch-4" class="form-check-input" type="radio" checked name="horizontal_radio_button" value="none">
                                                    <label class="form-check-label" for="radio-switch-4"><img  class="w-8 mr-auto ml-auto" src="media/submenu/close.svg" />None</label>
                                                </div>
                                                <div class="form-check mr-2 mt-2 sm:mt-0" onclick="pywebview.api.existmode('IfEx')">
                                                    <input id="radio-switch-5" class="form-check-input" type="radio" name="horizontal_radio_button" value="ifexist">
                                                    <label class="form-check-label" for="radio-switch-5"><img  class="w-8 mr-auto ml-auto" src="media/editor/facial-recognition (1).png" />If Exist</label>
                                                </div>
                                                <div class="form-check mr-2 mt-2 sm:mt-0" onclick="pywebview.api.existmode('IfNot')">
                                                    <input id="radio-switch-6" class="form-check-input" type="radio" name="horizontal_radio_button" value="Ifnotexist">
                                                    <label class="form-check-label" for="radio-switch-6"><img  class="w-8 mr-auto ml-auto" src="media/editor/facial-recognition.png" />If Not Exist</label>
                                                </div>
                                            </div>
                                        </div>
                                        <br><br>
                                        <div class="mr-auto ml-auto"
                                            <label>Build / Copy</label>
                                            <div class="flex flex-col sm:flex-row mt-2">
                                            <button type="button" class="btn btn-outline-secondary text-gray-300 px-4 ml-2"   onclick="pywebview.api.functioncodebuilder('Image')"> <img class="mr-2" src="media/editor/code.png" height="30" width="30"/>  Build Function</button>
                                            <button type="button" class="btn btn-outline-secondary text-gray-300 px-4 ml-2"   onclick="pywebview.api.codecopy()"> <img  class="mr-2" src="media/editor/copy.png" height="30" width="30"/>  Copy Code</button>
                                            </div>
                                        </div>
                                        </div>
                    <div class="px-8 py-12 flex flex-col  flex-1 border-t sm:border-t-0 sm:border-l border-gray-300 dark:border-dark-5 border-dashed">
                        <div class="modal-body">
                         <div  class="text-center mr-auto ml-auto">
                            <a>
                                <span class="px-4 py-3 rounded-full bg-theme-1 text-white" id="functext">Object name</span>
                            
                            </a>
                            <div class="mr-auto ml-auto">
                                <a  class="flex gap-5 mt-5 mr-auto ml-auto">
                                        <div class=" mr-auto ml-auto">
                                        IMG C
                                        <img id="funcbimg" src="media/submenu/picture.svg" style="max-width:100px;width:100%;" class="color mt-3">
                                        </div>
                                        <div class=" mr-auto ml-auto">
                                        IMG G
                                        <img id="funcbimg2" src="media/submenu/picture.svg" style="max-width:100px;width:100%;" class="gray mt-3">
                                        </div>
                                       
                                        
                                        
                                    </a>
                                </div>

                        </div>
                        <br><br>
                        <div class="flex">
                       
                            <div>
                                <img src="media/objectmenu/edit.svg" alt="" width="40" height="40" />
                                
                            </div>
                                <span class="ml-2">Scan Type:</span>
                                <select id="funcarea" class="form-select ml-2" >
                                    <option>Area</option>
                                    <option>Window</option>
                                </select>
                        </div>
                    <div class="flex mt-2">
                            <div>
                                <img src="media/objectmenu/color-circle.svg" alt="" width="40" height="40" />
                                
                            </div>
                            <span  class="ml-2">Scan Color:</span>
                            <select id="funccolor" value="" class="form-select ml-2">
                                <option>Color</option>
                                <option>Grayscale</option>
                                </select>
                    </div>

                    <div class="flex mt-2">
                            <div>
                                <img src="media/objectmenu/tap.svg" alt="" width="40" height="40" />
                                
                            </div>
                            <span class="ml-2">Click Options:</span>
                            <select id="funcclick" value="" class="form-select ml-2" aria-label="Select System">
                                <option>Click</option>
                                <option>No Click</option>
                                </select>
                    </div>

                    <div class="flex mt-2">
                            <div>
                                <img src="media/objectmenu/transparency.svg" alt="" width="40" height="40" />
                                
                            </div>
                            <span class="ml-2">Similarity:</span>
                            <input id="funcobjecttol"  type="text" value="" class="form-control ml-2" placeholder="How Similar Image Can Be">
                                
                    </div>

                      
                    </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- END: General Report -->'''.format(**dict)
            #self.sidefoot='''<div id="tmpditor"></div>'''

        if mode =="Pixel":
            print('pixel card')
            indexer = 0
            totalpix=""
            listpix=[]
            for key in botobject.objs:
                
                for objname in key:
                    #print(objname)
                    
                    objname=objname.lower()
                    objtyp =botobject.objs[indexer][objname][0]['type']
                    #print(objtyp)
                    if objtyp == "Pixel":
                               # dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                        listpix.append(objname)
                        listpix.sort()
                 

                    indexer += 1
            #print(listpix)
            listpix.reverse()
           
            for item in listpix:
                botobject.ActiveObj(item)
                #print(botobject.Aobjtol,botobject.Aobjscan,botobject.pixelcolor)
                
                try:
                    imgcolor =botobject.pixelcolor
                   # print(imgcolor)
                    if imgcolor == '' or imgcolor==None:
                        print('no color')
                        dict = {'name':item}
                        democard='''<div class="w-12 h-12 image-fit zoom-in" onclick="pywebview.api.funceditactiveobj('{name}','Pixel')" title="{name}">
                                <img  class="tooltip rounded-full" src="media/submenu/pixels.svg"">
                                </div>&nbsp;&nbsp;'''.format(**dict)
                        
                    else:

                        print('else starter',imgcolor)
                        try:
                            x = botobject.pixelcolor.replace("0x", "")
                        # print(x)
                        except:
                            print('no 0x')
                        dict = {'pixelcolor':x}
                        
                        tmpdiv=x
                        dict = {'name':item,'img':tmpdiv}
                        democard='''<div class="w-12 h-12 image-fit zoom-in" onclick="pywebview.api.funceditactiveobj('{name}','Pixel')" title="{name}">
                                    <div class="tooltip rounded-full"  title="{name}" style="width:48px;height:48px;background-color: #{img};"></div>
                                    </div>&nbsp;&nbsp;'''.format(**dict)
                  
                    # rawimg=''
                    # if imgcolor == "":
                    #         print("empty")
                    #         tmpdiv='''media/submenu/picture.svg'''
                    #         #dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':''}
                    # else:
                    #         #rawimg=imgcolor
                    #         dict = {'imgbase64':imgcolor}
                    #         tmpdiv='''data:image/png;base64,{imgbase64}'''.format(**dict)
                    #         print(tmpdiv)
                except:
                    print('fail build')
            
                
                totalpix= democard+totalpix
            print(totalpix)
            dict = {'imgobjs':totalpix}
            self.sidebody ='''  <!-- BEGIN: General Report -->
                            <div class="col-span-12 lg:col-span-8 xl:col-span-6 mt-2">

                                <div class="report-box-2 intro-y mt-12 sm:mt-5">
                                    <div class="box sm:flex">
                                        <div class="px-8 py-12 flex flex-col  flex-1">
                                            <div class="flex">
                                            
                                            
                                            <strong>Pick Object</strong><br><br>
                                        </div>
                                            
                                            <div class="flex flex-wrap">
                                                {imgobjs}
                                            </div>
                                             <br>
                                        <br>
                                        <div class="w-full border-t border-gray-200 dark:border-dark-5 mt-5"></div>   
                                        <br>
                                        <div class="mr-auto ml-auto"
                                            <label>If Image Exist Options</label>
                                            <div class="flex flex-col sm:flex-row mt-2">
                                                <div class="form-check mr-2"  onclick="pywebview.api.existmode('None')">
                                                    <input id="radio-switch-4" class="form-check-input" type="radio" checked name="horizontal_radio_button" value="none">
                                                    <label class="form-check-label" for="radio-switch-4"><img  class="w-8 mr-auto ml-auto" src="media/submenu/close.svg" />None</label>
                                                </div>
                                                <div class="form-check mr-2 mt-2 sm:mt-0" onclick="pywebview.api.existmode('IfEx')">
                                                    <input id="radio-switch-5" class="form-check-input" type="radio" name="horizontal_radio_button" value="ifexist">
                                                    <label class="form-check-label" for="radio-switch-5"><img  class="w-8 mr-auto ml-auto" src="media/editor/facial-recognition (1).png" />If Exist</label>
                                                </div>
                                                <div class="form-check mr-2 mt-2 sm:mt-0" onclick="pywebview.api.existmode('IfNot')">
                                                    <input id="radio-switch-6" class="form-check-input" type="radio" name="horizontal_radio_button" value="Ifnotexist">
                                                    <label class="form-check-label" for="radio-switch-6"><img  class="w-8 mr-auto ml-auto" src="media/editor/facial-recognition.png" />If Not Exist</label>
                                                </div>
                                            </div>
                                        </div>
                                        <br><br>
                                        <div class="mr-auto ml-auto"
                                            <label>Build / Copy</label>
                                            <div class="flex flex-col sm:flex-row mt-2">
                                            <button type="button" class="btn btn-outline-secondary text-gray-300 px-4 ml-2"   onclick="pywebview.api.functioncodebuilder('Pixel')"> <img class="mr-2" src="media/editor/code.png" height="30" width="30"/>  Build Function</button>
                                            <button type="button" class="btn btn-outline-secondary text-gray-300 px-4 ml-2"   onclick="pywebview.api.codecopy()"> <img  class="mr-2" src="media/editor/copy.png" height="30" width="30"/>  Copy Code</button>
                                            </div>
                                        </div>
                                        </div>
                    <div class="px-8 py-12 flex flex-col  flex-1 border-t sm:border-t-0 sm:border-l border-gray-300 dark:border-dark-5 border-dashed">
                        <div class="modal-body">
                         <div  class="text-center mr-auto ml-auto">
                            <a>
                                <span class="px-4 py-3 rounded-full bg-theme-1 text-white" id="functext">Object name</span>
                            
                            </a>
                            <div class="mr-auto ml-auto">
                                <a  class="flex gap-5 mt-5 mr-auto ml-auto">
                                        <div class=" mr-auto ml-auto">
                                        Color
                                        <div id="changepix"><img id="funcbimg" src="media/submenu/pixels.svg" style="max-width:100px;width:100%;" class="color mt-3"></div>
                                        </div>
                                       
                                       
                                        
                                        
                                    </a>
                                </div>

                        </div>
                        <br><br>
                        <div class="flex">
                       
                            <div>
                                <img src="media/objectmenu/edit.svg" alt="" width="40" height="40" />
                                
                            </div>
                                <span class="ml-2">Scan Type:</span>
                                <select id="funcarea" class="form-select ml-2" >
                                    <option>Area</option>
                                    <option>Single point</option>
                                </select>
                        </div>


                    <div class="flex mt-2">
                            <div>
                                <img src="media/objectmenu/tap.svg" alt="" width="40" height="40" />
                                
                            </div>
                            <span class="ml-2">Click Options:</span>
                            <select id="funcclick" value="" class="form-select ml-2" aria-label="Select System">
                                <option>Click</option>
                                <option>No Click</option>
                                </select>
                    </div>

                    <div class="flex mt-2">
                            <div>
                                <img src="media/objectmenu/transparency.svg" alt="" width="40" height="40" />
                                
                            </div>
                            <span class="ml-2">Similarity:</span>
                            <input id="funcobjecttol"  type="text" value="" class="form-control ml-2" placeholder="How Similar Image Can Be">
                                
                    </div>

                      
                    </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- END: General Report -->'''.format(**dict)
            #self.sidefoot='''<div id="tmpditor"></div>'''

        if mode =="Function":
            print('func')
            print('func card')
            indexer = 0
            totalpix=""
            listpix=[]
            for key in botobject.objs:
                
                for objname in key:
                    #print(objname)
                    
                    objname=objname.lower()
                    objtyp =botobject.objs[indexer][objname][0]['type']
                    #print(objtyp)
                    if objtyp == "Func":
                               # dict = {'objname':bar.activeobjectname,'type':bar.Aobjtype,'media':tmpdiv,'nameraw':key,'imgraw':rawimg}
                        listpix.append(objname)
                        listpix.sort()
                 

                    indexer += 1
            print(listpix)
            listpix.reverse()
           
            for item in listpix:
                botobject.ActiveObj(item)
                dict = {'name':item}
                democard='''<div class="w-12 h-12 image-fit zoom-in" onclick="pywebview.api.funceditactiveobj('{name}','Func')" title="{name}">
                        <img  class="tooltip rounded-full" src="media/submenu/function.svg"">
                        </div>&nbsp;&nbsp;'''.format(**dict)
                #print(botobject.Aobjtol,botobject.Aobjscan,botobject.pixelcolor)
                totalpix= democard+totalpix
                continue
                
            dict = {'imgobjs':totalpix}
            self.sidebody ='''  <!-- BEGIN: General Report -->
                            <div class="col-span-12 lg:col-span-8 xl:col-span-6 mt-2">

                                <div class="report-box-2 intro-y mt-12 sm:mt-5">
                                    <div class="box sm:flex">
                                        <div class="px-8 py-12 flex flex-col  flex-1">
                                            <div class="flex">
                                            
                                            
                                            <strong>Pick Object</strong><br><br>
                                        </div>
                                            
                                            <div class="flex flex-wrap">
                                                {imgobjs}
                                            </div>
                                             <br>
                                        <br>
                                        <div class="w-full border-t border-gray-200 dark:border-dark-5 mt-5"></div>   
                                        <br>
                                        <div class="mr-auto ml-auto"
                                            <label>If Image Exist Options</label>
                                            <div class="flex flex-col sm:flex-row mt-2">
                                                <div class="form-check mr-2"  onclick="pywebview.api.existmode('None')">
                                                    <input id="radio-switch-4" class="form-check-input" type="radio" checked name="horizontal_radio_button" value="none">
                                                    <label class="form-check-label" for="radio-switch-4"><img  class="w-8 mr-auto ml-auto" src="media/submenu/close.svg" />None</label>
                                                </div>
                                                <div class="form-check mr-2 mt-2 sm:mt-0" onclick="pywebview.api.existmode('IfEx')">
                                                    <input id="radio-switch-5" class="form-check-input" type="radio" name="horizontal_radio_button" value="ifexist">
                                                    <label class="form-check-label" for="radio-switch-5"><img  class="w-8 mr-auto ml-auto" src="media/editor/facial-recognition (1).png" />If Exist</label>
                                                </div>
                                                <div class="form-check mr-2 mt-2 sm:mt-0" onclick="pywebview.api.existmode('IfNot')">
                                                    <input id="radio-switch-6" class="form-check-input" type="radio" name="horizontal_radio_button" value="Ifnotexist">
                                                    <label class="form-check-label" for="radio-switch-6"><img  class="w-8 mr-auto ml-auto" src="media/editor/facial-recognition.png" />If Not Exist</label>
                                                </div>
                                            </div>
                                        </div>
                                        <br><br>
                                        <div class="mr-auto ml-auto"
                                            <label>Build / Copy</label>
                                            <div class="flex flex-col sm:flex-row mt-2">
                                            <button type="button" class="btn btn-outline-secondary text-gray-300 px-4 ml-2"   onclick="pywebview.api.functioncodebuilder('Func')"> <img class="mr-2" src="media/editor/code.png" height="30" width="30"/>  Build Function</button>
                                            <button type="button" class="btn btn-outline-secondary text-gray-300 px-4 ml-2"   onclick="pywebview.api.codecopy()"> <img  class="mr-2" src="media/editor/copy.png" height="30" width="30"/>  Copy Code</button>
                                            </div>
                                        </div>
                                        </div>
                    <div class="px-8 py-12 flex flex-col  flex-1 border-t sm:border-t-0 sm:border-l border-gray-300 dark:border-dark-5 border-dashed">
                        <div class="modal-body">
                         <div  class="text-center mr-auto ml-auto">
                            <a>
                                <span class="px-4 py-3 rounded-full bg-theme-1 text-white" id="functext">Object name</span>
                            
                            </a>
                            <br><br>
                            <strong class="text-center">Connected Objects</strong/
                            <br>

                            <div  class="flex flex-warp"><div id="funcconnect"></div></div>

                      
                    </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- END: General Report -->'''.format(**dict)
            #self.sidefoot='''<div id="tmpditor"></div>'''

    def editor(self,window,funccode):
        # demofunc=funccode.replace("@-","\\n"+"{"+"\\n")
        # demofunc=demofunc.replace("-@",'\\n'+"}")
        # demofunc=demofunc.replace("_"," ")
        # print('editor start')
        # print(funccode)
        funccode=funccode.replace("<pb>","\\n").replace("<ps>"," ").replace("<pn>","{").replace("<pe>","}").replace("<pc>",'"')
        dict = {'code': funccode}
        window.evaluate_js(""" 
                    var mainapp = document.getElementById('mainapp');
                    mainapp.innerHTML = '<div style="font-size: 22px " id="editor"></div> <div class="flex" style="margin-left: auto; margin-right: auto;" > <button class="btn btn-danger ml-3"> <img  class="w-8 mr-3 " src="media/editor/24-hours.svg" />  Restore </button>&nbsp;&nbsp;&nbsp;&nbsp; <button onclick="pywebview.api.editorchange()" class="btn btn-primary mr-3"> <img  class="w-8 mr-3 " src="media/editor/documents.svg" />  Save </button> </div>';
                    var editor = ace.edit("editor");
                    editor.setOption("showPrintMargin", false)
                    editor.setTheme("ace/theme/dracula");
                    editor.session.setMode("ace/mode/autohotkey");
                    editor.setValue('{code}');
                        """.format(**dict))
                    
       

        # result1 = window.evaluate_js(""" 
        #                     console.log("editor try")
                            
        #                  """)
        # print(result1)

    
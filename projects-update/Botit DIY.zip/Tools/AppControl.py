print('App Class')
class AppConfig(object):
    def __init__(self, APP_NAME='',COMPANY_NAME='',APP_VERSION=''):
            print('intin')
            self.APP_NAME = APP_NAME
            self.COMPANY_NAME=COMPANY_NAME
            self.APP_VERSION = APP_VERSION
           
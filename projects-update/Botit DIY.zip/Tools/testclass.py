
import json

class data:
    def __init__(self):
        print('hi')
        print(self.name)
        self.data="tesdf"

class settings:
    def __init__(self):

        print('settings')
        self.new="fdgdfg"

        

class bot(data,settings):
    def __init__(self):
        self.name="test"
        super().__init__()
        print('test')
        print(self.name)
        self.name="new"
        


test = bot()
print(test.name)
print(test.data)
print(test.new)
from pickle import TRUE
import numpy as np
import win32gui
import win32ui
import win32con
import win32api
import base64
import webview
import time
import random
from ctypes import windll
from PIL import Image
import ctypes
import subprocess
from random import randrange
import os

extrapath=''
if __name__ == '':
    extrapath= 'apps/Botit DIY/'



def getwindow(window):
   
   
    window.evaluate_js("""
            var select = document.getElementById("targetselect");
            var length = select.options.length;
            for (i = length-1; i >= 0; i--) {
            select.options[i] = null;
            }
                                """)
    def winEnumHandler( hwnd, ctx ):
        
        if win32gui.IsWindowVisible( hwnd ):
            if win32gui.GetWindowText( hwnd ) != '':
                
                tmptarget=win32gui.GetWindowText( hwnd )
               
                dict = {'winname':tmptarget}
              #  print(dict)
                result1 = window.evaluate_js("""
                var x = document.getElementById("targetselect");
                var option = document.createElement("option");
                option.text = "{winname}";
                x.add(option);
                    """.format(**dict))
                #print(tmptarget)
    
            
            

   # 
        
        
                
    win32gui.EnumWindows( winEnumHandler, None )
    


class WindowCapture:

    # properties
    w = 0
    h = 0
    hwnd = None
    cropped_x = 0
    cropped_y = 0
    offset_x = 0
    offset_y = 0

    # constructor
    def __init__(self, window_name):
        # find the handle for the window we want to capture
        print('Window capture Init',window_name)
        self.window_name= window_name
        self.hwnd = win32gui.FindWindow(None, window_name)
        if not self.hwnd:
            raise Exception('Window not found: {}'.format(window_name))

        # get the window size
        window_rect = win32gui.GetWindowRect(self.hwnd)
        # self.x=window_rect[0]
        # self.y=window_rect[1]
        self.w = window_rect[2] - window_rect[0]
        self.h = window_rect[3] - window_rect[1]
    
        # account for the window border and titlebar and cut them off
        # border_pixels = 8
        # titlebar_pixels = 30
        #self.w = self.w - (border_pixels * 2)
        #self.h = self.h - titlebar_pixels - border_pixels
        self.cropped_x = 0
        self.cropped_y = 0

        # set the cropped coordinates offset so we can translate screenshot
        # images into actual screen positions
        self.offset_x = window_rect[0] 
        self.offset_y = window_rect[0]
    
    def get_winowsize(self):
        window_rect = win32gui.GetWindowRect(self.hwnd)
        self.w = window_rect[2] - window_rect[0]
        self.h = window_rect[3] - window_rect[1]

    def set_windowsize(self,setW,setH):
        print(setW,setH)
        setW=int(setW)
        setH=int(setH)
        counter=0
        gate=True
        randomgate=True
        while gate == True:
            self.get_winowsize()
            print('Init target size',self.w,self.h,'my randomgate',randomgate)
            if setW == self.w and setH == self.h:
                print('window size correct')
                gate=False
                return "OK"
            else:
                print('window size incorrect')
                if counter > 0:
                    randnum=randrange(1,300)
                    if randomgate == True:
                        print('doing random True')
                        randomgate=False
                        try:
                            settmp=setH+randnum
                            settmp2=setW-randnum
                            win32gui.MoveWindow(self.hwnd, 0, 0, settmp2, settmp, True)
                        except:
                            print('fail window random move')
                    else:
                        print('doing random False')
                        try:
                            settmp=setW+randnum
                            settmp2=setH-randnum
                            win32gui.MoveWindow(self.hwnd, 0, 0, settmp, settmp2, True)
                        except:
                            print('fail window random move')
                        randomgate=True
                    
                    print('Random gate state',randomgate,'totla new random W/H',settmp )
                    
                    # time.sleep(0.15)
                    print('True set after random', setW, setH)
                    win32gui.MoveWindow(self.hwnd, 0, 0, setW, setH, True)
                    # time.sleep(0.15)

                
                else:
                    win32gui.MoveWindow(self.hwnd, 0, 0, setW, setH, True)
                    # time.sleep(0.15)

                counter+=1

                if counter==10:
                    print('my fail counter',counter)
                    
                    gate=False
                    return self.w,self.h

    def get_screenshot(self,width,height):
        hwndDC = win32gui.GetWindowDC(self.hwnd)
        mfcDC  = win32ui.CreateDCFromHandle(hwndDC)
        saveDC = mfcDC.CreateCompatibleDC()

        saveBitMap = win32ui.CreateBitmap()
        saveBitMap.CreateCompatibleBitmap(mfcDC, self.w, self.h)

        saveDC.SelectObject(saveBitMap)
        result = windll.user32.PrintWindow(self.hwnd, saveDC.GetSafeHdc(), 2)
        bmpinfo = saveBitMap.GetInfo()
        bmpstr = saveBitMap.GetBitmapBits(True)

        im = Image.frombuffer(
            'RGB',
            (bmpinfo['bmWidth'], bmpinfo['bmHeight']),
            bmpstr, 'raw', 'BGRX', 0, 1)

        win32gui.DeleteObject(saveBitMap.GetHandle())
        saveDC.DeleteDC()
        mfcDC.DeleteDC()
        win32gui.ReleaseDC(self.hwnd, hwndDC)

        if result == 1:
            #PrintWindow Succeeded
            im.save(extrapath+'templates/Builder/debug.png')
        elif result == 0:
            os.remove(extrapath+'templates/Builder/debug.png')
        try:
            randnum=randrange(3,30)
            # print(randnum)
            dict = {'numrand':randnum}
            colorc='''debug.png?{numrand}'''.format(**dict)
            # print(colorc)
        except:
            print('Random fail')
   
        return colorc

        
        # get the window image data
        wDC = win32gui.GetWindowDC(self.hwnd)
        dcObj = win32ui.CreateDCFromHandle(wDC)
        cDC = dcObj.CreateCompatibleDC()
        dataBitMap = win32ui.CreateBitmap()
        dataBitMap.CreateCompatibleBitmap(dcObj, self.w, self.h)
        cDC.SelectObject(dataBitMap)
        cDC.BitBlt((0, 0), (self.w, self.h), dcObj, (self.cropped_x, self.cropped_y), win32con.SRCCOPY)
        print(extrapath)
        # convert the raw data into a format opencv can read
        dataBitMap.SaveBitmapFile(cDC, extrapath+'templates/Builder/debug.png')
        # signedIntsArray = dataBitMap.GetBitmapBits(True)
        # img = np.fromstring(signedIntsArray, dtype='uint8')
        # img.shape = (self.h, self.w, 4)

        try:
            # free resources
            dcObj.DeleteDC()
            cDC.DeleteDC()
            win32gui.ReleaseDC(self.hwnd, wDC)
            win32gui.DeleteObject(dataBitMap.GetHandle())
        except:
            print('free fail')

        try:
            randnum=randrange(3,30)
            print(randnum)
            dict = {'numrand':randnum}
            colorc='''debug.png?{numrand}'''.format(**dict)
            print(colorc)
        except:
            print('Random fail')
   
        return colorc

        # def background_screenshot(hwnd, width, height):
        try:
            width=int(width)
            height=int(height)
            wDC = win32gui.GetWindowDC(self.hwnd)
            dcObj = win32ui.CreateDCFromHandle(wDC)
            cDC = dcObj.CreateCompatibleDC()
            dataBitMap = win32ui.CreateBitmap()
            dataBitMap.CreateCompatibleBitmap(dcObj, self.h, self.w)
            cDC.SelectObject(dataBitMap)
            cDC.BitBlt((0, 0), (self.w, self.h), dcObj, (0, 0), win32con.SRCCOPY)
            dataBitMap.SaveBitmapFile(cDC, 'debug.png')
            dcObj.DeleteDC()
            cDC.DeleteDC()
            win32gui.ReleaseDC(self.hwnd, wDC)
            win32gui.DeleteObject(dataBitMap.GetHandle())

            print('return get screen')
        except:
            print('capture failed')
        return
        wid=int(wid)
        hieg=int(hieg)
        window_name=self.window_name
        myscreen=subprocess.Popen(["BotitCloud/AutoHotkeyA32.exe", "BotitCloud/lib/Remotepy.ahk",window_name,str(wid),str(hieg)])
        myscreen.wait()

        import random

      
        randnum=random.randint(0, 9999)
     
        dict = {'numrand':randnum}
        colorc='''debug.png?{numrand}'''.format(**dict)
      
   
        return colorc
       

    
    def get_screenshot2(self,wid,hieg):
        wid=int(wid)
        hieg=int(hieg)
        x0, y0, x1, y1 = win32gui.GetWindowRect(self.hwnd)
        w = x1 - x0
        h = y1 - y0
     #   print(wid,hieg)
        while w!=wid and h==hieg:
            win32gui.MoveWindow(self.hwnd, x0, y0, w+7, h, True)
            time.sleep(0.1)
            win32gui.MoveWindow(self.hwnd, x0, y0, wid, hieg, True)
            time.sleep(0.5)
            x0, y0, x1, y1 = win32gui.GetWindowRect(self.hwnd)
            w = x1 - x0
            h = y1 - y0
            print(w,h)
            print('try')
            #print(w,h)
        # get the window image data
        print('done')
        print(self.window_name)
        window_name =self.window_name
        self.hwnd = win32gui.FindWindow(None, window_name)
        window_rect = win32gui.GetWindowRect(self.hwnd)
        self.w = window_rect[2] - window_rect[0]
        self.h = window_rect[3] - window_rect[1]
        wDC = win32gui.GetWindowDC(self.hwnd)
        dcObj = win32ui.CreateDCFromHandle(wDC)
        cDC = dcObj.CreateCompatibleDC()
        dataBitMap = win32ui.CreateBitmap()
        dataBitMap.CreateCompatibleBitmap(dcObj, self.w, self.h)
        cDC.SelectObject(dataBitMap)
        cDC.BitBlt((0, 0), (self.w, self.h), dcObj, (self.cropped_x, self.cropped_y), win32con.SRCCOPY)

        # convert the raw data into a format opencv can read
        dataBitMap.SaveBitmapFile(cDC, 'templates/Builder/debug.png')

        import random
        randnum=random.randint(0, 9999)
       # print(randnum)
        # os.remove("templates\Builder/debug.png")
      #  png_img = cv2.imencode('.png', img)
      #  b64_string = base64.b64encode(png_img[1]).decode('utf-8')
        #print(png_img)

        #  encoded_string = base64.b64encode(image_file.read())
      #  dict = {'imgbase64':b64_string}  
        #colorc="{imgbase64}".format(**dict)
        #colorc="data:image/png;base64,{imgbase64}".format(**dict)
        dict = {'numrand':randnum}
        colorc='''debug.png?{numrand}'''.format(**dict)
        #print(imgstring)
        #colorc="debug.png?"+randnum
       # print(colorc)
        dcObj.DeleteDC()
        cDC.DeleteDC()
        win32gui.ReleaseDC(self.hwnd, wDC)
        win32gui.DeleteObject(dataBitMap.GetHandle())
       # print(colorc)
   
        return colorc
    # find the name of the window you're interested in.
    # once you have it, update window_capture()
    # https://stackoverflow.com/questions/55547940/how-to-get-a-list-of-the-name-of-every-open-window
    def list_window_names(self):
        def winEnumHandler(hwnd, ctx):
            if win32gui.IsWindowVisible(hwnd):
                #print(hex(hwnd), win32gui.GetWindowText(hwnd))
                pass
        win32gui.EnumWindows(winEnumHandler, None)

    # translate a pixel position on a screenshot image to a pixel position on the screen.
    # pos = (x, y)
    # WARNING: if you move the window being captured after execution is started, this will
    # return incorrect coordinates, because the window position is only calculated in
    # the __init__ constructor.
    def get_screen_position(self, pos):
        return (pos[0] + self.offset_x, pos[0] + self.offset_y)



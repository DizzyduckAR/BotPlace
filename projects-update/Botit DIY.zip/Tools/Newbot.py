import json
import os
print('botdb Class')
class botdb(object):
    def __init__(self, botname):
        print('intin')
        self.name = botname
        self.game_data=open("./DB/Shadow/"+self.name+".json")
        self.data = json.load(self.game_data)
        #print(self.data)
        self.activearea="Bots"

    def DataRefresh(self):
        self.game_data=open("./DB/Shadow/"+self.name+".json")
        self.data = json.load(self.game_data)
        
    def GetSetting(self):
        self.settings = self.data["Settings"][0]
        self.version = self.settings['botver']
        self.imgversion = self.settings['botimgver']
        self.wid = self.settings['targetwidth']
        self.heig = self.settings['targetheight']
        self.thumb = self.settings['thumburl']
        self.system = self.settings['system']
        self.gui = self.settings['botgui']
        self.developer = self.settings['dev']
        # self.public = True
        print("Done Setting Get")

    def GetModes(self):
        self.modesRaw= self.data["modes"]

     #   print('self raw modes',self.modesRaw)
        self.modelist=[]
        indexer=0
        for item in self.modesRaw:
              #  print('self item',item)
                for other in item:
                   # print(other)
                    self.modelist.append(other)
                indexer += 1
    
    def GetObjs(self):
        self.objs = self.data['Objects']
        self.objlist=[]
        for item in self.objs:
            for key in item:
                self.objlist.append(key)
        print('New Get Obj List',self.objlist)

    def ActiveMode(self,mode):
        self.activemodename=mode
        print('self mode list',self.modelist)
        self.activemodeindx=self.modelist.index(mode)
        self.modeobjecets=[]
        try:
            print(self.data['modes'][self.activemodeindx][self.activemodename][0]['free'])
        except:pass
      
        try:
                    self.activefree=self.data['modes'][self.activemodeindx][self.activemodename][0]['free']
        except:pass
        try:
                    self.activesilver=self.data['modes'][self.activemodeindx][self.activemodename][0]['silver']
        except:pass
        try:
                    self.activegold=self.data['modes'][self.activemodeindx][self.activemodename][0]['gold']

        except:pass
        try:
            x = self.data['modes'][self.activemodeindx][self.activemodename][0]['objects'].split("|")
            for stuff in x:
                self.modeobjecets.append(stuff)
        except:pass
        #print(self.modesRaw[self.activemodeindx][self.activemodename])

    def ActiveObj(self,objname):
        self.activeobjectname=objname.lower()
        self.activeobjectindx=self.objlist.index(objname.lower())
        self.Aobjtype=self.objs[self.activeobjectindx][self.activeobjectname][0]['type']
       # print(self.Aobjtype)
        if self.Aobjtype == "Image":
            self.Aobjtol=self.objs[self.activeobjectindx][self.activeobjectname][0]['tol']
            self.Aobjscan=self.objs[self.activeobjectindx][self.activeobjectname][0]['scantype']
            #print(self.objs[self.activeobjectindx][self.activeobjectname][0]['scancolor'])
            self.Aobjcolor=self.objs[self.activeobjectindx][self.activeobjectname][0]['scancolor']
            self.Aobjclicks=self.objs[self.activeobjectindx][self.activeobjectname][0]['clicks']
            self.Aobjx1=self.objs[self.activeobjectindx][self.activeobjectname][0]['x1']
            self.Aobjy1=self.objs[self.activeobjectindx][self.activeobjectname][0]['y1']
            self.Aobjx2=self.objs[self.activeobjectindx][self.activeobjectname][0]['x2']
            self.Aobjy2=self.objs[self.activeobjectindx][self.activeobjectname][0]['y2']
            self.Aobjcolorstring=self.objs[self.activeobjectindx][self.activeobjectname][0]['colorstring']
            self.Aobjgraystring=self.objs[self.activeobjectindx][self.activeobjectname][0]['graystring']
            #print(self.Aobjcolorstring)
            #print(self.Aobjgraystring)
        if self.Aobjtype == "Pixel":
            self.Aobjtol=self.objs[self.activeobjectindx][self.activeobjectname][0]['tol']
            self.Aobjscan=self.objs[self.activeobjectindx][self.activeobjectname][0]['scantype']
            self.Aobjclicks=self.objs[self.activeobjectindx][self.activeobjectname][0]['clicks']
            self.pixelcolor=self.objs[self.activeobjectindx][self.activeobjectname][0]['pixelcolor']
            self.Aobjx1=self.objs[self.activeobjectindx][self.activeobjectname][0]['x1']
            self.Aobjy1=self.objs[self.activeobjectindx][self.activeobjectname][0]['y1']
            self.Aobjx2=self.objs[self.activeobjectindx][self.activeobjectname][0]['x2']
            self.Aobjy2=self.objs[self.activeobjectindx][self.activeobjectname][0]['y2']
            
        if self.Aobjtype == "Func":
            self.Aobjfunc=self.objs[self.activeobjectindx][self.activeobjectname][0]['objects']
            self.activecode=self.objs[self.activeobjectindx][self.activeobjectname][0]['code']
            self.funcobjecets=[]
            x = self.objs[self.activeobjectindx][self.activeobjectname][0]['objects'].split("|")
            for stuff in x:
                self.funcobjecets.append(stuff)

        if self.Aobjtype == "UIFunc":
          #  self.Aobjfunc=self.objs[self.activeobjectindx][self.activeobjectname][0]['objects']
            self.activecode=self.objs[self.activeobjectindx][self.activeobjectname][0]['code']
            # self.funcobjecets=[]
            # x = self.objs[self.activeobjectindx][self.activeobjectname][0]['objects'].split("|")
            # for stuff in x:
            #     self.funcobjecets.append(stuff)
            #print(self.funcobjecets)


    def DataAdd(self,mode,add):
        if mode == "Mode":
            # #modename=window.evaluate_js(''' document.getElementById("addmodename").value ''')
            # add="hjkhjk2"
            try:
                self.modelist.index(add)
            except:
                print("no obj")
                # modefree=window.evaluate_js(''' document.getElementById("addfree2").checked ''')
                # modesilver=window.evaluate_js(''' document.getElementById("addsilver2").checked ''')
                # modegold=window.evaluate_js(''' document.getElementById("addgold2").checked ''')
                
                #War Remove
                modefree=True
                modesilver=False
                modegold=True
                self.modesRaw.append(
                    {add:
                        [
                        {'free': modefree,'silver':modesilver ,'gold':modegold ,'objects':''}
                        ]
                    }
                )

                self.DataDump()
          
        if mode == "ToMode":
          #  print('ToMode',add)
            for item in add:
                print(item)
            
        if mode == "ToDB":
        #    print('ToDB',add)
            for item in add:
                print(item)

    def DataDump(self):
        #Write Settings
        print('dump wh',self.wid,self.heig)
        self.settings['botver'] = self.version
        self.settings['botimgver'] = self.imgversion
        self.settings['targetwidth'] = self.wid
        self.settings['targetheight'] = self.heig
        self.settings['thumburl'] = self.thumb
        self.settings['system'] = self.system
        self.settings['botgui'] =self.gui
        self.settings['dev'] = self.developer
        self.settings['public'] = True

        #Write Modes
        self.data['modes']=self.modesRaw

        #Write objects
        self.data['Objects']=self.objs
        json.dumps(self.data)
        with open('DB/Shadow/'+ self.name +'.json', mode='w') as f:
            f.write(json.dumps(self.data, indent=2))
        print('data dump ok')

    def saveactiveobjecet(self):
        print("start save")
       # name=self.activeobjectnameRaw
        
        tmp= self.activeobjectname
        tmp1= self.activeobjectindx
       # self.activeobjectname=tmp
       # self.activeobjectindex=tmp1
        self.objs[tmp1][tmp][0]['type']=self.Aobjtype
        if self.Aobjtype == "Image":
            self.objs[tmp1][tmp][0]['tol']=self.Aobjtol
            self.objs[tmp1][tmp][0]['scantype']=self.Aobjscan
            self.objs[tmp1][tmp][0]['scancolor']=self.Aobjcolor
            self.objs[tmp1][tmp][0]['clicks']=self.Aobjclicks
            self.objs[tmp1][tmp][0]['x1']=self.Aobjx1
            self.objs[tmp1][tmp][0]['y1']=self.Aobjy1
            self.objs[tmp1][tmp][0]['x2']=self.Aobjx2
            self.objs[tmp1][tmp][0]['y2']=self.Aobjy2
            self.objs[tmp1][tmp][0]['colorstring']=self.Aobjcolorstring
            self.objs[tmp1][tmp][0]['graystring']=self.Aobjgraystring
        if self.Aobjtype == "Pixel":
            self.objs[tmp1][tmp][0]['tol']=self.Aobjtol
            self.objs[tmp1][tmp][0]['scantype']=self.Aobjscan
            self.objs[tmp1][tmp][0]['clicks']=self.Aobjclicks
            self.objs[tmp1][tmp][0]['pixelcolor']=self.pixelcolor
            self.objs[tmp1][tmp][0]['x1']=self.Aobjx1
            self.objs[tmp1][tmp][0]['y1']=self.Aobjy1
            self.objs[tmp1][tmp][0]['x2']=self.Aobjx2
            self.objs[tmp1][tmp][0]['y2']=self.Aobjy2
            
        if self.Aobjtype == "Func":
            #print(self.activecode)
            self.objs[tmp1][tmp][0]['objects']=self.Aobjfunc
            self.objs[tmp1][tmp][0]['code']=self.activecode

        if self.Aobjtype == "UIFunc":
            #print(self.activecode)
           # self.objs[tmp1][tmp][0]['objects']=self.Aobjfunc
            self.objs[tmp1][tmp][0]['code']=self.activecode
            
        self.DataDump()
       # print('done active')


# mybot = bot("Test1")
# #print(mybot.name)
# mybot.GetSetting()
# #print(mybot.version,mybot.developer)
# mybot.GetModes()
# #print(mybot.modesRaw,mybot.modelist)
# mybot.GetObjs()
# #print(mybot.objs,mybot.objlist)
# mybot.ActiveMode('hjkhjk')
# #print(mybot.activemodename,mybot.activemodeindx)
# mybot.ActiveObj('dsfsdf')
# #print(mybot.activeobjectname,mybot.activeobjectindx,mybot.Aobjtype)

# mybot.DataAdd('Mode','Newmode')
# print(mybot.modesRaw,mybot.modelist)
# #mybot.DataAdd('ToMode',['test1','test2'])
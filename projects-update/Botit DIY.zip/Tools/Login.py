import requests, base64
from threading import Thread
import json


# from main import window,SigninURL


class LoginDB(object):
    print('LoginDB Class')
    def __init__(self, User,Pass,url,url2):
        print('try login init')
        self.User = User
        self.Pass= Pass
        self.HandUrl = url
        self.DataUrl = url2
    
    def GetDevHand(self):
      #  print(self.HandUrl)
        self.r = requests.get(self.HandUrl, auth=(self.User, self.Pass))
        self.data= self.r.json()
        print(self.data)
        
        t= Thread(target=self.logindb, args=(self.data,self.User, self.Pass,))
        t.start()
        self.rState=self.r.status_code

    def chkbotjson(self,botname):
        print('json chk')
        try:
            self.jsonchkdata=''
            tmp_data=open("DB/"+botname+".json")
            datatmp = json.load(tmp_data)
            self.jsonchkdata=datatmp
        #    print(datatmp["Settings"][0]['botver'])          
            self.version = datatmp["Settings"][0]['botver']
            self.imgversion = datatmp["Settings"][0]['botimgver']
            return True
        except:
            return False

    def logindb(self,r,myuser,mypass):
        print('Login DB')
        needupdate=[]
        self.botlist=[]
      
        rTmp=r
        for item in r:
            # print(item)
            vergate=False
            imggate=False
            botname=item["botname"]
            try:
                self.botlist.index(botname)
            except:
                print("Bot Added to List")
                self.botlist.append(botname)
       # print(self.botlist)
      #  print('self data',self.data)
        for bot in self.botlist:
          
            item=self.data[self.botlist.index(bot)]
            if self.chkbotjson(bot) == True:
                print('Json Found')
               # print(self.jsonchkdata)
                # settingappend= {"Settings":[{'botname': bot,'botver': item['botver'], 'botimgver': item['botimgver'], 'targetwidth': item['targetwidth'],
                #                             'targetheight': item['targetheight'],'thumburl': item['thumburl'],
                #                             'system': item['system'],'botgui': item['botgui'],'dev': item['dev'],'public':item['featured'],'code':item['Code']
                #     }]
                #     }
               # print(self.jsonchkdata["Settings"][0]["botname"])
                try:
                    self.jsonchkdata["Settings"][0]["botver"]=item['botver']
                    self.jsonchkdata["Settings"][0]["botimgver"]=item['botimgver']
                    self.jsonchkdata["Settings"][0]["targetwidth"]=item['targetwidth']
                    self.jsonchkdata["Settings"][0]["targetheight"]=item['targetheight']
                    self.jsonchkdata["Settings"][0]["thumburl"]=item['thumburl']
                    self.jsonchkdata["Settings"][0]["system"]=item['system']
                    self.jsonchkdata["Settings"][0]["botgui"]=item['botgui']
                    self.jsonchkdata["Settings"][0]["dev"]=item['dev']
                    self.jsonchkdata["Settings"][0]["public"]=item['featured']
                    self.jsonchkdata["Settings"][0]["Code"]=item['Code']
                except:pass
               # self.jsonchkdata["Settings"]=settingappend
                json.dumps(self.jsonchkdata)
                with open('DB/'+ bot +'.json', mode='w') as f:
                    f.write(json.dumps(self.jsonchkdata, indent=2))
            #    print('my bot',rTmp[self.botlist.index(bot)])
            #    print(rTmp[self.botlist.index(bot)])
              #  print('Local vers',bot,self.version,self.imgversion)
               # print('Online Version',rTmp[self.botlist.index(bot)]['botver'])

                if self.version == rTmp[self.botlist.index(bot)]['botver']:
                        print('Bot ver ok')
                        continue
                        
                else:
                    print('Bot ver Need Update')
                    vergate=True
                    imggate=True
                    try:
                        needupdate.index(bot)
                    except:
                        needupdate.append(bot)
                  
                    

                if self.imgversion == self.version == rTmp[self.botlist.index(bot)]['botimgver']:
                    print('Bot img ver ok')
                else:
                    print('Bot img ver Need Update')
                    vergate=True
                    imggate=True #temp to avoid dev breaking update
                    try:
                        needupdate.index(bot)
                    except:
                        needupdate.append(bot)
            else: 
                print(bot,'False')
                try:
                    datawrt = {"Settings":[{'botname': bot,'botver': item['botver'], 'botimgver': item['botimgver'], 'targetwidth': item['targetwidth'],
                                            'targetheight': item['targetheight'],'thumburl': item['thumburl'],
                                            'system': item['system'],'botgui': item['botgui'],'dev': item['dev'],'public':item['featured'],'Code':item['Code']
                    }],
                    "modes":[],
                    "Objects":[]
                    }
                    print('Bot Settings Build OK')
                    try:
                        needupdate.index(bot)
                    except:
                        needupdate.append(bot)
                    with open('DB/'+ item['botname'] +'.json', mode='w') as f:
                        f.write(json.dumps(datawrt, indent=2))
                except:print('Bot Settings Fail', bot)

                
                try:
                    print('Bot Modes Build Start')

                except:print('Bot Settings Fail', bot)
        print('Updates For',needupdate)
        # t2= Thread(target=self.Web2Json, args=(needupdate,))
        # t2.start()
        self.Web2Json(needupdate)
        return needupdate

       
        for item in r:
                vergate=False
                imggate=False
                botname=item["botname"]
                try:
                    self.botlist.index(botname)
                except:
                    print("no obj")
                    self.botlist.append(botname)
                

                #Check Bot Ver
                try:
                    tmp_data=open("DB/"+botname+".json")
                    datatmp = json.load(tmp_data)
                    settings = datatmp[botname][0]
                    version = settings['botver']
                    imgversion = settings['botimgver']
                    oldmodes = datatmp[botname][1]
                    oldobjects = datatmp[botname][2]

                    # print(oldmodes)
                    # print(oldobjects)
                    
                    #print(settings)
                    settingappend= {'botver': item['botver'], 'botimgver': item['botimgver'], 'targetwidth': item['targetwidth'],
                                        'targetheight': item['targetheight'],'thumburl': item['thumburl'],
                                        'system': item['system'],'botgui': item['botgui'],'dev': item['dev'],'public':item['featured'],'code':item['Code']}
                    datatmp[botname][0]=settingappend
                    json.dumps(datatmp)
                    with open('DB/'+ botname +'.json', mode='w') as f:
                        f.write(json.dumps(datatmp, indent=2))
                    

                    if item['botver'] == version:
                        print('Bot ver ok')
                        
                    else:
                        print('Bot ver Need Update')
                        vergate=True
                        imggate=True
                        

                    if item['botimgver'] == imgversion:
                        print('Bot img ver ok')
                    else:
                        print('Bot img ver Need Update')
                        vergate=True
                        imggate=True #temp to avoid dev breaking update

                    #print(vergate,imggate)
                    if vergate==True and imggate==True:
                        needupdate=botname+'|Full'
                        print('Full update' ,botname)
                        # url ="https://botplace.hopto.org/api/devdata/?format=json"
                        url = self.DataUrl
                        test = myuser
                        test2 = mypass
                        r = requests.get(url, auth=(test, test2),params = {"data": botname+'|Full'})
                        data= r.json()
                        
                        modeslist=[]
                    
                        for item2 in data:
                            print(item2["goldmodes"])
                            try:
                                tmp = json.loads(item2["goldmodes"])
                                for stuff in tmp:
                                    modeslist.append(stuff)
                                    #print('Mode name',stuff)
                                    #print('Mode Data',tmp[stuff])
                            except:print('error in gold modes')

                    # print(modeslist)
                        #Modes Write
                        datatmp[botname][1]['modes']=[]
                    

                        #for item in datatmp:
                            #print(jdata[item][1]['modes'])
                        for mode in modeslist:
                            datatmp[botname][1]['modes'].append(
                        
                            {mode:
                                [
                                {'free': False,'silver':False ,'gold':True ,'objects':tmp[mode]}
                                ]
                            }
                        
                        )
                        
                        print('start silver')
                        
                        #Silver modes
                        #for item in data:
                            #print(item)
                        try:
                            tmp = json.loads(datatmp[botname]["silvermodes"])
                            for stuff in tmp:
                            #  print('Mode name',stuff)
                            # print('Mode index',modeslist.index(stuff))
                                #print(datatmp[botname][1]['modes'][modeslist.index(stuff)][stuff][0]['silver'])
                                datatmp[botname][1]['modes'][modeslist.index(stuff)][stuff][0]['silver']=True
                                # print('Mode Data',tmp[stuff])
                        except:pass
                        # with open('DB/'+ botname +'.json', mode='w') as f:
                        #     f.write(json.dumps(datatmp, indent=2))
                        print('start Free')

                        
                        #Silver modes
                        #for item in data:
                            #print(item)
                        try:
                            tmp = json.loads(datatmp[botname]["freemodes"])
                            for stuff in tmp:
                                datatmp[botname][1]['modes'][modeslist.index(stuff)][stuff][0]['free']=True

                        except:pass

                        print('Start obj writer')
                    # print(data)
                        #Object Write
                        datatmp[botname][2]['Objects']=[]
                        ### Start Obj Get
                        objlist=[]
                    # for item in data:
                            #print(item)
                            #print(item["imgcalls"])
                        try:
                            tmp = json.loads(data[0]["imgcalls"])
                            for stuff in tmp:
                                #print('obj name',stuff)
                                objlist.append(stuff)
                                #print('Mode name',stuff)
                                #print('obj Data',tmp[stuff])
                        except:pass

                        print('My object List',objlist)
                        
                        for item in datatmp:
                        # print('Obj list',datatmp[botname][2]['Objects'])

                            for obj in objlist:
                    #         print(obj)
                                args=tmp[obj].split("|")
                                if args[0]=="Image":
                                    print('image')
                                    try:
                                        datatmp[botname][2]['Objects'].append(
                                        {obj:
                                            [
                                            {'type':args[0],'tol':args[1] ,'scantype':args[2] ,'scancolor':args[3],'clicks':args[4],'x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                                            ]
                                        })
                                    except:
                                        datatmp[botname][2]['Objects'].append(
                                        {obj:
                                            [
                                            {'type':args[0],'tol':'' ,'scantype':'' ,'scancolor':'','clicks':'','x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                                            ]
                                        })

                                if args[0]=="Pixel":
                                    print('Pixel')
                                    try:
                                        datatmp[botname][2]['Objects'].append(
                                            {obj:
                                                [
                                                {'type': args[0],'tol':args[1] ,'scantype':args[2] ,'clicks':args[3],'pixelcolor':args[4],'x1':'','y1':'','x2':'','y2':''}
                                                ]
                                            })
                                    except:
                                        datatmp[botname][2]['Objects'].append(
                                        {obj:
                                            [
                                            {'type':args[0],'tol':'' ,'scantype':'' ,'clicks':'','pixelcolor':'','x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                                            ]
                                        })
                                if args[0]=="Func":
                                    print('Func')
                                    try:
                            
                                        funcobjs=tmp[obj].replace("Func|", '')
                                    
                                    # print(funcobjs)
                                    except:
                                        funcobjs=''
                                    
                                    if funcobjs=="Func" or funcobjs=="func":
                                        funcobjs=''

                                    datatmp[botname][2]['Objects'].append(
                                        {obj:
                                            [
                                            {'type': args[0],'objects':funcobjs,'code':''}
                                            ]
                                        }
                                    
                                    )
                                
                                if args[0]=="UIFunc":
                                    print('UIFunc')
                                
                                    datatmp[botname][2]['Objects'].append(
                                        {obj:
                                            [
                                            {'type': args[0],'code':''}
                                            ]
                                        }
                                    
                                    )
                        
                        #img calls Imgxy
                        try:
                            tmp = json.loads(data[0]["imgxy"])
                            
                            #print(tmp)
                            for stuff in tmp:
                                #print('ImageXY  ',tmp[stuff])
                                args=tmp[stuff].split("|")
                            # print(args[0])
                            # print(jdata[botname][2]['Objects'][objlist.index(stuff)][stuff][0])
                                datatmp[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['x1']=args[0]
                                datatmp[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['y1']=args[1]
                                datatmp[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['x2']=args[2]
                                datatmp[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['y2']=args[3]
                                # #print('obj name',stuff)
                                # objlist.append(stuff)
                                #print('Mode name',stuff)
                                #print('obj Data',tmp[stuff])
                        except:pass

                        #Img Strings
                        try:
                            tmp = json.loads(data[0]["botimages"])
                            for stuff in tmp:
                                datatmp[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['colorstring']=tmp[stuff]
                        except:pass


                        #Func Code Writter
                        try:
                            tmp = json.loads(data[0]["botfunctions"])
                        # print(tmp)
                            # print(datatmp[botname][2]['Objects'])
                            for item in tmp:
                                # print(item)
                                # print(tmp[item])
                                # print(jdata[botname][2]['Objects'][objlist.index(item)][item][0]['code'])
                                datatmp[botname][2]['Objects'][objlist.index(item)][item][0]['code']=tmp[item]
                                #jdata[botname][2]['Objects'][modeslist.index(item)][item][0]['free']=
                                

                        
                        except:
                            print('nocode')
                            #code=''


                        json.dumps(datatmp)
                        with open('DB/'+ botname +'.json', mode='w') as f:
                            f.write(json.dumps(datatmp, indent=2))
                        continue
                        
                
                        
                    if vergate!=True and imggate!=True:
                        needupdate=botname+'|skip'
                        continue

                    
                #Bot is Missing
                except:
                    print('no json')
                
                
                

                datawrt = {item['botname']:[{'botver': item['botver'], 'botimgver': item['botimgver'], 'targetwidth': item['targetwidth'],
                                        'targetheight': item['targetheight'],'thumburl': item['thumburl'],
                                        'system': item['system'],'botgui': item['botgui'],'dev': item['dev'],'public':item['featured'],'code':item['Code']
                }]}
            
                with open('DB/'+ item['botname'] +'.json', mode='w') as f:
                    f.write(json.dumps(datawrt, indent=2))

                #url ="https://botplace.hopto.org/api/devdata/?format=json"
                url ="http://127.0.0.1:8000/api/devdata/?format=json"
                test = myuser
                test2 = mypass
                r = requests.get(url, auth=(test, test2),params = {"data": botname+'|Full'})
                data= r.json()
                #print(data)
                
                modeslist=[]
                for item in data:
                    
                    try:
                        tmp = json.loads(item["goldmodes"])
                        for stuff in tmp:
                            modeslist.append(stuff)
                            #print('Mode name',stuff)
                            #print('Mode Data',tmp[stuff])
                    except:pass

                print(modeslist)
                
                json_data=open('DB/'+ botname +'.json')
                jdata = json.load(json_data)
            # jdata[botname][1]['modes']=[]
                for item in jdata:
                    test =jdata[item].append(
                    {'modes':[]
                        
                    })
                json.dumps(jdata)
                
                #print(jdata[0]['modes'][1])
                
                ### Start mode Get
                for item in jdata:
                    #print(jdata[item][1]['modes'])
                    for mode in modeslist:
                        jdata[botname][1]['modes'].append(
                    
                        {mode:
                            [
                            {'free': False,'silver':False ,'gold':True ,'objects':tmp[mode]}
                            ]
                        }
                    
                    )

                print('start silver')
                #Silver modes
                for item in data:
                    #print(item)
                    try:
                        tmp = json.loads(item["silvermodes"])
                        for stuff in tmp:
                        #  print('Mode name',stuff)
                        # print('Mode index',modeslist.index(stuff))
                            #print(jdata[botname][1]['modes'][modeslist.index(stuff)][stuff][0]['silver'])
                            jdata[botname][1]['modes'][modeslist.index(stuff)][stuff][0]['silver']=True
                            # print('Mode Data',tmp[stuff])
                    except:pass

                print('start Free')
                #Silver modes
                for item in data:
                    #print(item)
                    try:
                        tmp = json.loads(item["freemodes"])
                        for stuff in tmp:
                            jdata[botname][1]['modes'][modeslist.index(stuff)][stuff][0]['free']=True

                    except:pass
                
    
                with open('DB/'+botname +'.json', mode='w') as f:
                    f.write(json.dumps(jdata, indent=2))
                

                json_data=open('DB/'+ botname +'.json')
                jdata = json.load(json_data)
                for item in jdata:
                    test =jdata[item].append(
                    {'Objects':[]
                        
                    })
                json_string = json.dumps(jdata)

                ### Start Obj Get
                objlist=[]
                for item in data:
                    #print(item["imgcalls"])
                    try:
                        tmp = json.loads(item["imgcalls"])
                        for stuff in tmp:
                            #print('obj name',stuff)
                            objlist.append(stuff)
                            #print('Mode name',stuff)
                            #print('obj Data',tmp[stuff])
                    except:pass

                print('My object List',objlist)
                
                for item in jdata:
                # print('Obj list',jdata[botname][2]['Objects'])

                    for obj in objlist:
                        #print(obj)
                        args=tmp[obj].split("|")
                        if args[0]=="Image":
                            print('image')
                            try:
                                jdata[botname][2]['Objects'].append(
                                {obj:
                                    [
                                    {'type':args[0],'tol':args[1] ,'scantype':args[2] ,'scancolor':args[3],'clicks':args[4],'x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                                    ]
                                })
                            except:
                                jdata[botname][2]['Objects'].append(
                                {obj:
                                    [
                                    {'type':args[0],'tol':'' ,'scantype':'' ,'scancolor':'','clicks':'','x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                                    ]
                                })
                        if args[0]=="Pixel":
                            print('Pixel')
                            try:
                                jdata[botname][2]['Objects'].append(
                                    {obj:
                                        [
                                        {'type': args[0],'tol':args[1] ,'scantype':args[2] ,'clicks':args[3],'pixelcolor':args[4],'x1':'','y1':'','x2':'','y2':''}
                                        ]
                                    })
                            except:
                                jdata[botname][2]['Objects'].append(
                                {obj:
                                    [
                                    {'type':args[0],'tol':'' ,'scantype':'' ,'clicks':'','pixelcolor':'','x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                                    ]
                                })
                        if args[0]=="Func":
                            print('Func')
                            try:
                                #print(tmp[obj])
                                funcobjs=tmp[obj].replace("Func|", '')
                            
                            # print(funcobjs)
                            except:
                                funcobjs=''
                            
                            if funcobjs=="Func" or funcobjs=="func":
                                funcobjs=''
                            jdata[botname][2]['Objects'].append(
                                {obj:
                                    [
                                    {'type': args[0],'objects':funcobjs,'code':''}
                                    ]
                                }
                            
                            )
                        if args[0]=="UIFunc":
                            print('UIFunc')
                            
                            jdata[botname][2]['Objects'].append(
                                {obj:
                                    [
                                    {'type': args[0],'code':''}
                                    ]
                                }
                            
                            )
                
                #img calls Imgxy
                try:
                    tmp = json.loads(data[0]["imgxy"])
                    
                    #print(tmp)
                    for stuff in tmp:
                        #print('ImageXY  ',tmp[stuff])
                        try:
                            args=tmp[stuff].split("|")
                        # print(args[0])
                        # print(jdata[botname][2]['Objects'][objlist.index(stuff)][stuff][0])
                            jdata[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['x1']=args[0]
                            jdata[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['y1']=args[1]
                            jdata[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['x2']=args[2]
                            jdata[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['y2']=args[3]
                        # #print('obj name',stuff)
                        # objlist.append(stuff)
                        #print('Mode name',stuff)
                        #print('obj Data',tmp[stuff])
                        except:print('Error in build', stuff)
                except:pass

                #Img Strings
                try:
                    tmp = json.loads(data[0]["botimages"])
                    for stuff in tmp:
                        jdata[botname][2]['Objects'][objlist.index(stuff)][stuff][0]['colorstring']=tmp[stuff]
                except:pass


                #Func Code Writter
                try:
                    tmp = json.loads(data[0]["botfunctions"])
                # print(tmp)
                    # print(jdata[botname][2]['Objects'])
                    for item in tmp:
                        # print(item)
                        # print(tmp[item])
                        # print(jdata[botname][2]['Objects'][objlist.index(item)][item][0]['code'])
                        jdata[botname][2]['Objects'][objlist.index(item)][item][0]['code']=tmp[item]
                        #jdata[botname][2]['Objects'][modeslist.index(item)][item][0]['free']=
                        

                
                except:
                    print('nocode')
                    #code=''
                        
                with open('DB/'+botname +'.json', mode='w') as f:
                    f.write(json.dumps(jdata, indent=2))
                
        return self.botlist
       
    def Web2Json(self,list):
        # print(list)
        json_data = json.dumps(list)
        # print(json_data)
        r = requests.get(self.DataUrl,auth=(self.User, self.Pass),json=json_data)
        data= r.json()
        botcount=0
      #  print(data)
        for item in data:
            #print(item)
            # print(item['botname'])
          
            
            tmp_data=open("DB/"+item['botname']+".json")
            datatmp = json.load(tmp_data)
            modeslist=[]
            try:
                #print(item["goldmodes"])
                tmp = json.loads(item["goldmodes"])
                for stuff in tmp:
                    modeslist.append(stuff)
            except:print('Fail in gold get',item['botname'])
            datatmp['modes']=[]
            for mode in modeslist:
                    #set base
                    print('strating Mode',mode)
                    datatmp['modes'].append(
                
                    {mode:
                        [
                        {'free': False,'silver':False ,'gold':True ,'objects':tmp[mode]}
                        ]
                    }
                
                    )
            try:
                tmp = json.loads(item["silvermodes"])
                for stuff in tmp:
                    datatmp['modes'][modeslist.index(stuff)][stuff][0]['silver']=True
            except:print('Silver Fail role')

            try:
                tmp = json.loads(item["freemodes"])
                for stuff in tmp:
                    datatmp['modes'][modeslist.index(stuff)][stuff][0]['free']=True
            except:
                print(mode,'Free Fail role')
                tmp = None

            
            
            #Object List
            datatmp['Objects']=[]

            objlist=[]
            try:
                tmp = json.loads(item["imgcalls"])
                for stuff in tmp:
                    #print('obj name',stuff)
                    objlist.append(stuff)
                    #print('Mode name',stuff)
                    #print('obj Data',tmp[stuff])
            except:pass

            print('My object List',objlist)
            #Object Base
            for obj in objlist:
                #print(obj)
                args=tmp[obj].split("|")
                if args[0]=="Image":
                    print('image')
                    try:
                        datatmp['Objects'].append(
                        {obj:
                            [
                            {'type':args[0],'tol':args[1] ,'scantype':args[2] ,'scancolor':args[3],'clicks':args[4],'x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                            ]
                        })
                    except:
                        datatmp['Objects'].append(
                        {obj:
                            [
                            {'type':args[0],'tol':'' ,'scantype':'' ,'scancolor':'','clicks':'','x1':"",'y1':"",'x2':"",'y2':"",'colorstring':"",'graystring':""}
                            ]
                        })
                if args[0]=="Pixel":
                    print('Pixel')
                    try:
                        datatmp['Objects'].append(
                            {obj:
                                [
                                {'type': args[0],'tol':args[1] ,'scantype':args[2] ,'clicks':args[3],'pixelcolor':args[4],'x1':'','y1':'','x2':'','y2':''}
                                ]
                            })
                    except:
                        datatmp['Objects'].append(
                        {obj:
                            [
                            {'type':args[0],'tol':'' ,'scantype':'' ,'clicks':'','pixelcolor':'','x1':"",'y1':"",'x2':"",'y2':""}
                            ]
                        })
                if args[0]=="Func":
                    print('Func')
                    try:
                        #print(tmp[obj])
                        funcobjs=tmp[obj].replace("Func|", '')
                    
                    # print(funcobjs)
                    except:
                        funcobjs=''
                    
                    if funcobjs=="Func" or funcobjs=="func":
                        funcobjs=''
                    datatmp['Objects'].append(
                        {obj:
                            [
                            {'type': args[0],'objects':funcobjs,'code':''}
                            ]
                        }
                    
                    )
                if args[0]=="UIFunc":
                    print('UIFunc')
                    
                    datatmp['Objects'].append(
                        {obj:
                            [
                            {'type': args[0],'code':''}
                            ]
                        }
                    
                    )
            
            #XY
            try:
               # print('Req Xy',item["imgxy"])
                tmp = json.loads(item["imgxy"])
                
               # print('Img XY',tmp)
                for stuff in tmp:
                   # print('ImageXY  ',tmp[stuff])
                    try:
                        args=tmp[stuff].split("|")
                    # print(args[0])
                    # print(datatmp['Objects'][objlist.index(stuff)][stuff][0])
                        datatmp['Objects'][objlist.index(stuff)][stuff][0]['x1']=args[0]
                        datatmp['Objects'][objlist.index(stuff)][stuff][0]['y1']=args[1]
                        datatmp['Objects'][objlist.index(stuff)][stuff][0]['x2']=args[2]
                        datatmp['Objects'][objlist.index(stuff)][stuff][0]['y2']=args[3]
                    # #print('obj name',stuff)
                    # objlist.append(stuff)
                    #print('Mode name',stuff)
                    #print('obj Data',tmp[stuff])
                    except:print('Error in build', stuff)
            except:pass
            # with open('DB/'+item['botname'] +'.json', mode='w') as f:
            #             f.write(json.dumps(datatmp, indent=2))
            #Img Strings
            try:
                tmp = json.loads(item["botimages"])
                for stuff in tmp:
                    try:
                        datatmp['Objects'][objlist.index(stuff)][stuff][0]['colorstring']=tmp[stuff]
                    except:pass
            except:pass

            #Func Code Writter
            try:
                tmp = json.loads(item["botfunctions"])
               # print(tmp)
                pass
                # print(jdata[botname][2]['Objects'])
                for itemcode in tmp:
                 #   print(itemcode)
                  #  print(tmp[itemcode])
                    # print(jdata[botname][2]['Objects'][objlist.index(item)][item][0]['code'])
                    try:
                        datatmp['Objects'][objlist.index(itemcode)][itemcode][0]['code']=tmp[itemcode]
                        #jdata[botname][2]['Objects'][modeslist.index(item)][item][0]['free']=
                    except:pass

            
            except:
                print('nocode')


            with open('DB/'+item['botname'] +'.json', mode='w') as f:
                        f.write(json.dumps(datatmp, indent=2))
            botcount=+1
            continue

                    # try:
                    #     tmp = json.loads(item["silvermodes"])
                    #     for stuff in tmp:
                    #         print('Silver',stuff)
                    #         if stuff==mode:
                    #             datatmp['modes'][modeslist.index(stuff)][stuff][0]['silver']=True
                            
                    #         # print('Mode Data',tmp[stuff])
                    # except:print(mode,'Silver Fail role')
                    # try:
                    #     tmp = json.loads(item["freemodes"])
                    #     print(tmp)
                    #     for stuff in tmp:
                    #         print(modeslist.index(stuff))
                    #         datatmp['modes'][modeslist.index(stuff)][stuff][0]['free']=True

                    # except:print(mode,'Free Fail role')

                    # try:
                    #     tmp = json.loads(item["freemodes"])
                    #     for stuff in tmp:
                    #         print('Free',stuff)
                    #         if stuff==mode:
                    #             datatmp['modes'][modeslist.index(stuff)][stuff][0]['free']=True
                    #         # print('Mode Data',tmp[stuff])
                    # except:print(mode,'Free Fail role')


            # print('data modes after',datatmp['modes'])
            # with open('DB/'+item['botname'] +'.json', mode='w') as f:
            #             f.write(json.dumps(datatmp, indent=2))


        #object

        
            # for item2 in data:
            #     print(item2["goldmodes"])
            #     try:
            #         tmp = json.loads(item2["goldmodes"])
            #         for stuff in tmp:
            #             modeslist.append(stuff)
            #             #print('Mode name',stuff)
            #             #print('Mode Data',tmp[stuff])
            #     except:print('error in gold modes')

            # # print(modeslist)
            # #Modes Write
            # datatmp[botname][1]['modes']=[]
        

            # #for item in datatmp:
            #     #print(jdata[item][1]['modes'])
            # for mode in modeslist:
            #     datatmp[botname][1]['modes'].append(
            
            #     {mode:
            #         [
            #         {'free': False,'silver':False ,'gold':True ,'objects':tmp[mode]}
            #         ]
            #     }
            
            # )

    


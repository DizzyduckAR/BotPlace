
try:

    global extrapath
    #print(mycrashteste)
    from Tools.Mrimporter import *
    from Tools.Frameless import *
    
    import os
    #adeptive root
    filename= os.path.basename(__file__)
    filename=filename.replace('.py','')
    
    #Start UI
    # print('app name var',__name__)
    extrapath=''
    if __name__ == '':
        
        extrapath= 'apps/'+filename+'/'
    # print('Extra Path',extrapath)
    StartWin=extrapath+'templates/Builder/builder.html'


    

    #App HardCoded
    
    APP_NAME = 'Botit DIY'
    COMPANY_NAME = 'Buck and Moncey'
    APP_VERSION = '1.0.8'
    DRAG_REGION_SELECTOR = '.pywebview-drag-region'



    # print(__name__)

    #DB folder make
    # if os.path.isfile('templates/Builder/builder.html'):

    # else:
    try:
        os.mkdir('DB/')
    except:
        pass

    try:

        os.mkdir('DB/Shadow/')
    except:
        pass
   
    



    #On shown stop window on top
    def on_shown():
        print('on shown')
        setsizer(window,80,80)  #Set widow to 80% of W and H

        global UImain
        #Top window setup
        UImain = appui(window,APP_NAME,APP_VERSION,COMPANY_NAME)
        UImain.setdata()
        #Home app set
        UImain.appHome()
        UImain.senddata('Set','mainapp',UImain.Homemain)


        window.on_top = False
        

        window.shown -= on_shown







    class Api:

       
        ####Login
        def BuilderInit(self):
            UImain = appui(window,APP_NAME,APP_VERSION,COMPANY_NAME)
        #  print('Home',UImain.main)
            UImain.setdata()
            UImain.appHome()
            UImain.senddata('Set','mainapp',UImain.Homemain)

        def pushtoapplocal(self):
            # print('bot data',self.botobject.data)
            with open('DB/'+ self.botobject.name +'.json', mode='w') as f:
                    f.write(json.dumps(self.botobject.data, indent=2))
            
        def midsceencalc(self):
            print('mid screen')
        # print(window.width, window.height)
            #ox, oy = win32api.GetCursorPos()
            #print(ox, oy)
            midw = round((GetSystemMetrics(0)-window.width)/2)
            midh = round((GetSystemMetrics(1)-window.height)/2)
            #print(midw,midh)

            if midw > 0:
                movew=midw
            else:movew=0

            if midh > 0:
                moveh=midh
            else:moveh=0

            window.move(movew,moveh)
        
        def resizedrag(self):
            doresize(window)

        def b64EncodeString(self,msg):
            print(msg)
            msg_bytes = msg.encode('ascii')
            base64_bytes = base64.b64encode(msg_bytes)
            return base64_bytes.decode('ascii')

        def hextriplet(self,colortuple):
            return '#' + ''.join(f'{i:02X}' for i in colortuple)

        def getpixel2(self):
            
            print('Press Ctrl-C to quit')
        
            result1 = window.evaluate_js(""" 
                    var result = document.getElementById('result');
                    console.log(result)
                    result.innerHTML = '';
                    $('#result').empty().append('<div style="width:100px;height:100px;background-color: #fff;"></div>');
                        """)
        
            try:
                import time
                while True:
                    
                    x,y = pyautogui.position()
                    positionStr = 'X:'+ str(x).rjust(4) + ' Y:' + str(y).rjust(4) #rjust() The string method will adjust the coordinates right so that they occupy the same width .
                    pixelColor = pyautogui.screenshot().getpixel((x,y))
                    dict = {'pixelclr':self.hextriplet(pixelColor)}
                    result1 = window.evaluate_js(""" 
                    var result = document.getElementById('result');
                    result.innerHTML = '';
                    $('#result').empty().append('<div style="width:100px;height:100px;background-color:{pixelclr};"></div>');
                        """.format(**dict))
                            #typer='''<div style="width:100px;height:100px;background-color: #{pixelcolor};"></div> '''
                #  typer='''<div style="width:60px;height:60px;background-color: {pixelcolor};"></div>'''.format(**dict)
                    
                    if win32api.GetKeyState(0x01) == -127:
                        print('left click')
                        dict = {'pixelclr':self.hextriplet(pixelColor)}
                        result1 = window.evaluate_js(""" 
                        var oldimgnest = document.getElementById('oldimgnest');
                        oldimgnest.innerHTML = '';
                        $('#oldimgnest').empty().append('<div style="width:100px;height:100px;background-color:{pixelclr};"></div>');
                            """.format(**dict))
                    
                        result1 = window.evaluate_js("""
                                var cropper = new Cropper(document.getElementById('image'), {
                    
                                movable: false,
                                zoomable: false,
                                rotatable: false,
                                scalable: false,
                                autoCropArea: 0.05,
                                crop(event) {
                                    document.getElementById('cropx1').value= Math.ceil(event.detail.x);
                                    document.getElementById('cropy1').value= Math.ceil(event.detail.y);
                                    document.getElementById('cropx2').value= Math.ceil(event.detail.width+event.detail.x);
                                    document.getElementById('cropy2').value= Math.ceil(event.detail.height+event.detail.y);
                                    
                                },
                                });
                        """)
                    
                        tmp= self.botobject.activeobjectname.lower()
                        tmp1= self.botobject.activeobjectindx
                        pixtmp=self.hextriplet(pixelColor).replace("#", "0x")
                    # print(pixtmp,name)
                        self.botobject.pixelcolor=pixtmp
                        self.botobject.saveactiveobjecet()
                        self.whereIM(self.botobject.activearea)
                        break
                    time.sleep(0.03)


            except KeyboardInterrupt:
                print('\ndone')
        
        def destroydebug(self):
            print('delete debug')
            os.remove(extrapath+"templates/Builder/debug.png")

        def getscreen(self):
            os.chdir(os.path.dirname(os.path.abspath(__file__)))
            
            testvar = '''document.getElementById("targetselect").value'''
            windowname = window.evaluate_js(testvar)
            # windowsize=Api.gettargetsize(windowname)
            # print(windowsize)
            wincap = WindowCapture(windowname)
            # print(self.botobject.wid,self.botobject.heig)
            Api.ifloader("on")
            sizestate=wincap.set_windowsize(self.botobject.wid,self.botobject.heig)
            if sizestate != "OK":
                dict={"w":sizestate[0],"h":sizestate[1]}
                result = win32api.MessageBox(None,"Warning Window Size Change Detected!\n\nSaving New Size into Bot Settings Can Break old image Object Cords!!\n\nPress OK to allow Reset Bot Target Size into\n\nNew W {w} New H {h}".format(**dict), "Critical Warning!",1 | 0x00001000)
                if result == 1:
                    
                    self.botobject.wid = str(sizestate[0])
                    self.botobject.heig = str(sizestate[1])
                    self.botobject.data['Settings'][0]['targetwidth'] = str(sizestate[0])
                    self.botobject.data['Settings'][0]['targetheight'] = str(sizestate[1])

                    try:
                        self.botobject.DataDump()
                        self.botobject.DataRefresh()
                        
                    except:
                        print('fail dump new size')
                    try:
                        self.botobject.GetSetting()
                    except:
                        print('fail dump new size')
                    
                    self.editobj(self.botobject.activeobjectname,'')
                        
                    Api.ifloader("off")
                    return
                    
           
            time.sleep(0.2)

            screenshot = wincap.get_screenshot(self.botobject.wid,self.botobject.heig)
            Api.ifloader("off")
          
                    

            jsrunnerdb={'Set':[{'idname':'image','changename':'src','setvalue':screenshot}]}
            self.jsmaker(jsrunnerdb)

        def homereset(self):
            UImain = appui(window,APP_NAME,APP_VERSION,COMPANY_NAME)
            UImain.setdata()
            UImain.appHome()
            UImain.senddata('Set','mainapp',UImain.Homemain)

        ###New
        ###Cards
        def botlister():
            botlist=[]
            path_to_json = 'DB/'
            for file_name in [file for file in os.listdir(path_to_json) if file.endswith('.json')]:
                file_name=file_name.split('.json')[:-1]
                botlist.append(file_name[0])
            return botlist

        def botcards(self):
            Api.ifloader("on")
            UImain.senddata('Clear','mainhead','')
            
            #build bot cards
            UImain.botcardmaker('Bots',Api.botlister())

            #set mainapp
            UImain.senddata('Set','mainapp',UImain.cards)

            Api.ifloader("off")

        def modecards(self):
            if self.chkload():
                Api.ifloader("on")
                self.botobject.activearea="Modes"
                self.botobject.DataRefresh()
            # self.botobject.getdata()
                self.botobject.GetModes()
                UImain.maintop('Modes','')
                UImain.senddata('Set','mainhead',UImain.topmain)
                UImain.botcardmaker('Modes',self.botobject.modesRaw)
                UImain.senddata('Set','mainapp',UImain.cards)
                Api.ifloader("off")
        
        def objectscards(self,name):
            
            if self.chkload():
                Api.ifloader("on")
                self.botobject.activearea="Modesobj"
                self.botobject.ActiveMode(name)
                UImain.maintop('Objects',self.botobject.activemodename)
                UImain.senddata('Set','mainhead',UImain.topmain)
                UImain.botcardmaker('Objects',self.botobject)
                UImain.senddata('Set','mainapp',UImain.cards)
                Api.ifloader("off")

        def totalcards(self):
            self.botobject.GetObjs()
        # print(self.botobject.objs)
            if self.chkload():
                Api.ifloader("on")
                self.botobject.activearea="Total"
                UImain.maintop('Total','')
                UImain.senddata('Set','mainhead',UImain.topmain)
                UImain.botcardmaker('Total',self.botobject)
                UImain.senddata('Set','mainapp',UImain.cards)
                Api.ifloader("off")
        
        def functioncards(self):
            self.botobject.GetObjs()
            if self.chkload():
                print("func cards")
                Api.ifloader("on")
                self.botobject.activearea="Functions"
                UImain.maintop('Total','')
                UImain.senddata('Set','mainhead',UImain.topmain)
                UImain.botcardmaker('TotalFunc',self.botobject)
                UImain.senddata('Set','mainapp',UImain.cards)
                Api.ifloader("off")

        ####Function Editor
        def funcedit(self,name):
            print("Editor",name)
            self.botobject.activearea="Editor"
            print('t2')
            #print(self.tmpactivefunc)
            self.tmpactivefunc=name
            #print(self.tmpactivefunc)
            self.botobject.ActiveObj(name)

            #print(self.botobject.activecode)
            UImain.editor(window,self.botobject.activecode)
            UImain.maintop('Editor','')
            UImain.senddata('Set','mainhead',UImain.topmain)

          

        def funceditactiveobj(self,name,mode):
            print(name)
            self.botobject.ActiveObj(name)
            if mode == "Image":
                print(self.botobject.Aobjscan,self.botobject.Aobjcolor,self.botobject.Aobjclicks)
                # print(self.botobject.activeobjectname, self.botobject.Aobjclicks)
                jsrunnerdb={'Set':[{'idname':'functext','changename':'innerHTML','setvalue':name}]}
                self.jsmaker(jsrunnerdb)
                dict = {'imgbase64':self.botobject.Aobjcolorstring}
                tmpimg='''data:image/png;base64,{imgbase64}'''.format(**dict)
                jsrunnerdb={'Set':[{'idname':'funcbimg','changename':'src','setvalue':tmpimg}]}
                self.jsmaker(jsrunnerdb)
                jsrunnerdb={'Set':[{'idname':'funcbimg2','changename':'src','setvalue':tmpimg}]}
                self.jsmaker(jsrunnerdb)
                if self.botobject.Aobjscan == "area" or self.botobject.Aobjscan == "Area":
                    print('if area')
                    jsrunnerdb={'Set':[{'idname':'funcarea','changename':'selectedIndex','setvalue':0}]}
                    
                else:
                    print('window')
                    jsrunnerdb={'Set':[{'idname':'funcarea','changename':'selectedIndex','setvalue':1}]}
                
                self.jsmaker(jsrunnerdb)
                    #print(self.botobject.activeobjectname,self.botobject.Aobjcolor)
                
                if self.botobject.Aobjcolor == "G" or self.botobject.Aobjcolor == "Grayscale":
                    print(self.botobject.Aobjcolor)
                    jsrunnerdb={'Set':[{'idname':'funccolor','changename':'selectedIndex','setvalue':1}]}
                else:
                    
                #if self.botobject.Aobjcolor == "C" or  self.botobject.Aobjcolor == "Color":
                    print('if color')
                    jsrunnerdb={'Set':[{'idname':'funccolor','changename':'selectedIndex','setvalue':0}]}
                
                self.jsmaker(jsrunnerdb)

                if self.botobject.Aobjclicks == "0":
                    jsrunnerdb={'Set':[{'idname':'funcclick','changename':'selectedIndex','setvalue':1}]}
                    

                if self.botobject.Aobjclicks == "1":
                    jsrunnerdb={'Set':[{'idname':'funcclick','changename':'selectedIndex','setvalue':0}]}
                self.jsmaker(jsrunnerdb)

                jsrunnerdb={'Set':[{'idname':'funcobjecttol','changename':'value','setvalue':self.botobject.Aobjtol}]}
                self.jsmaker(jsrunnerdb)

            if mode=="Pixel":
                print('pixel')
                print(self.botobject.Aobjscan,self.botobject.pixelcolor,self.botobject.Aobjclicks,self.botobject.Aobjtol)
                jsrunnerdb={'Set':[{'idname':'functext','changename':'innerHTML','setvalue':name}]}
                self.jsmaker(jsrunnerdb)
                try:
                    x = self.botobject.pixelcolor.replace("0x", "")
                # print(x)
                except:
                    print('no 0x')
                dict = {'pixelcolor':x}
                print(dict)
                democard='''<div  style="width:100px;height:100px;background-color: #{pixelcolor};"></div>&nbsp;&nbsp;'''.format(**dict)
                # dict = {'imgbase64':self.botobject.Aobjcolorstring}
                # tmpimg='''data:image/png;base64,{imgbase64}'''.format(**dict)
                jsrunnerdb={'Set':[{'idname':'changepix','changename':'innerHTML ','setvalue':democard}]}
                self.jsmaker(jsrunnerdb)
                # jsrunnerdb={'Set':[{'idname':'funcbimg2','changename':'src','setvalue':tmpimg}]}
                # self.jsmaker(jsrunnerdb)
                if self.botobject.Aobjscan == "area" or self.botobject.Aobjscan == "Area":
                    print('if area')
                    jsrunnerdb={'Set':[{'idname':'funcarea','changename':'selectedIndex','setvalue':0}]}
                    
                else:
                    print('window')
                    jsrunnerdb={'Set':[{'idname':'funcarea','changename':'selectedIndex','setvalue':1}]}
                
                self.jsmaker(jsrunnerdb)
                    #print(self.botobject.activeobjectname,self.botobject.Aobjcolor)
                
            

                if self.botobject.Aobjclicks == "0":
                    jsrunnerdb={'Set':[{'idname':'funcclick','changename':'selectedIndex','setvalue':1}]}
                    

                if self.botobject.Aobjclicks == "1":
                    jsrunnerdb={'Set':[{'idname':'funcclick','changename':'selectedIndex','setvalue':0}]}
                self.jsmaker(jsrunnerdb)

                jsrunnerdb={'Set':[{'idname':'funcobjecttol','changename':'value','setvalue':self.botobject.Aobjtol}]}
                self.jsmaker(jsrunnerdb)
        
            if mode=="Func":
                jsrunnerdb={'Set':[{'idname':'functext','changename':'innerHTML','setvalue':name}]}
                self.jsmaker(jsrunnerdb)

                tmpvar=""
                x = self.botobject.Aobjfunc.split("|")
                for some in x:
                    if some == "Func":
                        continue
                    dict = {'modename':some}
                    test= '''<span  class=" mb-4 ml-2 px-5    rounded-full bg-theme-6 text-gray-300 "><strong>{modename}</strong></span> '''.format(**dict)
                    tmpvar = test +  tmpvar
            # print(tmpvar)
                jsrunnerdb={'Set':[{'idname':'funcconnect','changename':'innerHTML','setvalue':tmpvar}]}
                self.jsmaker(jsrunnerdb)

            if mode=="UIFunc":
                jsrunnerdb={'Set':[{'idname':'functext','changename':'innerHTML','setvalue':name}]}
                self.jsmaker(jsrunnerdb)

          
        def functiontop(self,name):
            print(name)
            self.ifmode='None'
            UImain.autocodemodal(name,self.botobject)
            UImain.senddata('Set','modallhead',UImain.sidehead)
            UImain.senddata('Set','modallbody',UImain.sidebody)
            # funccode=funccode.replace("<pb>","\\n").replace("<ps>"," ").replace("<pn>","{").replace("<pe>","}").replace("<pc>",'"')
            # dict = {'code': funccode}
            window.evaluate_js(""" 
                        var mainapp2 = document.getElementById('modallfoot');
                        mainapp2.innerHTML = '<div style="font-size: 22px " id="editor2"></div>';
                        var editor2 = ace.edit("editor2");
                        editor2.setOption("showPrintMargin", false)
                        editor2.setTheme("ace/theme/dracula");
                        editor2.session.setMode("ace/mode/autohotkey");
                            """)
            # UImain.senddata('Set','modallfoot',UImain.sidefoot)

        def existmode(self,name):
            print(name)
            self.ifmode=name

        def Controllermode(self,name):
            print(name)
            # print(self.botobject.system)
            self.botobject.system=name
            self.botobject.DataDump()
            #print('Done',self.botobject.system)

            # ifmode=name
        
        def controllersave(self):
            self.botobject.DataDump()

        def codecopy(self):
            window.evaluate_js(""" 
                        var editor2 = ace.edit("editor2");
                        var code2 = editor2.getSession().getValue();
                        pywebview.api.autofuncread(code2)
                            """)
               

        def autofuncread(self,code):
            print(code)

            clipboard.copy(code)
            print('done')

        def functioncodebuilder(self,mode):
            if mode=="Image":
                print(self.ifmode,mode)
                jsrunnerdb={'Get':[{'idname':'functext','changename':'innerHTML','setvalue':''}]}
                codename=self.jsmaker(jsrunnerdb)
                if codename=="Object name":
                    print('no object picked')
                    return

                jsrunnerdb={'Get':[{'idname':'funcarea','changename':'value','setvalue':''}]}
                codearea=self.jsmaker(jsrunnerdb)

                jsrunnerdb={'Get':[{'idname':'funcarea','changename':'value','setvalue':''}]}
                codearea=self.jsmaker(jsrunnerdb)

                jsrunnerdb={'Get':[{'idname':'funccolor','changename':'value','setvalue':''}]}
                codecolor=self.jsmaker(jsrunnerdb)

                jsrunnerdb={'Get':[{'idname':'funcclick','changename':'value','setvalue':''}]}
                codeclick=self.jsmaker(jsrunnerdb)

                jsrunnerdb={'Get':[{'idname':'funcobjecttol','changename':'value','setvalue':''}]}
                codetol=self.jsmaker(jsrunnerdb)

                if self.ifmode=="None":
                    ifmode2=''
                    myex1=''
                    myex2=''
                if self.ifmode=="IfEx":
                    ifmode2='exist:='
                    myex1='\\nif exist'
                    myex2='\\n{\\n ;Your Next Code Here\\n}'
                
                if self.ifmode=="IfNot":
                    ifmode2='exist:='
                    myex1='\\nif not exist'
                    myex2='\\n{\\n ;Your Next Code Here\\n}'

                if codearea == "Window":
                    codearea='Single'
                else:
                    codearea='area'
                
                if codecolor == "Color":
                    codecolor='C'
                else:
                    codecolor='G'
                
                if codeclick == "Click":
                    codeclick=1
                else:
                    codeclick=0
                

                
                dict = {'imgname':codename,'imgtol':codetol,'imgarea':codearea,'imgcol':codecolor,'imgclick':codeclick,'myif':ifmode2,'myifextra1':myex1,'myifextra2':myex2}
                self.codebuilder='''{myif}BotItScanner("{imgname}",{imgtol},"{imgarea}","{imgcol}",{imgclick},neutron){myifextra1}{myifextra2}'''.format(**dict)
                #print(codename,codearea,codecolor,codeclick,codetol)
                
                
                dict = {'code': self.codebuilder}
                window.evaluate_js(""" 
                        var editor2 = ace.edit("editor2");
                        editor2.setValue('{code}');
                            """.format(**dict))

            if mode=="Pixel":
                print('pix')
                jsrunnerdb={'Get':[{'idname':'functext','changename':'innerHTML','setvalue':''}]}
                codename=self.jsmaker(jsrunnerdb)
                if codename=="Object name":
                    print('no object picked')
                    return

                jsrunnerdb={'Get':[{'idname':'funcarea','changename':'value','setvalue':''}]}
                codearea=self.jsmaker(jsrunnerdb)

                jsrunnerdb={'Get':[{'idname':'funcarea','changename':'value','setvalue':''}]}
                codearea=self.jsmaker(jsrunnerdb)

                jsrunnerdb={'Get':[{'idname':'funcclick','changename':'value','setvalue':''}]}
                codeclick=self.jsmaker(jsrunnerdb)

                jsrunnerdb={'Get':[{'idname':'funcobjecttol','changename':'value','setvalue':''}]}
                codetol=self.jsmaker(jsrunnerdb)

                if self.ifmode=="None":
                    ifmode2=''
                    myex1=''
                    myex2=''
                if self.ifmode=="IfEx":
                    ifmode2='exist:='
                    myex1='\\nif exist'
                    myex2='\\n{\\n ;Your Next Code Here\\n}'
                
                if self.ifmode=="IfNot":
                    ifmode2='exist:='
                    myex1='\\nif not exist'
                    myex2='\\n{\\n ;Your Next Code Here\\n}'

                if codearea == "Area" or codearea == "area":
                    codearea='area'
                else:
                    codearea='Single'
                
            
                if codeclick == "Click":
                    codeclick=1
                else:
                    codeclick=0
                

                
                dict = {'imgname':codename,'imgtol':codetol,'imgarea':codearea,'imgclick':codeclick,'myif':ifmode2,'myifextra1':myex1,'myifextra2':myex2}
                self.codebuilder='''{myif}BotItPixel("{imgname}",{imgtol},"{imgarea}",{imgclick},neutron){myifextra1}{myifextra2}'''.format(**dict)
                #print(codename,codearea,codeclick,codetol)
                dict = {'code': self.codebuilder}
                window.evaluate_js(""" 
                        var editor2 = ace.edit("editor2");
                        editor2.setValue('{code}');
                            """.format(**dict))
            if mode=="Func":
                print('Func')
                
                jsrunnerdb={'Get':[{'idname':'functext','changename':'innerHTML','setvalue':''}]}
                codename=self.jsmaker(jsrunnerdb)
                if codename=="Object name":
                    print('no object picked')
                    return

                if self.ifmode=="None":
                    ifmode2=''
                    myex1=''
                    myex2=''
                if self.ifmode=="IfEx":
                    ifmode2='exist:='
                    myex1='\\nif exist'
                    myex2='\\n{\\n ;Your Next Code Here\\n}'
                
                if self.ifmode=="IfNot":
                    ifmode2='exist:='
                    myex1='\\nif not exist'
                    myex2='\\n{\\n ;Your Next Code Here\\n}'


                
                dict = {'imgname':codename,'myif':ifmode2,'myifextra1':myex1,'myifextra2':myex2}
                self.codebuilder=''';Raw\\n{myif}{imgname}(neutron){myifextra1}{myifextra2}'''.format(**dict)
                #print(codename,codearea,codeclick,codetol)
                dict = {'code': self.codebuilder}
                window.evaluate_js(""" 
                        var editor2 = ace.edit("editor2");
                        editor2.setValue('{code}');
                            """.format(**dict))
        
        
            #UIFunc
            if mode=="UIFunc":
                print('UIFunc')
                
                jsrunnerdb={'Get':[{'idname':'functext','changename':'innerHTML','setvalue':''}]}
                codename=self.jsmaker(jsrunnerdb)
                if codename=="Object name":
                    print('no object picked')
                    return

                if self.ifmode=="None":
                    ifmode2=''
                    myex1=''
                    myex2=''
                if self.ifmode=="IfEx":
                    ifmode2='exist:='
                    myex1='\\nif exist'
                    myex2='\\n{\\n ;Your Next Code Here\\n}'
                
                if self.ifmode=="IfNot":
                    ifmode2='exist:='
                    myex1='\\nif not exist'
                    myex2='\\n{\\n ;Your Next Code Here\\n}'


                
                dict = {'imgname':codename,'myif':ifmode2,'myifextra1':myex1,'myifextra2':myex2}
                self.codebuilder=''';Raw\\n{myif}{imgname}(neutron){myifextra1}{myifextra2}'''.format(**dict)
                #print(codename,codearea,codeclick,codetol)
                dict = {'code': self.codebuilder}
                window.evaluate_js(""" 
                        var editor2 = ace.edit("editor2");
                        editor2.setValue('{code}');
                            """.format(**dict))
        
        ###SideMenu
        def botsidemenu(self,name):

            
        
            #self.botobject = bot(name)
            self.botobject = botdb(name)
        
            self.botobject.GetSetting()
        
            self.botobject.GetModes()
        
            self.botobject.GetObjs()
        
            systemid =str(self.botobject.system)
            
            if "Nox" == systemid or "nox" == systemid:
                sysid=0
            
            if "BlueStacks" == systemid:
            # print('im in')
                systemid=1
            # print(systemid)

            if "Bluestacks" == systemid:
                #print('found')
                sysid=1
            if "Chrome" == systemid:
                sysid=2
            if "Human" == systemid:
                sysid=3
            # print(sysid)
            print('start')
            UImain.Sidemenu('Bot',self.botobject)
            print('start1')
            UImain.senddata('Set','sidehead',UImain.sidehead)
            UImain.senddata('Set','sidebody',UImain.sidebody)
            UImain.senddata('Set','sidefoot',UImain.sidefoot)
            print('start2')
            jsrunnerdb={'Set':[{'idname':'botsubsys','changename':'selectedIndex','setvalue':int(sysid)}]}
            self.jsmaker(jsrunnerdb)
            #print(self.botobject.public)
            print('start3')
            # if self.botobject.public == True:
            #     jsrunnerdb={'Set':[{'idname':'publicchk','changename':'checked','setvalue':"True"}]}
            # else:
            #     jsrunnerdb={'Set':[{'idname':'publicchk','changename':'checked','setvalue':''}]}
            self.jsmaker(jsrunnerdb)
        
        def modesubmenu(self,name):
            
        # print('start mode',name)
            self.botobject.ActiveMode(name)
        #   name=self.botobject.activeobjectnameRaw
            UImain.Sidemenu('Mode',self.botobject)
            UImain.senddata('Set','sidehead',UImain.sidehead)
            UImain.senddata('Set','sidebody',UImain.sidebody)
            UImain.senddata('Set','sidefoot',UImain.sidefoot)
            try:
                if self.botobject.activefree == True or self.botobject.activefree == "True":
                    jsrunnerdb={'Set':[{'idname':'addfree','changename':'checked','setvalue':"True"}]}
                else:
                    jsrunnerdb={'Set':[{'idname':'addfree','changename':'checked','setvalue':''}]}
                self.jsmaker(jsrunnerdb)
            
                if self.botobject.activesilver == True or self.botobject.activesilver == "True":
                    jsrunnerdb={'Set':[{'idname':'addsilver','changename':'checked','setvalue':"True"}]}
                else:
                    jsrunnerdb={'Set':[{'idname':'addsilver','changename':'checked','setvalue':''}]}
                self.jsmaker(jsrunnerdb)

                if self.botobject.activegold == True or self.botobject.activegold == "True":
                    jsrunnerdb={'Set':[{'idname':'addgold','changename':'checked','setvalue':"True"}]}
                else:
                    jsrunnerdb={'Set':[{'idname':'addgold','changename':'checked','setvalue':''}]}
                self.jsmaker(jsrunnerdb)
            except:
                print("no modes")
            
        def objsubmenu(self,name):
            #print('sub')
            self.botobject.ActiveObj(name)
        #   name=self.botobject.activeobjectnameRaw
            UImain.Sidemenu('Object',self.botobject)
            #print("try side foot",UImain.sidefoot)
            UImain.senddata('Set','sidehead',UImain.sidehead)
            UImain.senddata('Set','sidebody',UImain.sidebody)
            UImain.senddata('Set','sidefoot',UImain.sidefoot)
            if self.botobject.Aobjtype == "Image":
                if self.botobject.Aobjscan == "area" or self.botobject.Aobjscan == "Area":
                    jsrunnerdb={'Set':[{'idname':'objecttype','changename':'selectedIndex','setvalue':0}]}
                    self.jsmaker(jsrunnerdb)
                
                else:
                    jsrunnerdb={'Set':[{'idname':'objecttype','changename':'selectedIndex','setvalue':1}]}
                    self.jsmaker(jsrunnerdb)
                
                
                #print(self.botobject.activeobjectname,self.botobject.Aobjcolor)
                if self.botobject.Aobjcolor == "G" or self.botobject.Aobjcolor == "Grayscale":
                    jsrunnerdb={'Set':[{'idname':'objectcolor','changename':'selectedIndex','setvalue':1}]}
                    
                if self.botobject.Aobjcolor == "C" or  self.botobject.Aobjcolor == "Color":
                    jsrunnerdb={'Set':[{'idname':'objectcolor','changename':'selectedIndex','setvalue':0}]}
                
                self.jsmaker(jsrunnerdb)

                if self.botobject.Aobjclicks == "0":
                    jsrunnerdb={'Set':[{'idname':'objectclick','changename':'selectedIndex','setvalue':1}]}
                

                if self.botobject.Aobjclicks == "1":
                    jsrunnerdb={'Set':[{'idname':'objectclick','changename':'selectedIndex','setvalue':0}]}
                self.jsmaker(jsrunnerdb)
            
            if self.botobject.Aobjtype == "Pixel":
                #print(self.botobject.Aobjscan,self.botobject.Aobjclicks)
            
                if self.botobject.Aobjscan == "area" or self.botobject.Aobjscan =="Area":
                    jsrunnerdb={'Set':[{'idname':'objecttype','changename':'selectedIndex','setvalue':0}]}
                
                else:
                    jsrunnerdb={'Set':[{'idname':'objecttype','changename':'selectedIndex','setvalue':1}]}
            
                self.jsmaker(jsrunnerdb)
                
            # print(self.botobject.Aobjclicks)
                if self.botobject.Aobjclicks == "0":
                # print('no')
                    jsrunnerdb={'Set':[{'idname':'objectclick','changename':'selectedIndex','setvalue':1}]}
                

                else:
                    jsrunnerdb={'Set':[{'idname':'objectclick','changename':'selectedIndex','setvalue':0}]}
                self.jsmaker(jsrunnerdb)
            
        ###Modals
        
        def loadbot(self,name,code):
                print(name)
                Api.ifloader("on")
                if code == "loadbot":
                    try:
                        game_data=open("DB/Shadow/"+name+".json")

                    except:
                        shutil.copy2("DB/"+name+".json", "DB/Shadow/"+name+".json")
                    
                    self.botobject = botdb(name)
                    # print(self.botobject)
                    
                    try:
                        print('before compare')
                        jsoncompare(window,self.botobject)
                        print('after compare')

                    except:
                        
                        shutil.copy2("DB/"+name+".json", "DB/Shadow/"+name+".json")
                        game_data=open("DB/Shadow/"+name+".json")
                        gamedata = json.load(game_data)
                        print('json copy')

                    print('compare done')
                    #json backup
                    name=self.botobject.name
                    try:
                        os.mkdir('DB/Shadow/'+self.botobject.name)
                    except:
                        print("folder already build")
                        pass


                    try:
                        os.stat('DB/Shadow/'+name)
                        import datetime

                        time_now  = datetime.datetime.now().strftime('%m_%d_%Y_%H_%M_%S') 
                        shutil.copy2("DB/Shadow/"+name+".json","DB/Shadow/"+name+"/"+time_now+".json" )
                        import glob


                        files = glob.glob("DB/Shadow/"+name+"/"+"*")
                        files.sort(key=os.path.getmtime)
                    
                        if len(files)>9:
                            print('warning')
                            os.remove(files[0])
                
                    except:
                        print('no bck')
                        os.mkdir('DB/Shadow/'+name+'/')
                        

                    self.loadtoggle=True
                    jsrunnerdb={'Set':[{'idname':'botpickname','changename':'innerHTML','setvalue':name}]}
                    self.jsmaker(jsrunnerdb)

                    jsrunnerdb={'Set':[{'idname':'botpickimg','changename':'src','setvalue':self.botobject.thumb}]}
                    self.jsmaker(jsrunnerdb)
                    
                    
                Api.ifloader("off")
        
        def addbot(self):
            print('addbot')

            UImain.modalsmake("Addbot",'')

            UImain.senddata('Set','modalshead',UImain.sidehead)

            UImain.senddata('Set','modalsbody',UImain.sidebody)

            UImain.senddata('Set','modalsfoot',UImain.sidefoot)
            print('done addbot')

        def addmode(self):
            #print('add mode')
            if self.chkload():
                UImain.modalsmake("Addmode",self.botobject)
                UImain.senddata('Set','modalshead',UImain.sidehead)
                UImain.senddata('Set','modalsbody',UImain.sidebody)
                UImain.senddata('Set','modalsfoot',UImain.sidefoot)
            
            else:
                print('fail1')
                UImain.modalsmake("fail",'')
                UImain.senddata('Set','modalshead',UImain.sidehead)
                UImain.senddata('Set','modalsbody',UImain.sidebody)
                UImain.senddata('Set','modalsfoot',UImain.sidefoot)

        def botsettings(self):
            print('bot set')
            if self.chkload():
                UImain.modalsmake("BotSett",self.botobject)
                UImain.senddata('Set','modalshead',UImain.sidehead)
                UImain.senddata('Set','modalsbody',UImain.sidebody)
                UImain.senddata('Set','modalsfoot',UImain.sidefoot)
            
            else:
                print('fail1')
                UImain.modalsmake("fail",'')
                UImain.senddata('Set','modalshead',UImain.sidehead)
                UImain.senddata('Set','modalsbody',UImain.sidebody)
                UImain.senddata('Set','modalsfoot',UImain.sidefoot)

        def addobj(self,type):
            
            if self.chkload():
            # testvar = ''' document.getElementById('addstuffbtn').innerHTML = ` ` '''
            # test = window.evaluate_js(testvar)
                if type == "image":
                    UImain.modalsmake("Addimage",'')
                    UImain.senddata('Set','modalshead',UImain.sidehead)
                    UImain.senddata('Set','modalsbody',UImain.sidebody)
                    UImain.senddata('Set','modalsfoot',UImain.sidefoot)
                    
                    

                if type == "pixel":
                    UImain.modalsmake("Addpixel",'')
                    UImain.senddata('Set','modalshead',UImain.sidehead)
                    UImain.senddata('Set','modalsbody',UImain.sidebody)
                    UImain.senddata('Set','modalsfoot',UImain.sidefoot)
                    return
                            

                if type == "func":
                    UImain.modalsmake("Addfunc",'')
                    UImain.senddata('Set','modalshead',UImain.sidehead)
                    UImain.senddata('Set','modalsbody',UImain.sidebody)
                    UImain.senddata('Set','modalsfoot',UImain.sidefoot)
                    return
                if type == "UIfunc":
                    UImain.modalsmake("AddUIfunc",'')
                    UImain.senddata('Set','modalshead',UImain.sidehead)
                    UImain.senddata('Set','modalsbody',UImain.sidebody)
                    UImain.senddata('Set','modalsfoot',UImain.sidefoot)
                    return
            else:
                print('fail1')
                UImain.modalsmake("fail",'')
                UImain.senddata('Set','modalshead',UImain.sidehead)
                UImain.senddata('Set','modalsbody',UImain.sidebody)
                UImain.senddata('Set','modalsfoot',UImain.sidefoot)
        
        def addtomode(self):
            UImain.modalsmake("Addtomode",self.botobject)
            UImain.senddata('Set','modallhead',UImain.sidehead)
            UImain.senddata('Set','modallbody',UImain.sidebody)
            UImain.senddata('Set','modallfoot',UImain.sidefoot)

        def editobj(self,name,img):
            #print(name,img)
            self.botobject.ActiveObj(name)
            UImain.modalsmake("Editobj",self.botobject)
            UImain.senddata('Set','modallhead',UImain.sidehead)
            UImain.senddata('Set','modallbody',UImain.sidebody)
            UImain.senddata('Set','modallfoot',UImain.sidefoot)

        
            name=self.botobject.activeobjectname
            type=self.botobject.Aobjtype
            botw=self.botobject.wid
            both=self.botobject.heig
        # img=""
            #print(name,type,botw,both,img)
        # print(type)
            if type == "Image":
            # print(type)
                testvar= '''document.getElementsByName("multibtn")[0].id="buttoncrop" '''
                test = window.evaluate_js(testvar)

                testvar= '''document.getElementsByName("multibtnimg")[0].src="media/editmenu/crop.svg"'''
                test = window.evaluate_js(testvar)
            # print(test)

                testvar= '''document.getElementsByName("multibtntxt")[0].innerHTML="Crop" '''
                test = window.evaluate_js(testvar)
            
                if img == "":
                    result1 = window.evaluate_js(""" 
                    var oldimgnest2 = document.getElementById('oldimgnest');
                    oldimgnest2.innerHTML = '';
                    $('#oldimgnest').empty().append('<img class="mt-3"  id="oldimg2" src="media/submenu/picture.svg">');
                        """ )
                else:
                    result1 = window.evaluate_js(""" 
                    var oldimgnest2 = document.getElementById('oldimgnest');
                    oldimgnest2.innerHTML = '';
                    $('#oldimgnest').empty().append('<img class="mt-3" id="oldimg2" src="media/submenu/picture.svg">');
                        """ )

                    jsrunnerdb={'Set':[{'idname':'oldimg2','changename':'src','setvalue':"data:image/png;base64,"+img}]}
                    self.jsmaker(jsrunnerdb)

            if type == "Pixel":
                
                img= img.replace("0x", "")
            # print('i fallow',img)
                testvar= '''document.getElementsByName("multibtn")[0].id="btnpixel" '''
                test = window.evaluate_js(testvar)
                testvar= '''document.getElementsByName("multibtnimg")[0].src="media/editmenu/022-dropper-1.svg"'''
                test = window.evaluate_js(testvar)
                testvar= '''document.getElementsByName("multibtntxt")[0].innerHTML="Get Pixel" '''
                test = window.evaluate_js(testvar)
                if img == "":

                    result1 = window.evaluate_js(""" 
                    var oldimgnest2 = document.getElementById('oldimgnest');
                    oldimgnest2.innerHTML = '';
                    $('#oldimgnest').empty().append(''<div style="width:100px;height:100px;background-color: #fff;"></div>');

                    var result2 = document.getElementById('result');
                    result2.innerHTML = '';
                    $('#result').empty().append(''<div style="width:100px;height:100px;background-color: #fff;"></div>');
                        """ )
                    #jsrunnerdb={'Set':[{'idname':'oldimg2','changename':'src','setvalue':''}]}
                else:
                # print('deep sea baby')
                    dict = {'img2':img}
                    result1 = window.evaluate_js(""" 
                    var oldimgnest2 = document.getElementById('oldimgnest');
                    oldimgnest2.innerHTML = '';
                    $('#oldimgnest').empty().append('<div style="width:100px;height:100px;background-color: #{img2};"></div>');
                        """.format(**dict))
                    
                    #jsrunnerdb={'Set':[{'idname':'oldimg2','changename':'src','setvalue':''}]}
            # self.jsmaker(jsrunnerdb)
            # print(test)
            # print('t3')
            
            if type == "func":
            # print(type)
                testvar= '''document.getElementsByName("multibtn")[0].id="" '''
            #test = window.evaluate_js(testvar)

            # testvar= '''document.getElementsByName("multibtn")[0].id '''
            # test = window.evaluate_js(testvar)
            # print(test)


            jsrunnerdb={'Set':[{'idname':'editobjname','changename':'innerHTML','setvalue':"<strong> Obj Name: "+name+"</strong>"}]}
            self.jsmaker(jsrunnerdb)

            # jsrunnerdb={'Set':[{'idname':'editobjtype','changename':'innerHTML','setvalue':"<strong>Obj Type: "+type+"</strong>"}]}
            # self.jsmaker(jsrunnerdb)

            jsrunnerdb={'Set':[{'idname':'editobjtrgw','changename':'innerHTML','setvalue':"<strong>Target Width: "+str(botw)+"</strong>"}]}
            self.jsmaker(jsrunnerdb)


            jsrunnerdb={'Set':[{'idname':'editobjtrgh','changename':'innerHTML','setvalue':"<strong>Target Height: "+str(both)+"</strong>"}]}
            self.jsmaker(jsrunnerdb)

        def help(self):
            print("api test")
            UImain.modalsmake("Help",'')
        #  print(UImain.sidebody)
            UImain.senddata('Set','modallhead',UImain.sidehead)
            UImain.senddata('Set','modallbody',UImain.sidebody)
            UImain.senddata('Set','modallfoot',UImain.sidefoot)
        ###TopBar
        def objaddremove(self,mode,type):
            #print(mode,type)
            #print('start2')
            checkedlist=[]
            checkedlist2=[]
            if type == "modes":
            # print('remove modes')
            # print(self.botobject.modelist)
                for item in self.botobject.modelist:
                    try:
                        dict = {'name':item}
                        test=window.evaluate_js(''' document.getElementById("{name}moddel").checked '''.format(**dict))
                        if test == True:
                            checkedlist.append(item)

                    except:
                        pass

                checkedlist.reverse()

                for item in checkedlist:
                    indexer=0
                    for key in self.botobject.modesRaw:
                        for chk in key:
                            if chk == item:
                            # print(chk,indexer)
                                del self.botobject.modesRaw[indexer]
                                #print(self.botobject.modesRaw[indexer])
                        indexer += 1
                self.botobject.DataDump()
                self.whereIM(self.botobject.activearea)
        
            if type == "modeobjs":
            #  print('remove objects of modes')
                print(mode)

            if type == "total":
                print('total remove ')

            if type == "addtomode":
            #   print('addtomode',mode)
                for key in self.botobject.objs:
                    for objname in key:
                        try:
                            #print(objname)
                            dict = {'name':objname}
                            test=window.evaluate_js(''' document.getElementById("{name}chk").checked '''.format(**dict))
                            if test == True:
                            
                                    checkedlist.append(objname)
                                
                        except:
                            print("Fail",objname)
            
                checkedlist.sort()
                checkedlist2=[]
                for key in checkedlist:

                    if len(checkedlist2) == 0:
                        checkedlist2.append(key)
                    else:
                        checkedlist2.append("|"+key)
                        #checkedlist.append(objname)
                
                indexer = 0
                new=""
                for key in self.botobject.modesRaw:
                    for p in key:
                        if p == mode:
                            old= self.botobject.modesRaw[indexer][p][0]['objects']
                            for stuff in checkedlist2:
                                new= new+stuff
                                # print(stuff)
                            if old == "":
                                new=old+new
                            else:
                                new=old+"|"+new
                            #print(new)
                            self.botobject.modesRaw[indexer][p][0]['objects']= new
                            #print(self.botobject.modes[indexer][p][0]['objects'])
                            
                            #self.objectscards(self.botobject.activemodename)
                            #Api.objectscards(window,mode)
                            #print(self.botobject.modes[indexer][p][0]['objects'])
                        indexer += 1
                self.botobject.DataDump()
            # self.botobject.DataRefresh()
                self.botobject.GetModes()
                self.botobject.GetObjs()
                self.whereIM(self.botobject.activearea)
            
            if type == "removefrommode":
                #print('removefrommode',mode)
                
                
                for key in self.botobject.modeobjecets:
                    dict = {'name':key}
                    test=window.evaluate_js(''' document.getElementById("{name}modchk").checked '''.format(**dict))
                    if test == True:
                        checkedlist.append(key)
            # print(self.botobject.modeobjecets)
            # print(checkedlist)
                for key in checkedlist:
                    for key2 in self.botobject.modeobjecets:
                        if key == key2:
                            #print("found del",key)
                            self.botobject.modeobjecets.remove(key)
                #print(self.botobject.modeobjecets)
            
                indexer=0
                tmp=""
                for key in self.botobject.modeobjecets:
                    
                    if indexer == 0:
                    
                        tmp=key
                    
                    else:
                        tmp= tmp+"|"+key
                    
                    indexer += 1

                modedata = self.botobject.modesRaw
                
                indexer=0
                for gmode in modedata:
                        for key in gmode:
                            if self.botobject.activemodename==key:
                                self.botobject.modesRaw[indexer][key][0]['objects']=tmp
                            
                            indexer += 1
                self.botobject.DataDump()
                self.objectscards(self.botobject.activemodename)


            
                return
            
            if type == "removefromDB":
                print("DB Remove")
                for key in self.botobject.objlist:
                    print(key)

                    # x=key.split("|")
                    # key=x[0].lower()
                    dict = {'name':key}
                    test=window.evaluate_js(''' document.getElementById("{name}chktotal").checked '''.format(**dict))
                    if test == True:
                        checkedlist.append(key)
                    #   checkedlist2.append(key+"|"+x[1])
                print(checkedlist)
                
                for item in self.botobject.modelist:
                # print(item)
                    self.botobject.ActiveMode(item)
                #   print(item,self.botobject.modeobjecets)
                    for key in checkedlist:
                        #print("chk item",key)
                        for key2 in self.botobject.modeobjecets:
                            #print("match item",key2)
                            if key == key2.lower():
                                self.botobject.modeobjecets.remove(key2)
                            # print("Found Match",key)
                #  print(self.botobject.modeobjecets)
                    indexer=0
                    tmp=""
                    for key in self.botobject.modeobjecets:
                        if indexer == 0:
                    
                            tmp=key
                        
                        else:
                            tmp= tmp+"|"+key
                        indexer+=1
                # print(tmp)
                # print("raw",self.botobject.modesRaw)
                    modedata = self.botobject.modesRaw
                    
                    indexer=0
                    for gmode in modedata:
                            for key in gmode:
                                if self.botobject.activemodename==key:
                                    self.botobject.modesRaw[indexer][key][0]['objects']=tmp
                                
                                indexer += 1
                    
                    
                    #self.botobject.DataDump()
            #  print("done")
                checkedlist.reverse()
            # print("chk2",checkedlist2)
                #print(self.botobject.objlist)
                for item in checkedlist:
                    print(item)
                    self.botobject.ActiveObj(item)
                #     x=item.split("|")
                #     tmp= x[0].lower()
                #     tmp1= int(x[1])
                #  #   print(x[0],x[1])
                # #    print(self.botobject.objs[tmp1])
                    del self.botobject.objs[self.botobject.activeobjectindx]

                self.botobject.DataDump()
                self.whereIM(self.botobject.activearea)

            return
        
            
            t= Thread(target=procobjs, args=(window,))
            t.start()

        #### Utils
        def ifloader(type):
            if type == "on":
                print('on')
                mydiv=''' <span class="loader"><span class="loader-inner"></span></span> '''
                dict = {'name': 'loadstat','change':'innerHTML','element':mydiv}
                testvar = ''' document.getElementById('{name}').{change} = `{element}` '''.format(**dict)
                window.evaluate_js(testvar)
            else:
                print("off")
                dict = {'name': 'loadstat','change':'innerHTML','element':''}
                testvar = ''' document.getElementById('{name}').{change} = `{element}` '''.format(**dict)
                window.evaluate_js(testvar)

        def getdataurl(self,dataurl):
            print("url start")
        
            print(dataurl)

        def getscanarea(self):
            print("set area")
            testvar = ''' document.getElementById('cropx1').value '''
            x=window.evaluate_js(testvar)
            testvar = ''' document.getElementById('cropy1').value '''
            y=window.evaluate_js(testvar)
            testvar = ''' document.getElementById('cropx2').value '''
            x1=window.evaluate_js(testvar)
            testvar = ''' document.getElementById('cropy2').value '''
            y1=window.evaluate_js(testvar)

            self.botobject.Aobjx1=x
            self.botobject.Aobjy1=y
            self.botobject.Aobjx2=x1
            self.botobject.Aobjy2=y1
            self.botobject.saveactiveobjecet()

        def getbase64result(self,base,x,y,x1,y1):
            print(base)
            self.loadtoggle=False
            #self.botobject.activeobject(self.botobject.activeobjectnameRaw)
            #print(self.botobject.activeobjectnameRaw)
            tmp= self.botobject.activeobjectname
            tmp1= self.botobject.activeobjectindx
        # print(tmp,tmp1)
        #  old=self.botobject.objs[tmp1][tmp][0]['colorstring']
        #  print(old)
            
            test=base.replace('data:image/png;base64,', '')
            if self.botobject.objs[tmp1][tmp][0]['colorstring'] != test:
            # print("img change")
                self.loadtoggle=True
            
        
            self.botobject.Aobjx1=x
            self.botobject.Aobjy1=y
            self.botobject.Aobjx2=x1
            self.botobject.Aobjy2=y1

            self.botobject.Aobjcolorstring=test

            self.botobject.saveactiveobjecet()
            if self.loadtoggle == True:
                self.whereIM(self.botobject.activearea)
        
            
        def chkload(self):

            if self.loadtoggle==True:
                print('load chk')
                testvar = ''' document.getElementById('botpickname').textContent '''
                test = window.evaluate_js(testvar)
                if test == "Bot Picked":
                    print('no bot loaded')
                    return False
                    
                else:
                    print('bot loaded')
                    return True
                
        def refreshlist(self):
            Api.ifloader("on")
            print('refresh')
            getwindow(window)
            Api.ifloader("off")
            # t= Thread(target=getwindow, args=(window,))
            # t.start()

        #Top Window Handlers
        def topbar(self,code):
            topbarhandler(code,window) #utilcode/Frameless.py  window is the target object window.

        def bottbar(self,code):
            if code == "website":
                webbrowser.open('http://botplace.me')

            if code == "discord":
                webbrowser.open('https://discord.gg/ggRCXS2')

        def jsmaker(self,mode):
        #  print("jsmaker active",mode)
            try:
                for item in mode:
                    if item == "Set":
                        for key in mode[item]:
                            
                            dict = {'name': key['idname'],'change':key['changename'],'element':key['setvalue']}
                            testvar = ''' document.getElementById('{name}').{change} = `{element}` '''.format(**dict)
                            test = window.evaluate_js(testvar)
                    if item == "Set2":
                        for key in mode[item]:
                        # print(item)
                            dict = {'name': key['idname'],'change':key['changename'],'element':key['setvalue']}
                            testvar = ''' document.getElementById('{name}').{change} = "{element}" '''.format(**dict)
                            test = window.evaluate_js(testvar)
            
                    if item == "Get":
                        for key in mode[item]:
                            dict = {'name': key['idname'],'change':key['changename'],'element':key['setvalue']}
                            testvar = ''' document.getElementById('{name}').{change} '''.format(**dict)
                            test =window.evaluate_js(testvar)
                            return test
            except:
                print('error ',mode)

        def jsonsave(self,name):
        # print('test')
        # print(name,"json save")
            result = win32api.MessageBox(None,"This Action Will Overwrite Saved data and Restore to Web App Data\n\nDo You Allow??", "Critical Warning!",1 | 0x00001000)
            if result == 1:
                
                shutil.copy2("DB/"+name+".json", "DB/Shadow/"+name+".json")
                #game_data=open("DB/Shadow/"+name+".json")
                #gamedata = json.load(game_data)
                self.botobject.DataRefresh()
                self.botobject.GetModes()
                self.botobject.GetObjs()
                print('json copy')
            if result == 2:
                print('No')

        def jsonwriter(self,name,jdata):
            print('writter')
            print('json writer')
            json.dumps(jdata)
            with open('DB/Shadow/'+ name +'.json', mode='w') as f:
                f.write(json.dumps(jdata, indent=2))
        
        # def objaddremove(self,datalist):
        #     print(datalist)
        ### Menu Divs

        def sidesave(self,name,data):
            obtyper=""
        # print(name,data)
            if name=="ObjectSideSave":
                reftrigger=False
            # print(data,self.botobject.activeobjectname)
                if self.botobject.Aobjtype == "Image":

                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['scantype']=window.evaluate_js(''' document.getElementById("objecttype").value ''').lower()
                    if window.evaluate_js(''' document.getElementById("objectcolor").value ''') == "Grayscale":
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['scancolor']="G"
                    else:
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['scancolor']="C"
                    
                    jsrunnerdb={'Get':[{'idname':'objectclick','changename':'value','setvalue':''}]}
                    clickchk=self.jsmaker(jsrunnerdb)

                    #print(clickchk)
                    if clickchk == "Click" or clickchk == '1':
                    #  print("write click")
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['clicks']="1"
                    else:
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['clicks']="0"
                    # self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['clicks']=window.evaluate_js(''' document.getElementById("objectclick").value ''')
                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['tol']=window.evaluate_js(''' document.getElementById("objecttol").value ''')
                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['x1']=window.evaluate_js(''' document.getElementById("objectx1").value ''')
                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['y1']=window.evaluate_js(''' document.getElementById("objecty1").value ''')
                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['x2']=window.evaluate_js(''' document.getElementById("objectx2").value ''')
                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['y2']=window.evaluate_js(''' document.getElementById("objecty2").value ''')
                    
                    if self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['colorstring'] != window.evaluate_js(''' document.getElementById("objectcolorstring").value '''):
                    
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['colorstring']=window.evaluate_js(''' document.getElementById("objectcolorstring").value ''')
                        reftrigger=True
                        
                    if self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['graystring'] != window.evaluate_js(''' document.getElementById("objectgraystring").value '''):
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['graystring']=window.evaluate_js(''' document.getElementById("objectgraystring").value ''')
                        reftrigger=True
                    self.botobject.DataDump()
                    if reftrigger == True:
                        self.whereIM(self.botobject.activearea)
                        #self.objectscards(self.botobject.activemodename)

                if self.botobject.Aobjtype  == "Pixel":
                    if window.evaluate_js(''' document.getElementById("objecttype").value ''') == "Area":
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['scantype']=window.evaluate_js(''' document.getElementById("objecttype").value ''').lower()
                    else:
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['scantype']="Single"
                    jsrunnerdb={'Get':[{'idname':'objectclick','changename':'value','setvalue':''}]}
                    clickchk=self.jsmaker(jsrunnerdb)
                    if clickchk == "Click" or clickchk == '1':
                    #  print("write click")
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['clicks']="1"
                    else:
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['clicks']="0"
                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['tol']=window.evaluate_js(''' document.getElementById("objecttol").value ''')
                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['x1']=window.evaluate_js(''' document.getElementById("objectx1").value ''')
                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['y1']=window.evaluate_js(''' document.getElementById("objecty1").value ''')
                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['x2']=window.evaluate_js(''' document.getElementById("objectx2").value ''')
                    self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['y2']=window.evaluate_js(''' document.getElementById("objecty2").value ''')
                    
                    if self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['pixelcolor'] != window.evaluate_js(''' document.getElementById("objectcolorstring").value '''):
                        self.botobject.objs[self.botobject.activeobjectindx][self.botobject.activeobjectname][0]['pixelcolor']=window.evaluate_js(''' document.getElementById("objectcolorstring").value ''')
                        reftrigger=True
                    
                    self.botobject.DataDump()
                    if reftrigger == True:
                        self.whereIM(self.botobject.activearea)
        
            if name=="ModeSettingSave":
                self.botobject.activefree= window.evaluate_js(''' document.getElementById("addfree").checked ''')
                self.botobject.activesilver= window.evaluate_js(''' document.getElementById("addsilver").checked ''')
                self.botobject.activegold= window.evaluate_js(''' document.getElementById("addgold").checked ''')
                self.botobject.modesRaw[self.botobject.activemodeindx][self.botobject.activemodename][0]['free']=self.botobject.activefree
                self.botobject.modesRaw[self.botobject.activemodeindx][self.botobject.activemodename][0]['silver']=self.botobject.activesilver
                self.botobject.modesRaw[self.botobject.activemodeindx][self.botobject.activemodename][0]['gold']=self.botobject.activegold
                self.botobject.DataDump()

            if name=="BotSettings":
                print('BotSettings save')
                self.botobject.system = window.evaluate_js(''' document.getElementById("botsubsys").value''')
                self.botobject.version = window.evaluate_js(''' document.getElementById("botsubver").value''')
                self.botobject.imgversion = window.evaluate_js(''' document.getElementById("botsubimgver").value''')
                self.botobject.wid = window.evaluate_js(''' document.getElementById("botsubwid").value''')
                self.botobject.heig = window.evaluate_js(''' document.getElementById("botsubhei").value''')
                self.botobject.thumb = window.evaluate_js(''' document.getElementById("botsubthum").value''')
                # self.botobject.public = window.evaluate_js(''' document.getElementById("publicchk").checked ''')
                print('BotSettings done')
                self.botobject.DataDump()
                print('BotSettings done1')
            
            if name=="AddMode":
                modedata = self.botobject.modesRaw
                modename=window.evaluate_js(''' document.getElementById("addmodename").value ''')
                modename=modename.replace(" ", "")
                modename=modename.lower()
                modefree=True
                modesilver=False
                # old modegold=window.evaluate_js(''' document.getElementById("addgold2").checked ''')

                modegold=False

                try:
                    self.botobject.ActiveMode(modename)
                except:
                # print('building mode')
                    modedata.append(
                    {modename:
                        [
                        {'free': modefree,'silver':modesilver ,'gold':modegold ,'objects':''}
                        ]
                    }
                
                    )
                self.botobject.DataDump()
                self.modecards()
            
            if name=="addBot":
                botname=window.evaluate_js(''' document.getElementById("addbotname").value ''').replace(" ", "").lower()
                botsystem=window.evaluate_js(''' document.getElementById("addbotsystem").value ''').replace(" ", "").lower()
                ver=window.evaluate_js(''' document.getElementById("addbotver").value ''').replace(" ", "").lower()
                imgver=window.evaluate_js(''' document.getElementById("addbotimgver").value ''').replace(" ", "").lower()
                botw=window.evaluate_js(''' document.getElementById("addbotw").value ''').replace(" ", "").lower()
                both=window.evaluate_js(''' document.getElementById("addboth").value ''').replace(" ", "").lower()
                botimg=window.evaluate_js(''' document.getElementById("addbotimg").value ''').replace(" ", "").lower()
                if botname == '' or botname == None:
                    return
                print(botname,botsystem,ver,imgver,botw,both,botimg)

                data = {
                    "Settings": [{
                        "botname":botname,
                        "botver": ver,
                        "botimgver": imgver,
                        "targetwidth": botw,
                        "targetheight": both,
                        "thumburl": botimg,
                        "system": botsystem,
                        "botgui": "<div id=\"botguidiv\" value=\"\">\r\n                                      <div class=\"row mt-2 \">\r\n                                        <div class=\" col-3 col-sm-3\">\r\n                                            <row>\r\n                                          <div ><img  id=\"gameimg2\" src=\"\" height=\"80\" width=\"80\" class=\"avatar avatar-xl mr-1 \" /></div>\r\n                                            </row>                             \r\n                                        </div>\r\n                                      <div class=\" mr-2 col-sm my-1 col-12\">\r\n                                          <row>\r\n                                                <div class=\"input-group\"  >\r\n                                                    <input\r\n                                                      type=\"text\"\r\n                                                      class=\"form-control\"\r\n                                              id=\"targetname\"\r\n                                              name=\"targetname\"\r\n                                              value=\"\"\t \r\n                                                      placeholder=\"Click Grab and left Click Target\"\r\n                                                      aria-describedby=\"button-addon2\"\r\n                                              required\r\n                                                    />\r\n                                                    <div class=\"input-group-append\" id=\"button-addon2\">\r\n                                                      <button class=\"btn btn-outline-success\" onclick=\"ahk.grabtarget(event)\"  type=\"button\">Grab</button>\r\n                                                    </div>\r\n                                                  </div>\r\n                                            </row>\r\n                                        </div>\r\n                                            </row>  \r\n                                          \r\n                                    </div>\t\t\r\n                                    <div class=\"row \">\r\n                                        <div class=\"col mt-2\">\r\n                                        <h5>Bot State: </h5>\r\n                                        <div class=\"badge badge-glow badge-danger botstate\" name=\"botstate\" id=\"botstate\">Stopped</div>  \r\n                                    \r\n                                        </div>\r\n                                    \r\n                                      \r\n                                      \r\n                                        <div class=\"col mr-2 col-sm-7\">\r\n                                           <button type=\"button\" class=\"btn btn-outline-success \" role=\"button\" aria-pressed=\"true\"  id=\"optionsplay1\" onclick=\"ahk.botplay()\"><img name=\"startbtn\" src=\"play.svg\" height=\"30\" width=\"30\" /> </button>\r\n                                                    <button type=\"button\" class=\"btn btn-outline-success \" role=\"button\" aria-pressed=\"true\"  id=\"optionsplay2\" onclick=\"ahk.botpause()\"><img name=\"waitbtn\"  src=\"pause.svg\" height=\"30\" width=\"30\" /></button>\r\n                                                    <button type=\"button\" class=\"btn btn-outline-success \" role=\"button\"  aria-pressed=\"true\" id=\"optionsplay3\" onclick=\"ahk.botstop()\"><img name=\"stopbtn\" src=\"stop.svg\" height=\"30\" width=\"30\" /></button>\r\n                                          </div>\r\n                                    </div>\r\n                                    <div class=\"row my-1\">\r\n                                        <div class=\"col\">\r\n                                          <div class=\"form-group\">\r\n                                                <label for=\"mainselect\"> <h5>Select Mode</h5> </label>\r\n                                                <select class=\"custom-select\" id=\"mainselect\">\r\n                                                  \r\n                                                </select>\r\n                                              </div>\r\n                                        </div>\r\n                                        \r\n                                        <div class=\"col\">\r\n                                          <div class=\"form-group\" disabled>\r\n                                                <label for=\"mainselect2\"><h5>More Options</h5></label>\r\n                                                <select class=\"custom-select\" id=\"mainselect2\">\r\n                                                  \r\n                                                </select>\r\n                                              </div>\r\n                                        </div>\r\n                                      </div>\r\n                                  \r\n                                    <div class=\"row my-1\">\r\n                                        <div class=\"col mt-2\">\r\n                                        <h5>More Options: </h5>\r\n                                        </div>\r\n                                  \r\n                                        <div class=\"col mr-2 col-sm-7\">\r\n                                          \r\n                                          </div>\r\n                                      </div>\r\n                                     \r\n                                    <h4 id=\"welcomebox\" class=\"text-center my-1\" > Status Bar</h4> \r\n                                    <h5 id=\"statustext\" class=\"text-center\">Image Scanner Info</h5> \r\n                                    <div class=\"progress progress-bar-success\" style=\"height: 30px\">\r\n                                      \r\n                                                  <div\r\n                                                      class=\"progress-bar progress-bar-striped progress-bar-animated\"\r\n                                                      role=\"progressbar\"\r\n                                                      aria-valuenow=\"50\"\r\n                                                      aria-valuemin=\"0\"\r\n                                                      aria-valuemax=\"100\"\r\n                                                      id=\"botststusbar\"\r\n                                  \r\n                                                      style=\"width: 0%\"\r\n                                                    >\r\n                                                    \r\n                                                  </div>\r\n                                        \r\n                                  </div>\r\n                                  <!-- gui block-->\r\n                                  \r\n                                    </div >",
                        "dev": "LocalUser",
                        "public":1,
                        "Code": "autohotkey"
                    }],
                    "modes": [

                    ],
                    "Objects": [

                    ]
                }
                # dict_1 = json.dumps(data) # converting dictionary to JSON
                with open('DB/'+ botname +'.json', mode='w') as f:
                    f.write(json.dumps(data, indent=2))

                UImain.senddata('Set','modalsbody','data saved ok')

                UImain.senddata('Set','modalsfoot','')
                self.botcards()
                # print(dict_1)
               

            if name=="DbObjAdd":
                obtyper = data.split('|')
                type=obtyper[0]
                objtype=obtyper[1]
                #print('objtype',obtyper[0],"type",obtyper[1])
                self.botobject.DataRefresh()
                self.botobject.GetModes()
                self.botobject.GetObjs()
                if type == "Single":
                    print("Single")
                    if objtype == "Image":
                        # print('img')
                        add1=window.evaluate_js(''' document.getElementById("simgname").value ''')
                        add1=add1.replace(" ", "")
                        add1=add1.lower()
                        add2=window.evaluate_js(''' document.getElementById("simgtype").value ''')
                        add3=window.evaluate_js(''' document.getElementById("simgcolor").value ''')
                        add4=window.evaluate_js(''' document.getElementById("simgclick").value ''')
                        add5=window.evaluate_js(''' document.getElementById("simgtol").value ''')
                        # print(add4)
                        try:
                        
                            self.botobject.ActiveObj(add1)
                        #  print('found')
                            
                        
                        except:
                            print('object no exist')
                            if add4=="Click":
                                add4="1"
                            else: 
                                add4="0"
                            self.botobject.objs.append(
                            {add1.lower():
                                [
                                {'type': objtype,'tol':add5 ,'scantype':add2 ,'scancolor':add3,'clicks':add4,'x1':'','y1':'','x2':'','y2':'','colorstring':'','graystring':''}
                                ]
                            }
                        
                            )
                        
                    if objtype == "Pixel":
                        add1=window.evaluate_js(''' document.getElementById("spixname").value ''')
                        add1=add1.replace(" ", "")
                        add1=add1.lower()
                        add2=window.evaluate_js(''' document.getElementById("spixtype").value ''')
                        #add3=window.evaluate_js(''' document.getElementById("spixcolor").value ''')
                        add4=window.evaluate_js(''' document.getElementById("spixclick").value ''')
                        add5=window.evaluate_js(''' document.getElementById("spixtol").value ''')
                        
                        try:
                        
                            self.botobject.ActiveObj(add1)
                        #  print('found')
                            
                        
                        except:
                            if add4=="Click":
                                add4="1"
                            else: 
                                add4="0"
                            self.botobject.objs.append(
                            {add1:
                                [
                                {'type': objtype,'tol':add5 ,'scantype':add2 ,'clicks':add4,'pixelcolor':'','x1':'','y1':'','x2':'','y2':''}
                                ]
                            }
                        
                            )
                            
                    if objtype == "Func":
                        print('func')
                        add1=window.evaluate_js(''' document.getElementById("funcname").value ''')
                        add1=add1.replace(" ", "")
                        add1=add1.lower()
                        try:
                        
                            self.botobject.ActiveObj(add1)
                        #  print('found')
                            
                        
                        except:
                            dict = {'name':add1}
                            
                            demofunc='''{name}(neutron)<pb><pn><pb><ps><ps><ps><ps>msgbox,Test<ps>Function<ps>Call<ps>{name}<pb><pe>'''.format(**dict)
                            # print(demofunc)
                            # demofunc=demofunc.replace("@-", "{")
                            # demofunc=demofunc.replace("-@", "}")       
                            self.botobject.objs.append(
                            {add1:
                                [
                                {'type': objtype,'objects':'','code':demofunc}
                                ]
                            }
                        
                            )
                    if objtype == "UIFunc":
                        print('UIfunc')
                        add1=window.evaluate_js(''' document.getElementById("funcname").value ''')
                        add1=add1.replace(" ", "")
                        add1=add1.lower()
                        try:
                        
                            self.botobject.ActiveObj(add1)
                        #  print('found')
                            
                        
                        except:
                            dict = {'name':add1}
                            
                            demofunc='''{name}(neutron)<pb><pn><pb><ps><ps><ps><ps>msgbox,Test<ps>Function<ps>Call<ps>{name}<pb><pe>'''.format(**dict)
                            # print(demofunc)
                            # demofunc=demofunc.replace("@-", "{")
                            # demofunc=demofunc.replace("-@", "}")       
                            self.botobject.objs.append(
                            {add1:
                                [
                                {'type': objtype,'code':demofunc}
                                ]
                            }
                        
                            )
                        
                if type == "Multi":
                    # print("multi")
                    if objtype == "Image":
                        # print('img multi')
                        add1=window.evaluate_js(''' document.getElementById("mimgname").value ''')
                        add1=add1.replace(" ", "")
                        add1=add1.lower()
                        add2=window.evaluate_js(''' document.getElementById("mimgtype").value ''')
                        add3=window.evaluate_js(''' document.getElementById("mimgcolor").value ''')
                        add4=window.evaluate_js(''' document.getElementById("mimgclick").value ''')
                        add5=window.evaluate_js(''' document.getElementById("mimgtol").value ''')
                        add6=window.evaluate_js(''' document.getElementById("mimgrange1").value ''')
                        add7=window.evaluate_js(''' document.getElementById("mimgrange2").value ''')
                        # print(add6,add7)
                        
                        testx=int(add6)
                        testx2=int(add7)+1
                        if testx2 >10:
                            testx2=10
                    
                        while testx<testx2:
                            #print(add1+str(testx))
                            objadd = add1+str(testx)
                            try:
                                self.botobject.ActiveObj(objadd)
                            except:
                            #  print('not found',objadd)
                                
                                if add4=="Click":
                                    add4tmp="1"
                                else: 
                                    add4tmp="0"
                                self.botobject.objs.append(
                                {objadd:
                                    [
                                    {'type': objtype,'tol':add5 ,'scantype':add2 ,'scancolor':add3,'clicks':add4tmp,'x1':'','y1':'','x2':'','y2':'','colorstring':'','graystring':''}
                                    ]
                                }
                        
                            )
                            testx += 1
                                

                        

                            
                        
                        
                        
                        # print(self.botobject.activearea)
                        
                        
                        #self.botobject.GetModes()
                            
                    if objtype == "Pixel":
                        print('pix multi')
                        add1=window.evaluate_js(''' document.getElementById("mpixname").value ''')
                        add1=add1.replace(" ", "")
                        add1=add1.lower()
                        add2=window.evaluate_js(''' document.getElementById("mpixtype").value ''')
                        # add3=window.evaluate_js(''' document.getElementById("mpixcolor").value ''')
                        add4=window.evaluate_js(''' document.getElementById("mpixclick").value ''')
                        add5=window.evaluate_js(''' document.getElementById("mpixtol").value ''')
                        add6=window.evaluate_js(''' document.getElementById("mpixrange1").value ''')
                        add7=window.evaluate_js(''' document.getElementById("mpixrange2").value ''')
                        testx=int(add6)
                        testx2=int(add7)+1
                        if testx2 >10:
                            testx2=10
                        while testx<testx2:
                            objadd = add1+str(testx)
                            try:
                                self.botobject.ActiveObj(objadd)
                            except:
                                if add4=="Click":
                                    add4tmp="1"
                                else: 
                                    add4tmp="0"
                                self.botobject.objs.append(
                                {objadd:
                                    [
                                    {'type': objtype,'tol':add5 ,'scantype':add2 ,'clicks':add4tmp,'pixelcolor':'','x1':'','y1':'','x2':'','y2':''}
                                    #{'type': objtype,'tol':add5 ,'scantype':add2 ,'scancolor':add3,'clicks':add4,'x1':'','y1':'','x2':'','y2':'','colorstring':'','graystring':''}
                                    ]
                                }
                            
                                )
                            testx += 1

                            
                
                self.botobject.DataDump()
                self.whereIM(self.botobject.activearea)
                
        def whereIM(self,where):
            print(where)
            self.botobject.DataRefresh()
            if where=="Bots":
                self.botcards()
            if where=="Modes":
                self.modecards()
            if where=="Modesobj":
                print(self.botobject.activemodename)
                self.objectscards(self.botobject.activemodename)
            if where=="Total":
                self.totalcards()
            if where=="Functions":
                self.functioncards()

        def codeptint(self,code):
            
            print('start codeprint')
            if self.botobject.Aobjtype == "Func":
            
                strcheck1=code.count('{')
                strcheck2=code.count('}')
                if strcheck1 < strcheck2:
                    ctypes.windll.user32.MessageBoxW(0, "You are missing { on the Code", "Code Error!",  0x1000)
                    return
                    print("error missing {")
                if strcheck1 > strcheck2:
                    ctypes.windll.user32.MessageBoxW(0, "You are missing } on the Code", "Code Error!", 0x1000)
                    return

                code=code.replace("\n","<pb>").replace(" ","<ps>").replace("{","<pn>").replace("}","<pe>").replace('"',"<pc>")
                self.botobject.activecode=code
                objpasscode=code
                #print('objpasscode',objpasscode)
                # while code.partition("BotItScanner(<pc>")[2] in code:
                #     test=code.partition("BotItScanner(<pc>")[2]
                #     print("one",test)
                #     test2=test.split("<pc>")[0]
                #     print(test2)
                test=code
                self.Aobjfunc=''
                try:
                    ConnectedFuncObjs=[]
                    while True:
                        if test.partition("BotItScanner(<pc>")[2]:
                            #print(test)
                            test=test.partition("BotItScanner(<pc>")[2]
                            testtmp=test
                            test2=testtmp.split("<pc>")[0]
                            try:
                                ConnectedFuncObjs.index(test2)
                            except:
                                ConnectedFuncObjs.append(test2)
                        else:
                            break
                    test=code
                    while True:
                        if test.partition("BotItPixel(<pc>")[2]:
                            #print(test)
                            test=test.partition("BotItPixel(<pc>")[2]
                            testtmp=test
                            test2=testtmp.split("<pc>")[0]
                            try:
                                ConnectedFuncObjs.index(test2)
                            except:
                                ConnectedFuncObjs.append(test2)
                        
                        
                        else:
                            #print(ConnectedFuncObjs)
                            
                            break

                    test=code
                    activefunclist=[]
                    while True:
                        print('starter')
                        if test.partition("neutron)")[0]:
                            testbefore=test.partition("neutron)")[0]
                            #print('Raw Before',testbefore)
                            test=test.partition("neutron)")[2]
                        # print('Next',test)
                        # testtmp=testbefore.partition("neutron)")[0]
                            #print('Before Split',testbefore)
                            test2=testbefore.split("(")[0]
                            t2tmp=test2
                        # print('after {',test2)
                            #print('1st',test2)
                            try:
                                test2=test2.split(":=")[1]
                                try:
                                    activefunclist.index(test2)
                                except:
                                    if test2 != "BotItScanner" and test2 != "BotItPixel":
                                        activefunclist.append(test2)
                                #activefunclist.append(test2)
                                #print('2ndsplit',test2)
                                continue
                            except:print('error')
                            test2=t2tmp
                        #  print('2st',test2)
                            try:
                            # print('Before Raw',test2)
                                test2=test2.split("Raw")[1]
                                #print('now test',test2)
                                testcut=test2.replace('<ps>','')
                                testcut=testcut.replace('<pb>','')
                            # print('test cut',testcut)
                                try:
                                    activefunclist.index(testcut)
                                except:
                                    activefunclist.append(testcut)
                            # print('2ndsplit',test2)
                                continue
                            except:print('error2')
                            # test2=t2tmp
                            # print('3st',test2)
                            # try:
                            #     test2=test2.split("<pb>")[1]
                            #     print('2ndsplit',test2)
                            #     continue
                            # except:print('error')
                                # test3=test2.split("<ps>")[2] or test2.split("<pb>")[2] 
                                # print('test3',test3)
                        
                            #print(test2)
                    
                        else:
                            break
                
                    
                    print()
                    print(activefunclist)
                    for item in activefunclist:
                        self.botobject.ActiveObj(item)
                        #print(self.botobject.funcobjecets)
                        for key in self.botobject.funcobjecets:
                            print(key)
                            try:
                                ConnectedFuncObjs.index(key)
                            except:
                                ConnectedFuncObjs.append(key)
                    indexer=0

                    self.botobject.ActiveObj(self.tmpactivefunc)
                    for item in ConnectedFuncObjs:
                            if indexer == 0:
                            
                                    tmp=item
                                
                            else:
                                tmp= tmp+"|"+item
                            indexer+=1
                    self.botobject.Aobjfunc=tmp
                except:
                    print('error in paser')
                #print(tmp)
                #print(tmp)
                #print(code)
                
                self.botobject.activecode=objpasscode
                #print('after objects',self.botobject.activecode)
                self.botobject.saveactiveobjecet()
                #print(self.botobject.activecode)
            
            
            if self.botobject.Aobjtype == "UIFunc":
                print("UI")
                
                strcheck1=code.count('{')
                strcheck2=code.count('}')
                if strcheck1 < strcheck2:
                    ctypes.windll.user32.MessageBoxW(0, "You are missing { on the Code", "Code Error!",  0x1000)
                    return
                    print("error missing {")
                if strcheck1 > strcheck2:
                    ctypes.windll.user32.MessageBoxW(0, "You are missing } on the Code", "Code Error!", 0x1000)
                    return

                code=code.replace("\n","<pb>").replace(" ","<ps>").replace("{","<pn>").replace("}","<pe>").replace('"',"<pc>")
                self.botobject.activecode=code
                objpasscode=code
                #print('objpasscode',objpasscode)
                # while code.partition("BotItScanner(<pc>")[2] in code:
                #     test=code.partition("BotItScanner(<pc>")[2]
                #     print("one",test)
                #     test2=test.split("<pc>")[0]
                #     print(test2)
            ##  test=code
                # 
                #print(tmp)
                #print(tmp)
                #print(code)
                
                self.botobject.activecode=objpasscode
                #print('after objects',self.botobject.activecode)
                self.botobject.saveactiveobjecet()
                #print(self.botobject.activecode)

        def editorchange(self):
        # print(self.tmpactivefunc)
            self.botobject.ActiveObj(self.tmpactivefunc)
            print('changed')
            window.evaluate_js(""" 
                        var editor = ace.edit("editor");
                        var code = editor.getSession().getValue();
                        pywebview.api.codeptint(code)
                            """)
            # window.evaluate_js(""" 
            #             var editor = ace.edit("editor");
            #             var code = editor.getSession().getValue().replace(/\s/g, '');
            #             alert(code);
            #             pywebview.api.codeptint(code)
            #                 """)

            print('done')

        ###Test Zone
        def BuildAhk(self):
            Api.ifloader("on")
            print("build start")
            # try:

            #     name= 'Botit DIY Local '+self.botobject.name
            #     whnd = win32gui.FindWindowEx(None, None, None, name)
            #     if not (whnd == 0):
            #         print('FOUND!')

            #     # handle = win32gui.FindWindow(None, name)
            #     # print(handle)
            # except:
            #     print('no app running yet')

            imgconnect=[]
            UIconnect=[]
            import subprocess
            #ahkname=self.botobject.name
            file='BotitCloud/bots/'+self.botobject.name+'/Data.bin'
            try:
                os.mkdir('BotitCloud/bots/'+self.botobject.name+'/')
            except:
                pass
            try:
                os.mkdir('BotitCloud/bots/'+self.botobject.name+'/Images/')
            except:
                pass

            # print(self.botobject.gui)
            with open(file, 'w') as filetowrite:
                filetowrite.write(self.botobject.gui)

            try:
                config = configparser.ConfigParser()
                path = 'BotitCloud/bots/'+self.botobject.name+'/Init.ini'
                config.read(path)
                config.sections()
                # for mode in config:
                #     print(mode)
                config['login']['gamename']=self.botobject.name

                #print(config['login']['gamename'])

                with open(path, 'w') as configfile:
                    config.write(configfile)
            except:
                dict = {'name':self.botobject.name}
                path = 'BotitCloud/bots/'+self.botobject.name+'/Init.ini'
                with open(path, 'w') as filetowrite:
                        filetowrite.write('''[login]
                        gamename={name}
                        memberberries='''.format(**dict))

            config = configparser.ConfigParser()
            
            config.read(path)
            config.sections()
            # for mode in config:
            #     print(mode)
            config['login']['gamename']=self.botobject.name

            #print(config['login']['gamename'])

            with open(path, 'w') as configfile:
                config.write(configfile)
            
            config = configparser.ConfigParser()
            path = 'BotitCloud/bots/'+self.botobject.name+'/Newbot.ini'
            config.read(path)

            
            try:
                config.remove_section('Botit Settings')
            except:
                pass
            config.add_section('Botit Settings')
            
            config['Botit Settings']['BotVersion']=self.botobject.version
            config['Botit Settings']['BotImgVersion']=self.botobject.imgversion
            config['Botit Settings']['Tokengrp']='Free'
            # config['Botit Settings']['MemberBerries']=''
            config['Botit Settings']['SleepAmountA']='150'
            config['Botit Settings']['SleepAmountB']='250'
            config['Botit Settings']['SleepAmountC']='1850'
            config['Botit Settings']['SleepAmountD']='2750'
            config['Botit Settings']['biobreaker']='1'

            funccoder=[]
            funcindx=0
        
            # if mode == "Botit Modes":
            try:
                config.remove_section('Botit Modes')
            except:
                pass
            
            config.add_section('Botit Modes')
            for item in self.botobject.modelist:
                    self.botobject.ActiveMode(item)
                    config['Botit Modes'][item]=self.botobject.modesRaw[self.botobject.activemodeindx][item][0]['objects']
                    #print(self.botobject.modeobjecets)
                    for stuff in self.botobject.modeobjecets:
                        print("Stuff lister", stuff)
                        
                        self.botobject.ActiveObj(stuff)
                        if self.botobject.Aobjtype == "Func":
                            try:
                                imgconnect.index(stuff)
                            except:
                                imgconnect.append(stuff)
                                for funcimg in self.botobject.funcobjecets:
                                    try:
                                        imgconnect.index(funcimg)
                                        pass
                                    except:
                                        imgconnect.append(funcimg)
                                        pass
                        else:
                            try:
                                imgconnect.index(stuff)
                            except:
                                imgconnect.append(stuff)
            
            try:
                config.remove_section('Botit Calls')
            except:
                pass
            try:
                config.remove_section('Botit XY')
            except:
                pass
            try:
                config.remove_section('Botit Pass')
            except:
                pass
            
            config.add_section('Botit Calls')
            
            config.add_section('Botit XY')

            config.add_section('Botit Pass')
        # print(self.botobject.objlist)
            for key in self.botobject.objlist:
                self.botobject.ActiveObj(key)
                if self.botobject.Aobjtype == "Image":
                    #print(self.botobject.Aobjcolor)
                    if self.botobject.Aobjcolor == "Color" or  self.botobject.Aobjcolor == "C":
                        setclr= "C"
                    else:
                        setclr="G"
                    config['Botit XY'][self.botobject.activeobjectname]=self.botobject.Aobjx1+'|'+self.botobject.Aobjy1+'|'+self.botobject.Aobjx2+'|'+self.botobject.Aobjy2
                    config['Botit Calls'][self.botobject.activeobjectname]=self.botobject.Aobjtype+'|'+self.botobject.Aobjtol+'|'+self.botobject.Aobjscan+'|'+setclr+'|'+self.botobject.Aobjclicks
                    #config['Botit Calls'][self.botobject.activeobjectname]=self.botobject.Aobjtype+'|'+self.botobject.Aobjtol+'|'+"Single"+'|'+setclr+'|'+"1"
                if self.botobject.Aobjtype == "Pixel":
                    config['Botit XY'][self.botobject.activeobjectname]=self.botobject.Aobjx1+'|'+self.botobject.Aobjy1+'|'+self.botobject.Aobjx2+'|'+self.botobject.Aobjy2
                    config['Botit Calls'][key]=self.botobject.Aobjtype+'|'+self.botobject.Aobjtol+'|'+self.botobject.Aobjscan+'|'+self.botobject.Aobjclicks+'|'+self.botobject.pixelcolor
                if self.botobject.Aobjtype == "Func":
                    config['Botit Calls'][key]=self.botobject.Aobjtype+'|'+self.botobject.Aobjfunc
                    try:
                        imgconnect.index(key)
                    except:
                        imgconnect.append(key)
                    
                
                if self.botobject.Aobjtype == "UIFunc":
                # config['Botit Calls'][key]=self.botobject.Aobjtype
                    UIconnect.append(key)
                

            with open(path, 'w') as configfile:
                config.write(configfile)
            print(imgconnect)
            for item in imgconnect:
                if item == '':
                    continue

                self.botobject.ActiveObj(item)
                if self.botobject.Aobjtype == "Image":
                    print('img')
                    #print(self.botobject.Aobjcolorstring)
                    try:
                        path2= "BotitCloud/bots/"+self.botobject.name+"/Images/"+self.botobject.activeobjectname+"C.png"
                        image = base64.b64decode(str(self.botobject.Aobjcolorstring))       
                    # fileName = 'test.png'

                    #  imagePath = ('D:\\base64toImage\\'+"test.jpeg")
                        img = Image.open(io.BytesIO(image))
                        img.save(path2, 'png')
                    
                    except:
                        pass
                    
                    config['Botit Pass'][self.botobject.activeobjectname]=''
                # config['Botit Settings']['MemberBerries']=''
                
                    # from base64 import decodebytes
                    # with open(path,"wb") as f:
                    #     f.write(decodebytes(self.botobject.Aobjcolorstring))
                if self.botobject.Aobjtype == "Func":
                    print("func found to write",item)
                    if funcindx == 0:
                        funcindx+=1
                        file='BotitCloud/lib/Functions.ahk' 
                        with open(file, 'w') as filetowrite:
                            funccode=self.botobject.activecode.replace("<pb>","\n").replace("<ps>"," ").replace("<pn>","{").replace("<pe>","}").replace("<pc>",'"')
                            filetowrite.write(funccode+'\n')

                    else:
                        print("else func")
                        file='BotitCloud/lib/Functions.ahk' 
                        with open(file, 'a') as filetowrite:
                            funccode=self.botobject.activecode.replace("<pb>","\n").replace("<ps>"," ").replace("<pn>","{").replace("<pe>","}").replace("<pc>",'"')
                            filetowrite.write(funccode+'\n')
            

            for item in UIconnect:
                if item == '':
                    continue

                self.botobject.ActiveObj(item)
                
                if self.botobject.Aobjtype == "UIFunc":
                    print("UIfunc found to write",item)
                    if funcindx == 0:
                        funcindx+=1
                        file='BotitCloud/lib/Functions.ahk' 
                        with open(file, 'w') as filetowrite:
                            funccode=self.botobject.activecode.replace("<pb>","\n").replace("<ps>"," ").replace("<pn>","{").replace("<pe>","}").replace("<pc>",'"')
                            filetowrite.write(funccode+'\n')

                    else:
                        print("else func")
                        file='BotitCloud/lib/Functions.ahk' 
                        with open(file, 'a') as filetowrite:
                            funccode=self.botobject.activecode.replace("<pb>","\n").replace("<ps>"," ").replace("<pn>","{").replace("<pe>","}").replace("<pc>",'"')
                            filetowrite.write(funccode+'\n')
            
            if funcindx == 0:
                file='BotitCloud/lib/Functions.ahk' 
                with open(file, 'w') as filetowrite:
                    filetowrite.write('')

            print("done building")
            with open(path, 'w') as configfile:
                config.write(configfile)
            Api.ifloader("off")
            subprocess.run(["BotitCloud/AutoHotkeyA32.exe", "BotitCloud/Runner.ahk",self.botobject.name,self.botobject.system,'Free','Free',self.botobject.imgversion,self.botobject.version,self.botobject.wid,self.botobject.heig,self.botobject.thumb])
       



    if filename == 'Botit DIY' or __name__ == "__main__":
        api = Api()
        window = webview.create_window('BotPlace Developer Tool',
                                StartWin,
                                width=20, height=20,
                                resizable=True,on_top=True,
                                frameless=True,js_api=api)
        window.shown += on_shown
        webview.start(debug=False,http_server=True)
except:
    import traceback
    f = open('Crash.log', 'w')
    e = traceback.format_exc()
    f.write(str(e))
    f.close()
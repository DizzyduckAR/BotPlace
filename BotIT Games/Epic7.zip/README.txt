This is an Alfa Version. 
Some scans may not work as intended, and support for some features will come in the future


Calibrated for Bluestacks 4.220.0.1109
Tablet Mode, 1600x900 res, 240 dpi
Performance, OpenGL, NVidia GPU, Disabled ASTC


Epic 7 in english


Setting up:
When setting for the 1st time, start a quest with a non friend support,
when the popup to add the friend appears, open BotitFriend in image installer, 
and press AutoScreen.
Bluestacks will resize, and all images should match.


You can help improving this bot by 
reporting issues and providing insight
https://discord.gg/pc7r5YG


Enjoy
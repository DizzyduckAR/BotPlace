
function modalcall() {
    console.log('test')
    $('#addstuff').modal('toggle');
   
    
  }



function ddlupdate() {
    var element = document.getElementById('selectMultiple');

    // Set Values
    var values = ["Gold", "Bronze"];
    for (var i = 0; i < element.options.length; i++) {
        element.options[i].selected = values.indexOf(element.options[i].value) >= 0;
    }
    
    // Get Value
    var selectedItens = Array.from(element.selectedOptions)
            .map(option => option.value)
    
  }

function myFunction(test) {
    document.getElementById('demo').innerHTML= (`

             check
        
         `);
  }
  
function modepick() {
    document.getElementById('mainapp').innerHTML= (`

    <div class='text-center'>
    <h4 class='mb-2' style="font-weight: bold"> mode Picked</h4> 
   
    <img alt="Bot Place" class="w-6 block w-12 h-12 text-theme-1 dark:text-theme-10 mx-auto" img  src="dist/images/icon.png" height="80" width="80">
    </div>

    <div class="flex flex-wrap px-4">
    <div class="w-24 h-24 relative image-fit mb-5 mr-5 cursor-pointer zoom-in">
        <img class="rounded-md" alt="Midone Tailwind HTML Admin Template" src="dist/images/preview-7.jpg">
        <div title="Remove this image?" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white bg-theme-6 right-0 top-0 -mr-2 -mt-2"> <i data-feather="x" class="w-4 h-4"></i> </div>
    </div>
    <div class="w-24 h-24 relative image-fit mb-5 mr-5 cursor-pointer zoom-in">
        <img class="rounded-md" alt="Midone Tailwind HTML Admin Template" src="dist/images/preview-2.jpg">
        <div title="Remove this image?" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white bg-theme-6 right-0 top-0 -mr-2 -mt-2"> <i data-feather="x" class="w-4 h-4"></i> </div>
    </div>
    <div class="w-24 h-24 relative image-fit mb-5 mr-5 cursor-pointer zoom-in">
        <img class="rounded-md" alt="Midone Tailwind HTML Admin Template" src="dist/images/preview-5.jpg">
        <div title="Remove this image?" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white bg-theme-6 right-0 top-0 -mr-2 -mt-2"> <i data-feather="x" class="w-4 h-4"></i> </div>
    </div>
    <div class="w-24 h-24 relative image-fit mb-5 mr-5 cursor-pointer zoom-in">
        <img class="rounded-md" alt="Midone Tailwind HTML Admin Template" src="dist/images/preview-10.jpg">
        <div title="Remove this image?" class="tooltip w-5 h-5 flex items-center justify-center absolute rounded-full text-white bg-theme-6 right-0 top-0 -mr-2 -mt-2"> <i data-feather="x" class="w-4 h-4"></i> </div>
    </div>
    
</div>
        
         `);

}


function submen(test) {
    if (test == 'editbot')
    {

        document.getElementById('mainapp').innerHTML= (`
        
        
         <div
                <div class=" mb-2 mr-5 cursor-pointer zoom-in">
                <img class="rounded-md" id="bot1"  src="dist/images/preview-7.jpg" height="250" width="250" onclick="pywebview.api.botcards()" >
                <div class="flex">
                    <!-- BEGIN: Header & Footer Slide Over -->
                    <div class="intro-y  mb-1">
                        <div id="header-footer-slide-over" class="p-2">
                            <div class="preview">
                                <!-- BEGIN: Slide Over Toggle -->
                                <div class="text-center"> <a href="javascript:;" data-toggle="modal" data-target="#sidemodal" class="btn btn-primary ml-5">Edit Bot</a> </div>
                                <!-- END: Slide Over Content -->
                            </div>
                        </div>
                    </div>
                    <!-- END: Header & Footer Slide Over -->
                    

                    <!-- BEGIN: Header & Footer Slide Over -->
                    <div class="intro-y  mb-1">
                        <div id="header-footer-slide-over" class="p-2">
                            <div class="preview">
                                <!-- BEGIN: Slide Over Toggle -->
                                <div class="text-center"> <a href="javascript:;" data-toggle="modal" data-target="#sidemodal" class="btn btn-danger">Pick Bot</a> </div>
                            </div>
                        </div>
                    </div>
                    <!-- END: Header & Footer Slide Over -->

                    
                </div>
                        
                    
                
            </div>

            
             
            <div
            <div class=" mb-2 mr-5 cursor-pointer zoom-in">
            <img class="rounded-md"  src="dist/images/preview-7.jpg" height="250" width="250">
            <div class="flex">
                <!-- BEGIN: Header & Footer Slide Over -->
                <div class="intro-y  mb-1">
                    <div id="header-footer-slide-over" class="p-2">
                        <div class="preview">
                            <!-- BEGIN: Slide Over Toggle -->
                            <div class="text-center"> <a href="javascript:;" data-toggle="modal" data-target="#sidemodal" class="btn btn-primary ml-5">Edit Bot</a> </div>
                            <!-- END: Slide Over Toggle -->
                            <!-- BEGIN: Slide Over Content -->
                            
                            <!-- END: Slide Over Content -->
                        </div>
                    </div>
                </div>
                <!-- END: Header & Footer Slide Over -->

                <!-- BEGIN: Header & Footer Slide Over -->
                <div class="intro-y  mb-1">
                    <div id="header-footer-slide-over" class="p-2">
                        <div class="preview">
                            <!-- BEGIN: Slide Over Toggle -->
                            <div class="text-center"> <a href="javascript:;" data-toggle="modal" data-target="#sidemodal" class="btn btn-danger">Pick Bot</a> </div>
                            <!-- END: Slide Over Toggle -->
                            <!-- BEGIN: Slide Over Content -->
                            
                            <!-- END: Slide Over Content -->
                        </div>
                    </div>
                </div>
                <!-- END: Header & Footer Slide Over -->
            </div>
                    
                
            
        </div>
       
        
         `);
         
         
    }


    if (test == 'botmode')
    {
        console.log(test)
         document.getElementById('mainapp').innerHTML= (`
         
       
        <div class="intro-y grid grid-cols-12 gap-3 sm:gap-6 mb-3">
        <!-- BEGIN: Directory & Files -->
                <div class="intro-y col-span-6 sm:col-span-4 md:col-span-3 xxl:col-span-2">
                <div class="file box rounded-md px-5 pt-8 pb-5 px-3 sm:px-5 relative zoom-in">
                    <div class="absolute left-0 top-0 mt-3 ml-3">
                        <input class="form-check-input border border-gray-500" type="checkbox">
                    </div>
                    <a href="" class="w-3/5 file__icon file__icon--image mx-auto">
                        <div class="file__icon--image__preview image-fit">
                            <img src="media/modes/data-collection.svg" height="50" width="50">
                        </div>
                    </a>
                    <a href="" class="block font-medium mt-4 text-center">Mode Name</a> 
                    <div class="text-gray-600 text-xs text-center mt-0.5">1 MB</div>
                    <div class="absolute top-0 right-0 mr-2 mt-2 dropdown ml-auto">
                        <a class="dropdown-toggle w-5 h-5 block" href="javascript:;" aria-expanded="false"> <i data-feather="log-out" class="w-5 h-5 text-gray-600"></i> </a>
                        <div class="dropdown-menu w-40">
                            <div class="dropdown-menu__content box dark:bg-dark-1 p-2">
                                <a href="" class="flex items-center block p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="users" class="w-4 h-4 mr-2"></i> Share File </a>
                                <a href="" class="flex items-center block p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md"> <i data-feather="trash" class="w-4 h-4 mr-2"></i> Delete </a>
                            </div>
                        </div>
                    </div>
                </div>
                 </div>
                 
        
        <!-- END: Directory & Files -->
        </div>
                        
     `);
         
    }
  }

const animateTickMark = gsap.timeline({ paused: true });
const animateCheckBox = new TimelineMax({ paused: true, yoyo: true });

let toggle = true;

animateTickMark
  .set(".checkbox", { border: "2px solid #3F71FF" })
  .to(".fill-color", 0.1, {
    webkitClipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)"
  })
  .to(".tick-mark-1", 0.1, {
    webkitClipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)"
  })
  .to(".tick-mark-2", 0.1, {
    webkitClipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)"
  });

animateCheckBox
  .to(".checkbox", 0.1, { rotate: 10 }, 0.2)
  .to(".checkbox", 0.1, { rotate: 0 }, 0.3)
  .to(".line-1", 0.1, { width: 15 }, 0.3)
  .to(".line-2", 0.1, { width: 15 }, 0.3)
  .to(".line-3", 0.1, { width: 15 }, 0.3)
  .to(".line-4", 0.1, { width: 15 }, 0.3)
  .set(".line-1", { width: 0 })
  .set(".line-2", { width: 0 })
  .set(".line-3", { width: 0 })
  .set(".line-4", { width: 0 });

$(".checkbox").click(() => {
  if (toggle) {
    $("#myAudio")[0].play();
    animateTickMark.restart();
    animateCheckBox.restart();
  } else {
    animateTickMark.reverse();
  }
  toggle = !toggle;
});